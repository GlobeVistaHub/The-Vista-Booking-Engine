import {Config} from '@remotion/cli/config';

Config.setVideoImageFormat('jpeg');
// Needed so three.js / WebGL renders correctly in headless Chromium.
Config.setChromiumOpenGlRenderer('angle');
Config.setOverwriteOutput(true);
