import React from 'react';
import {Easing, interpolate, useCurrentFrame} from 'remotion';
import {loadFont} from '@remotion/google-fonts/Cairo';
import {COLORS, FPS} from './config';

export const {fontFamily} = loadFont('normal', {
  weights: ['700', '900'],
  subsets: ['arabic', 'latin'],
});

// Smooth "expo-out" curve — fast start, long soft landing (no linear snaps).
const easeOut = Easing.bezier(0.16, 1, 0.3, 1);
const easeIn = Easing.bezier(0.5, 0, 0.9, 0.4);

type Word = {t: string; accent: boolean};

// "هل يستطيع *الذكاء الاصطناعي*" → words, highlighted ones flagged
const parse = (text: string): Word[] =>
  text
    .split('*')
    .flatMap((seg, i) =>
      seg
        .split(/\s+/)
        .filter(Boolean)
        .map((t) => ({t, accent: i % 2 === 1})),
    );

type PhraseProps = {
  at: number; // seconds: first word appears (match the narration beat)
  until: number; // seconds: phrase starts leaving (hold a beat after the voice)
  text: string;
  y?: number;
  size?: number;
  accentColor?: string;
  latin?: boolean; // for English text (letter-spaced, left-to-right)
  weight?: 700 | 900;
  color?: string;
};

export const Phrase: React.FC<PhraseProps> = ({
  at,
  until,
  text,
  y = 0,
  size = 104,
  accentColor = COLORS.yellow,
  latin = false,
  weight = 900,
  color = COLORS.white,
}) => {
  const frame = useCurrentFrame();
  const f0 = at * FPS;
  const f1 = until * FPS;
  if (frame < f0 - 1 || frame > f1 + 16) return null;

  const exit = interpolate(frame, [f1, f1 + 12], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: easeIn,
  });
  const words = parse(text);

  return (
    <div
      style={{
        position: 'absolute',
        inset: 0,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '0 160px',
        transform: `translateY(${y - exit * 36}px)`,
        opacity: 1 - exit,
      }}
    >
      <div
        dir={latin ? 'ltr' : 'rtl'}
        style={{
          display: 'flex',
          flexWrap: 'wrap',
          justifyContent: 'center',
          gap: `0 ${size * 0.26}px`,
          fontFamily,
          fontWeight: weight,
          fontSize: size,
          lineHeight: 1.3,
          letterSpacing: latin ? '0.28em' : 0, // never letter-space Arabic: it breaks the joins
          textAlign: 'center',
          color,
        }}
      >
        {words.map((w, i) => {
          // each word arrives 3 frames after the previous one
          const p = interpolate(frame, [f0 + i * 3, f0 + i * 3 + 18], [0, 1], {
            extrapolateLeft: 'clamp',
            extrapolateRight: 'clamp',
            easing: easeOut,
          });
          return (
            <span
              key={i}
              style={{
                display: 'inline-block',
                opacity: p,
                transform: `translateY(${(1 - p) * 70}px) scale(${0.92 + p * 0.08})`,
                filter: `blur(${(1 - p) * 14}px)`,
                color: w.accent ? accentColor : color,
                textShadow: w.accent ? `0 0 38px ${accentColor}66` : 'none',
              }}
            >
              {w.t}
            </span>
          );
        })}
      </div>
    </div>
  );
};

type ToolCardProps = {
  name: string;
  desc: string;
  at: number;
  until: number;
  index: number;
  total: number;
};

export const ToolCard: React.FC<ToolCardProps> = ({name, desc, at, until, index, total}) => {
  const frame = useCurrentFrame();
  const f0 = at * FPS;
  const f1 = until * FPS;
  if (frame < f0 - 1 || frame > f1 + 16) return null;

  const enter = interpolate(frame, [f0, f0 + 22], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: easeOut,
  });
  const exit = interpolate(frame, [f1, f1 + 12], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: easeIn,
  });
  const descIn = interpolate(frame, [f0 + 10, f0 + 30], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: easeOut,
  });
  const underline = interpolate(frame, [f0 + 6, f0 + 28], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: easeOut,
  });

  return (
    <div
      style={{
        position: 'absolute',
        inset: 0,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        opacity: (1 - exit) * enter,
        transform: `translateX(${(1 - enter) * 160 - exit * 120}px)`,
      }}
    >
      <div style={{textAlign: 'center', fontFamily}}>
        <div
          dir="ltr"
          style={{
            fontSize: 34,
            fontWeight: 700,
            letterSpacing: '0.3em',
            color: COLORS.blue,
            marginBottom: 18,
          }}
        >
          {String(index + 1).padStart(2, '0')} / {String(total).padStart(2, '0')}
        </div>
        <div
          dir="ltr"
          style={{
            fontSize: 190,
            fontWeight: 900,
            lineHeight: 1.05,
            color: COLORS.yellow,
            textShadow: `0 0 60px ${COLORS.yellow}55`,
          }}
        >
          {name}
        </div>
        <div
          style={{
            height: 8,
            borderRadius: 4,
            margin: '22px auto 34px',
            width: 520 * underline,
            background: `linear-gradient(90deg, ${COLORS.blue}, ${COLORS.yellow})`,
          }}
        />
        <div
          dir="rtl"
          style={{
            fontSize: 70,
            fontWeight: 700,
            color: COLORS.white,
            opacity: descIn,
            transform: `translateY(${(1 - descIn) * 40}px)`,
          }}
        >
          {desc}
        </div>
      </div>
    </div>
  );
};
