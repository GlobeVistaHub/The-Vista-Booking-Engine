// ─────────────────────────────────────────────────────────────
//  Everything you will want to edit lives in this file:
//  size, colors, the Arabic script and its timing (in seconds).
//  After you record / generate the voice-over, only change the
//  `at` / `until` numbers below so each phrase lands on its beat.
// ─────────────────────────────────────────────────────────────

// Landscape 16:9. For vertical Shorts/Reels use WIDTH = 1080, HEIGHT = 1920
// (the 3D scene and text are laid out relative to the frame, but re-check
// font sizes — see README).
export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;
export const DURATION_S = 53;
export const DURATION_FRAMES = FPS * DURATION_S;

// Put your narration in /public and set its name here, e.g. 'voiceover.mp3'
export const VOICEOVER_FILE: string | null = null;

// Your name for the sign-off line. Leave '' to say just "this is Harfen W Laken".
export const PRESENTER = '';

export const CHANNEL = {
  ar: 'حرفين و لكن',
  en: 'HARFEN W LAKEN',
  tagline: 'أخبار الذكاء الاصطناعي بالعربي',
};

export const COLORS = {
  bg1: '#070B16', // deep charcoal-blue
  bg2: '#0E1A33',
  white: '#F5F7FF',
  blue: '#3D8BFF',
  yellow: '#FFD23F',
  dim: 'rgba(245,247,255,0.55)',
};

export const sec = (s: number) => Math.round(s * FPS);

// Scene windows (seconds)
export const T = {
  hook: [0, 3.4],
  tools: [3.0, 18.0],
  pivot: [18.0, 35.0],
  thesis: [35.0, 45.0],
  outro: [45.0, 53.0],
  // waveform: music/voice fades to nothing, then holds in silence
  silenceStart: 31.0,
  silenceEnd: 34.6,
  // the two ideas in the thesis scene merge here
  merge: 40.5,
} as const;

export type PhraseData = {
  at: number;
  until: number;
  text: string; // wrap highlighted words in *stars*
  y?: number; // vertical offset from center, px
  size?: number;
};

// 0–3s  THE HOOK — a high-stakes question
// ("Can AI replace a video editor? Let's find out.")
export const HOOK: PhraseData[] = [
  {at: 0.1, until: 3.2, y: -150, size: 100, text: 'هل يستطيع *الذكاء الاصطناعي*'},
  {at: 1.0, until: 3.2, y: 0, size: 100, text: 'أن يحلّ محل *محرر الفيديو؟*'},
  {at: 2.0, until: 3.2, y: 150, size: 100, text: '*لنكتشف.*'},
];

// 3–18s  THE TOOLS — builds credibility (≈3.75s each)
export const TOOLS = [
  {name: 'Opus Clip', desc: 'يحوّل الفيديو الطويل إلى مقاطع قصيرة', at: 3.4, until: 7.05},
  {name: 'CapCut', desc: 'ترجمة تلقائية لكل كلمة تُقال', at: 7.2, until: 10.85},
  {name: 'Premiere Pro', desc: 'تعبئة توليدية بالذكاء الاصطناعي', at: 11.0, until: 14.65},
  {name: 'Kling', desc: 'لقطات كاملة من وصف مكتوب', at: 14.8, until: 18.0},
];

// 18–35s  THE EMOTIONAL PIVOT — human taste
export const PIVOT: PhraseData[] = [
  {at: 18.2, until: 22.0, text: 'لأن الذكاء الاصطناعي *يستطيع قصّ الفيديو*'},
  {at: 22.2, until: 26.0, text: 'لكنه *لا يشعر* به'},
  {at: 26.2, until: 30.4, text: 'ولا يعرف متى يترك *اللحظة تتنفس*'},
  // holds through the silence on purpose
  {at: 30.4, until: 34.9, text: 'حين يكون *الصمت* أقوى من الموسيقى'},
];

// 35–45s  THE MINDSET SHIFT — the thesis
export const THESIS: PhraseData[] = [
  {at: 35.1, until: 38.0, text: 'المحررون الذين *سيخسرون*'},
  {at: 38.1, until: 40.4, text: 'لن يخسروا أمام *الذكاء الاصطناعي*'},
  {at: 40.5, until: 42.2, text: 'بل أمام *محررين يستخدمونه*'},
  {at: 42.4, until: 45.0, y: -170, size: 120, text: 'لا تحاربه.'},
  {at: 43.2, until: 45.0, y: 0, size: 120, text: '*تعلّمه.*'},
  {at: 44.0, until: 45.0, y: 170, size: 120, text: '*استخدمه.*'},
];

// 45–53s  BRAND SIGN-OFF
export const SIGNOFF_AT = 45.3;
export const LOGO_AT = 46.2;
export const TAGLINE_AT = 47.6;
