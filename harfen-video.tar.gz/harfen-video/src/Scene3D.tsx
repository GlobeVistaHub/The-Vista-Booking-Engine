import React, {useMemo} from 'react';
import {Easing, interpolate, random, useCurrentFrame} from 'remotion';
import {useThree} from '@react-three/fiber';
import * as THREE from 'three';
import {COLORS, FPS, T, TOOLS} from './config';

// 0 → 1 → 0 visibility window in seconds, eased.
const vis = (t: number, a: number, b: number, fade = 0.7) =>
  interpolate(t, [a, a + fade, b - fade, b], [0, 1, 1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.inOut(Easing.cubic),
  });

const useT = () => {
  const frame = useCurrentFrame();
  return {frame, t: frame / FPS};
};

// Slow camera drift so the frame never feels static.
const CameraRig: React.FC = () => {
  const {t} = useT();
  const camera = useThree((s) => s.camera);
  camera.position.x = Math.sin(t * 0.35) * 0.7;
  camera.position.y = Math.cos(t * 0.27) * 0.35;
  camera.position.z = 10.5 - t * 0.018;
  camera.lookAt(0, 0, 0);
  return null;
};

// Floating blue dust — gives depth through the whole video.
const Particles: React.FC = () => {
  const {frame} = useT();
  const N = 700;
  const positions = useMemo(() => {
    const arr = new Float32Array(N * 3);
    for (let i = 0; i < N; i++) {
      arr[i * 3] = (random(`x${i}`) - 0.5) * 34;
      arr[i * 3 + 1] = (random(`y${i}`) - 0.5) * 20;
      arr[i * 3 + 2] = -random(`z${i}`) * 26 + 4;
    }
    return arr;
  }, []);
  return (
    <points rotation={[0, frame * 0.0014, 0]} position={[0, -frame * 0.0006, 0]}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" count={N} array={positions} itemSize={3} />
      </bufferGeometry>
      <pointsMaterial
        color={COLORS.blue}
        size={0.07}
        transparent
        opacity={0.75}
        sizeAttenuation
        depthWrite={false}
      />
    </points>
  );
};

// HOOK + OUTRO — a wireframe "AI core".
const Core: React.FC = () => {
  const {frame, t} = useT();
  const hook = vis(t, T.hook[0] - 1, T.hook[1] + 0.4, 0.9);
  const out = vis(t, T.outro[0], T.outro[1] + 1, 1.2);
  const v = Math.max(hook, out);
  if (v < 0.01) return null;
  const s = (hook > out ? 3.1 : 1.6) * (0.6 + 0.4 * v);
  return (
    <group scale={s} rotation={[frame * 0.006, frame * 0.009, 0]}>
      <mesh>
        <icosahedronGeometry args={[1, 1]} />
        <meshBasicMaterial color={COLORS.blue} wireframe transparent opacity={0.55 * v} />
      </mesh>
      <mesh scale={0.62}>
        <icosahedronGeometry args={[1, 0]} />
        <meshBasicMaterial color={COLORS.yellow} wireframe transparent opacity={0.8 * v} />
      </mesh>
    </group>
  );
};

// TOOLS — four nodes orbit; the active tool lights up yellow.
const Orbit: React.FC = () => {
  const {frame, t} = useT();
  const v = vis(t, T.tools[0], T.tools[1], 0.8);
  if (v < 0.01) return null;
  const active = TOOLS.findIndex((tool) => t >= tool.at - 0.2 && t < tool.until + 0.2);
  const R = 5.6;
  return (
    <group scale={0.7 + 0.3 * v} rotation={[0.35, 0, 0]}>
      <mesh rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[R, 0.014, 12, 160]} />
        <meshBasicMaterial color={COLORS.blue} transparent opacity={0.45 * v} />
      </mesh>
      {TOOLS.map((_, i) => {
        const a = (i / TOOLS.length) * Math.PI * 2 + frame * 0.012;
        const on = i === active;
        const pulse = on ? 1 + 0.25 * Math.sin(frame * 0.25) : 1;
        return (
          <group key={i} position={[Math.cos(a) * R, 0, Math.sin(a) * R]}>
            <mesh scale={(on ? 0.5 : 0.28) * pulse}>
              <sphereGeometry args={[1, 24, 24]} />
              <meshBasicMaterial color={on ? COLORS.yellow : COLORS.blue} transparent opacity={v} />
            </mesh>
            {on && (
              <mesh scale={0.95 * pulse}>
                <sphereGeometry args={[1, 24, 24]} />
                <meshBasicMaterial color={COLORS.yellow} transparent opacity={0.18 * v} />
              </mesh>
            )}
          </group>
        );
      })}
    </group>
  );
};

// PIVOT — a sound waveform. Loud, then it dies in silence and stays flat:
// the visual version of "silence hits harder than music".
const BARS = 61;
const Waveform: React.FC = () => {
  const {frame, t} = useT();
  const v = vis(t, T.pivot[0], T.pivot[1], 0.9);
  if (v < 0.01) return null;

  const loud = interpolate(t, [T.silenceStart, T.silenceStart + 0.9], [1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.out(Easing.cubic),
  });
  // tiny pulse when sound returns, right before the thesis
  const back = interpolate(t, [T.silenceEnd, T.silenceEnd + 0.5], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const amp = Math.max(loud, back * 0.6);
  const silent = 1 - amp;
  const color = new THREE.Color(COLORS.blue).lerp(new THREE.Color(COLORS.yellow), silent);

  return (
    <group position={[0, -3.45, 0]}>
      {Array.from({length: BARS}).map((_, i) => {
        const x = (i - (BARS - 1) / 2) * 0.3;
        const envelope = Math.exp(-Math.pow(x / 7.5, 2)); // taller in the middle
        const wob =
          0.55 +
          0.45 * Math.sin(frame * 0.33 + i * 0.55) * Math.sin(frame * 0.11 + i * 1.3);
        const h = 0.05 + amp * envelope * (0.35 + Math.abs(wob) * 1.9);
        return (
          <mesh key={i} position={[x, 0, 0]} scale={[1, h, 1]}>
            <boxGeometry args={[0.12, 1, 0.12]} />
            <meshBasicMaterial color={color} transparent opacity={0.9 * v} />
          </mesh>
        );
      })}
    </group>
  );
};

// THESIS — "AI" (blue) and "the editor" (yellow) drift together and merge.
const Merge: React.FC = () => {
  const {frame, t} = useT();
  const v = vis(t, T.thesis[0], T.thesis[1], 0.8);
  if (v < 0.01) return null;
  const k = interpolate(t, [T.thesis[0] + 0.5, T.merge], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.inOut(Easing.cubic),
  });
  const x = 6.2 * (1 - k) + 0.45 * k;
  const burst = interpolate(t, [T.merge, T.merge + 0.5, T.merge + 1.4], [0, 1, 0.35], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const s = (0.95 + burst * 0.45) * (0.7 + 0.3 * v);
  return (
    <group position={[0, 3.0, 0]} scale={s}>
      <mesh position={[-x, 0, 0]} rotation={[frame * 0.01, frame * 0.014, 0]}>
        <icosahedronGeometry args={[1, 1]} />
        <meshBasicMaterial color={COLORS.blue} wireframe transparent opacity={0.9 * v} />
      </mesh>
      <mesh position={[x, 0, 0]} rotation={[frame * 0.012, -frame * 0.011, 0]}>
        <octahedronGeometry args={[1.05, 0]} />
        <meshBasicMaterial color={COLORS.yellow} wireframe transparent opacity={0.9 * v} />
      </mesh>
      <mesh scale={1.7 + burst}>
        <sphereGeometry args={[1, 24, 24]} />
        <meshBasicMaterial color={COLORS.white} transparent opacity={0.1 * burst * v} />
      </mesh>
    </group>
  );
};

// OUTRO — rings orbit the logo.
const Rings: React.FC = () => {
  const {frame, t} = useT();
  const v = vis(t, T.outro[0] + 0.3, T.outro[1] + 1, 1.2);
  if (v < 0.01) return null;
  return (
    <group scale={0.6 + 0.4 * v}>
      {[0, 1, 2].map((i) => (
        <mesh
          key={i}
          rotation={[frame * 0.004 * (i + 1) + i, frame * 0.006 - i, i * 1.1]}
        >
          <torusGeometry args={[4.4 + i * 0.9, 0.012, 12, 200]} />
          <meshBasicMaterial
            color={i === 1 ? COLORS.yellow : COLORS.blue}
            transparent
            opacity={(0.55 - i * 0.12) * v}
          />
        </mesh>
      ))}
    </group>
  );
};

export const Scene3D: React.FC = () => (
  <>
    <CameraRig />
    <Particles />
    <Core />
    <Orbit />
    <Waveform />
    <Merge />
    <Rings />
  </>
);
