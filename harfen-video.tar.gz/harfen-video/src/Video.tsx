import React from 'react';
import {AbsoluteFill, Audio, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {ThreeCanvas} from '@remotion/three';
import {Scene3D} from './Scene3D';
import {Phrase, ToolCard, fontFamily} from './Kinetic';
import {
  CHANNEL,
  COLORS,
  DURATION_FRAMES,
  FPS,
  HEIGHT,
  HOOK,
  LOGO_AT,
  PIVOT,
  PRESENTER,
  SIGNOFF_AT,
  T,
  TAGLINE_AT,
  THESIS,
  TOOLS,
  VOICEOVER_FILE,
  WIDTH,
} from './config';

const Backdrop: React.FC = () => (
  <>
    <AbsoluteFill
      style={{
        background: `radial-gradient(ellipse at 50% 35%, ${COLORS.bg2} 0%, ${COLORS.bg1} 70%)`,
      }}
    />
    {/* faint grid for a "tech" feel */}
    <AbsoluteFill
      style={{
        opacity: 0.07,
        backgroundImage:
          'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)',
        backgroundSize: '90px 90px',
      }}
    />
  </>
);

const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{
      background: 'radial-gradient(ellipse at center, transparent 55%, rgba(0,0,0,0.55) 100%)',
      pointerEvents: 'none',
    }}
  />
);

const Watermark: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const o = interpolate(t, [0.5, 1.2, T.outro[0] - 0.3, T.outro[0]], [0, 0.7, 0.7, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  return (
    <div
      dir="rtl"
      style={{
        position: 'absolute',
        top: 48,
        right: 64,
        fontFamily,
        fontWeight: 900,
        fontSize: 40,
        color: COLORS.white,
        opacity: o,
      }}
    >
      {CHANNEL.ar}
    </div>
  );
};

const Progress: React.FC = () => {
  const frame = useCurrentFrame();
  const w = interpolate(frame, [0, DURATION_FRAMES], [0, 100]);
  return (
    <div style={{position: 'absolute', left: 0, bottom: 0, width: '100%', height: 8}}>
      <div
        style={{
          height: '100%',
          width: `${w}%`,
          background: `linear-gradient(90deg, ${COLORS.blue}, ${COLORS.yellow})`,
        }}
      />
    </div>
  );
};

export const Video: React.FC = () => {
  const frame = useCurrentFrame();
  const fadeIn = interpolate(frame, [0, 6], [0, 1], {extrapolateRight: 'clamp'});
  const END = 99; // "until" for items that stay to the end

  const signoff = PRESENTER
    ? `أنا *${PRESENTER}* وهذه قناة`
    : 'وهذه قناتك للذكاء الاصطناعي';

  return (
    <AbsoluteFill style={{backgroundColor: COLORS.bg1, opacity: fadeIn}}>
      <Backdrop />

      <ThreeCanvas
        width={WIDTH}
        height={HEIGHT}
        camera={{position: [0, 0, 10.5], fov: 50}}
        style={{position: 'absolute', inset: 0}}
      >
        <Scene3D />
      </ThreeCanvas>

      <Vignette />

      {/* 0–3s hook */}
      {HOOK.map((p, i) => (
        <Phrase key={`h${i}`} {...p} />
      ))}

      {/* 3–18s tools */}
      {TOOLS.map((tool, i) => (
        <ToolCard key={tool.name} {...tool} index={i} total={TOOLS.length} />
      ))}

      {/* 18–35s pivot */}
      {PIVOT.map((p, i) => (
        <Phrase key={`p${i}`} {...p} />
      ))}

      {/* 35–45s thesis */}
      {THESIS.map((p, i) => (
        <Phrase key={`t${i}`} {...p} />
      ))}

      {/* 45–53s sign-off */}
      <Phrase at={SIGNOFF_AT} until={END} y={-250} size={64} weight={700} color={COLORS.dim} text={signoff} />
      <Phrase at={LOGO_AT} until={END} y={-40} size={210} text={`حرفين و *لكن*`} />
      <Phrase
        at={TAGLINE_AT}
        until={END}
        y={150}
        size={34}
        weight={700}
        latin
        accentColor={COLORS.blue}
        text={`*${CHANNEL.en}*`}
      />
      <Phrase at={TAGLINE_AT + 0.6} until={END} y={240} size={46} weight={700} color={COLORS.dim} text={CHANNEL.tagline} />

      <Watermark />
      <Progress />

      {VOICEOVER_FILE ? <Audio src={staticFile(VOICEOVER_FILE)} /> : null}
    </AbsoluteFill>
  );
};
