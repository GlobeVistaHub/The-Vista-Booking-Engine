import React from 'react';
import {Composition} from 'remotion';
import {Video} from './Video';
import {DURATION_FRAMES, FPS, HEIGHT, WIDTH} from './config';

export const Root: React.FC = () => (
  <Composition
    id="Main"
    component={Video}
    durationInFrames={DURATION_FRAMES}
    fps={FPS}
    width={WIDTH}
    height={HEIGHT}
  />
);
