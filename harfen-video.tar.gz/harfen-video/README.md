# Harfen W Laken — AI explainer (Remotion + react-three-fiber)

53 s · 1920×1080 · 30 fps · Arabic RTL kinetic typography over a 3D scene.

## Run
```bash
npm install
npm start          # Remotion Studio: live preview, scrub the timeline
npm run render     # → out/harfen-w-laken.mp4
npm run still      # → out/frame.png (frame 900)
```
If the 3D layer renders black on your machine, keep `setChromiumOpenGlRenderer('angle')`
in `remotion.config.ts`; on some Linux servers `--gl=swangle` works better.

## Edit
All in `src/config.ts`: size, colors, Arabic script, timing (seconds), presenter name,
voice-over file. Highlight words with `*stars*`.

## Sync to your voice-over
1. Generate/record the narration, drop it in `public/voiceover.mp3`.
2. Set `VOICEOVER_FILE = 'voiceover.mp3'`.
3. Open Studio, play, and adjust each phrase's `at` (word appears) and `until`
   (starts leaving — keep ~0.3 s after the voice ends so it can be read).
   Waveform "silence" window: `T.silenceStart` / `T.silenceEnd`.

## 3D scenes (src/Scene3D.tsx)
- 0–3 s   wireframe AI core
- 3–18 s  four orbiting nodes, the active tool lights up yellow
- 18–35 s waveform that dies into silence (and holds) on "الصمت أقوى من الموسيقى"
- 35–45 s "AI" and "editor" shapes merge on "editors who use it"
- 45–53 s rings around the channel logo

## Vertical version
Set `WIDTH = 1080`, `HEIGHT = 1920` in `config.ts`. Then reduce `size` values
(hook 100 → ~80, logo 210 → ~150) and the tool-name size (190 → ~130) in `Kinetic.tsx`.
