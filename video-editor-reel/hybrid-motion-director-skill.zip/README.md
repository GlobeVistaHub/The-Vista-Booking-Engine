# 🎬 GoodBrains.Pro • Viral Hybrid Motion Architecture
> **The 5-Beat Retention Engine • Programmatic Remotion + Three.js Motion Pipeline**

[![GoodBrains.Pro Studio](https://img.shields.io/badge/GoodBrains.Pro-Studio%20Creatives-3D8BFF?style=for-the-badge)](https://goodbrains.pro)
[![Remotion](https://img.shields.io/badge/Remotion-v4.0-FFD23F?style=for-the-badge)](https://remotion.dev)
[![Tested on TikTok](https://img.shields.io/badge/TikTok%20FYP-98.7%25%20Verified-00F2FE?style=for-the-badge)](https://tiktok.com)
[![MCP Compatible](https://img.shields.io/badge/MCP-JSON--RPC%20Ready-FF2E93?style=for-the-badge)](https://modelcontextprotocol.io)

---

## ⚡ Overview

This repository houses the complete, broadcast-grade **Viral Hybrid Motion Engine** authored and produced by **GoodBrains.Pro Studio**. 

Built natively in **Remotion, React, and Three.js**, this pipeline abandons the fragile keyframes and slow rendering of Adobe After Effects and DaVinci Resolve in favor of **100% deterministic, programmatic audio-reactive code** with sub-frame and millisecond precision.

---

## 🧠 The 5-Beat Retention Arc

| Beat | Window | Purpose | Technical Implementation |
| :--- | :---: | :--- | :--- |
| **Beat 1: The Contrarian Hook** | `0.0s – 5.4s` | Interrupt doom-scrolling with high-stakes paradox | Cairo 84px typography, sub-impact + rising whoosh |
| **Beat 2: High-Density Staccato** | `5.2s – 22.4s` | Deliver rapid, high-utility tool cards | Translucent glassmorphism (`blur(20px)`), synchronized UI pops |
| **Beat 3: Humanist Pivot** | `22.3s – 37.0s` | Disarm viewer with authentic philosophical truth | Analog tape-stop SFX at 30.4s cutting music into vocal silence |
| **Beat 4: Mindset Reframing** | `37.0s – 48.0s` | Reframe fear into empowering action | Deep 35Hz sub-bass impact, rhythmic staccato typography |
| **Beat 5: Signature Anchor** | `48.0s – 55.0s` | Lock in brand equity & authority | 500px 3D glowing medallion with 45° metallic sheen sweep |

---

## 🚀 Quickstart & Rendering

```bash
# 1. Install dependencies
npm install

# 2. Start interactive Remotion Studio
npm start

# 3. Render 4K Masters (H.264 @ 30fps, CRF 16)
# Vertical 9:16 (English)
npx remotion render src/index.ts VerticalEN out/master_vertical_en.mp4 --concurrency=1 --crf=16

# Horizontal 16:9 (English)
npx remotion render src/index.ts MainEN out/master_horizontal_en.mp4 --concurrency=1 --crf=16
```

---

## 📦 Universal AI & Agent Integrations

This engine is architected to run seamlessly across all modern AI platforms:

### 1. Antigravity Agent
Add as a native workspace skill:
```bash
agy skill add goodbrains/hybrid-motion-director
```

### 2. Anthropic Claude (Claude Projects & Claude Desktop)
- **Claude Projects (Web):** Simply upload `SKILL.md` directly into your Project Knowledge. Claude will strictly apply the 5-Beat Retention Arc and Remotion constraints when writing motion scripts.
- **Claude Desktop (MCP):** Add the server definition from `claude_desktop_config.example.json` into your `claude_desktop_config.json`.

### 3. Higgsfield AI & Generative Video Pipelines (MCP JSON)
Higgsfield and AI video generative pipelines connect directly via our **MCP JSON Tool Manifest** (`mcp_server.json`). This exposes structured tools:
- `plan_retention_arc`: Generates millisecond-accurate storyboards and scene pacing.
- `calculate_dsp_timeline`: Pre-computes 35Hz sub-bass drops and tape-stop silence timestamps for video sync.
- `generate_higgsfield_prompt`: Translates scene beats into cinema-grade camera moves, depth of field, and lighting prompts tailored for Higgsfield video models.

---

*Authored & Produced by GoodBrains.Pro • STUDIO CREATIVES • 2026*
