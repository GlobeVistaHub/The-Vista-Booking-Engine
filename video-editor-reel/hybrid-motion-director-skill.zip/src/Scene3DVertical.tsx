import React, {useMemo} from 'react';
import {Easing, interpolate, random, useCurrentFrame} from 'remotion';
import {useThree} from '@react-three/fiber';
import * as THREE from 'three';
import {visualizeAudio, AudioData} from '@remotion/media-utils';
import {COLORS, FPS, T, TOOLS} from './config';

export interface SceneConfigType {
  T: any;
  TOOLS: any;
}

const SceneConfigContext = React.createContext<SceneConfigType>({
  T,
  TOOLS,
});

export const useSceneConfig = () => React.useContext(SceneConfigContext);

// 0 → 1 → 0 visibility window in seconds, eased.
const vis = (t: number, a: number, b: number, fade = 0.7) =>
  interpolate(t, [a, a + fade, b - fade, b], [0, 1, 1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.inOut(Easing.cubic),
  });

const useT = () => {
  const frame = useCurrentFrame();
  return {frame, t: frame / FPS};
};

// Studio Lighting Rig calibrated for 9:16 portrait viewport
const LightingVertical: React.FC = () => {
  return (
    <>
      <ambientLight intensity={0.75} />
      {/* Key Light */}
      <directionalLight position={[5, 8, 8]} intensity={2.4} color="#FFFFFF" />
      {/* Cyan Rim Light */}
      <pointLight position={[-6, 2, 4]} intensity={3.5} distance={25} color={COLORS.blue} />
      {/* Warm Amber Rim Light */}
      <pointLight position={[6, 3, 4]} intensity={3.8} distance={25} color={COLORS.yellow} />
      {/* Deep Under-Rim Backlight */}
      <directionalLight position={[0, -6, -5]} intensity={1.2} color="#38BDF8" />
    </>
  );
};

// Cinematic vertical camera drift with portrait Z-depth
const CameraRigVertical: React.FC = () => {
  const {t} = useT();
  const camera = useThree((s) => s.camera);
  camera.position.x = Math.sin(t * 0.35) * 0.25;
  camera.position.y = Math.cos(t * 0.27) * 0.2;
  camera.position.z = 12.2 - t * 0.015;
  camera.lookAt(0, 0, 0);
  return null;
};

// Floating ambient depth dust - calibrated bounds for portrait
const ParticlesVertical: React.FC = () => {
  const {frame} = useT();
  const N = 550;
  const positions = useMemo(() => {
    const arr = new Float32Array(N * 3);
    for (let i = 0; i < N; i++) {
      arr[i * 3] = (random(`vx${i}`) - 0.5) * 14; // Narrow X to keep particles inside 9:16 view
      arr[i * 3 + 1] = (random(`vy${i}`) - 0.5) * 24; // Tall Y for vertical height
      arr[i * 3 + 2] = -random(`vz${i}`) * 22 + 4;
    }
    return arr;
  }, []);
  return (
    <points rotation={[0, frame * 0.0012, 0]} position={[0, -frame * 0.0005, 0]}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" count={N} array={positions} itemSize={3} args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial
        color={COLORS.blue}
        size={0.065}
        transparent
        opacity={0.65}
        sizeAttenuation
        depthWrite={false}
      />
    </points>
  );
};

// HOOK + OUTRO — Luxury Volumetric Orb (Frosted Glass Outer Shell + Luminous Nucleus).
// Scaled natively to fit within 9:16 without ever bleeding off screen edges!
const CoreVertical: React.FC = () => {
  const {frame, t} = useT();
  const {T} = useSceneConfig();
  const hook = vis(t, T.hook[0] - 1, T.hook[1] + 0.4, 0.9);
  const out = vis(t, T.outro[0], T.outro[1] + 1, 1.2);
  const v = Math.max(hook, out);
  if (v < 0.01) return null;
  const morphOut = interpolate(t, [52.8, 53.3], [1, 0.05], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.in(Easing.cubic),
  });

  // Native vertical scale: 1.4 for Hook, 1.1 for Outro (comfortably within 48% screen width)
  const s = (hook > out ? 1.4 : 1.1) * (0.6 + 0.4 * v) * (out > 0.01 ? morphOut : 1);

  return (
    <group scale={s} rotation={[frame * 0.006, frame * 0.009, 0]}>
      {/* Outer Frosted Glass Sphere */}
      <mesh>
        <sphereGeometry args={[1.1, 36, 36]} />
        <meshPhysicalMaterial
          color={COLORS.blue}
          roughness={0.15}
          metalness={0.1}
          transmission={0.82}
          thickness={1.4}
          ior={1.45}
          transparent
          opacity={0.85 * v}
        />
      </mesh>
      {/* Delicate Latitude Gimbal Ring */}
      <mesh rotation={[frame * 0.015, 0, frame * 0.01]}>
        <torusGeometry args={[1.35, 0.012, 16, 90]} />
        <meshStandardMaterial
          color={COLORS.blue}
          emissive={COLORS.blue}
          emissiveIntensity={0.6}
          roughness={0.1}
          metalness={0.9}
          transparent
          opacity={0.9 * v}
        />
      </mesh>
      {/* Inner Glowing Crystal Core */}
      <mesh scale={0.52} rotation={[-frame * 0.01, frame * 0.012, 0]}>
        <octahedronGeometry args={[1, 0]} />
        <meshStandardMaterial
          color={COLORS.yellow}
          emissive={COLORS.yellow}
          emissiveIntensity={0.65}
          flatShading
          roughness={0.15}
          metalness={0.6}
          transparent
          opacity={0.95 * v}
        />
      </mesh>
    </group>
  );
};

// TOOLS — 4 Orbiting Satellites scaled natively for portrait width
const OrbitVertical: React.FC = () => {
  const {frame, t} = useT();
  const {T, TOOLS} = useSceneConfig();
  const v = vis(t, T.tools[0], T.tools[1], 0.8);
  if (v < 0.01) return null;
  const active = TOOLS.findIndex((tool: any) => t >= tool.at && t < tool.until);
  // Radius 2.4 fits 100% within the 9:16 mobile horizontal safe zone
  const R = 2.45;
  return (
    <group scale={0.7 + 0.3 * v} rotation={[0.42, 0, 0]}>
      <mesh rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[R, 0.016, 16, 160]} />
        <meshStandardMaterial
          color={COLORS.blue}
          emissive={COLORS.blue}
          emissiveIntensity={0.4}
          roughness={0.2}
          metalness={0.8}
          transparent
          opacity={0.55 * v}
        />
      </mesh>
      {TOOLS.map((_: any, i: number) => {
        const a = (i / TOOLS.length) * Math.PI * 2 + frame * 0.012;
        const on = i === active;
        const pulse = on ? 1 + 0.22 * Math.sin(frame * 0.25) : 1;
        return (
          <group key={i} position={[Math.cos(a) * R, 0, Math.sin(a) * R]}>
            <mesh scale={(on ? 0.30 : 0.18) * pulse}>
              <sphereGeometry args={[1, 32, 32]} />
              <meshStandardMaterial
                color={on ? COLORS.yellow : COLORS.blue}
                emissive={on ? COLORS.yellow : COLORS.blue}
                emissiveIntensity={on ? 0.8 : 0.35}
                roughness={0.15}
                metalness={0.7}
                transparent
                opacity={v}
              />
            </mesh>
            {on && (
              <mesh scale={0.52 * pulse}>
                <sphereGeometry args={[1, 24, 24]} />
                <meshStandardMaterial
                  color={COLORS.yellow}
                  transparent
                  opacity={0.22 * v}
                  roughness={0.1}
                />
              </mesh>
            )}
          </group>
        );
      })}
    </group>
  );
};

// PIVOT — 64-Band Real Audio FFT Waveform natively formatted for mobile portrait
const BARS = 64;
const WaveformVertical: React.FC<{audioData?: AudioData | null}> = ({audioData}) => {
  const {frame, t} = useT();
  const {T} = useSceneConfig();

  const enter = interpolate(t, [22.3, 23.1], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.out(Easing.cubic),
  });
  const exit = interpolate(t, [36.7, 37.06], [1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.in(Easing.cubic),
  });
  const v = Math.min(enter, exit);
  if (v < 0.005) return null;

  const loud = interpolate(t, [T.silenceStart, T.silenceStart + 0.4], [1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.out(Easing.cubic),
  });
  const back = interpolate(t, [T.silenceEnd, T.silenceEnd + 0.18], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const ampEnvelope = Math.max(loud, back);

  const visualization = audioData
    ? visualizeAudio({
        audioData,
        frame,
        fps: FPS,
        numberOfSamples: 64,
        smoothing: true,
      })
    : null;

  const color = new THREE.Color(COLORS.blue).lerp(
    new THREE.Color(COLORS.yellow),
    1 - ampEnvelope,
  );

  return (
    <group position={[0, -3.2, 0]}>
      {Array.from({length: BARS}).map((_, i) => {
        // Formatted to span 5.1 units total width (perfectly fits inside portrait screen)
        const x = (i - (BARS - 1) / 2) * 0.08;

        const center = (BARS - 1) / 2;
        const distFromCenter = Math.abs(i - center);
        const normDist = distFromCenter / center;
        const binIndex = Math.min(63, Math.floor(normDist * 52));

        const rawSample = visualization ? visualization[binIndex] : 0;
        const voiceBoost = 1.0 + (1 - normDist) * 2.2;
        const dynamicHeight = rawSample * 6.5 * voiceBoost;

        const h = Math.max(0.06, 0.06 + dynamicHeight * ampEnvelope * v);

        return (
          <mesh key={i} position={[x, 0, 0]} scale={[1, h, 1]}>
            <boxGeometry args={[0.048, 1, 0.048]} />
            <meshStandardMaterial
              color={color}
              emissive={color}
              emissiveIntensity={0.5}
              roughness={0.2}
              metalness={0.8}
              transparent
              opacity={0.92 * v}
            />
          </mesh>
        );
      })}
    </group>
  );
};

// THESIS — AI & Human Editor Symbiosis formatted for portrait viewport
const MergeVertical: React.FC = () => {
  const {frame, t} = useT();
  const {T} = useSceneConfig();
  const v = vis(t, T.thesis[0], T.thesis[1], 0.8);
  if (v < 0.01) return null;

  const k = interpolate(t, [T.thesis[0] + 0.4, T.merge], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.inOut(Easing.cubic),
  });

  // Safe distance inside portrait width: 2.2 units
  const distance = 2.2 * (1 - k);
  const orbitalPhase = k * Math.PI;
  const zDepth = Math.sin(orbitalPhase) * 0.85;

  const bluePos: [number, number, number] = [-distance * Math.cos(orbitalPhase * 0.3), 0, zDepth];
  const amberPos: [number, number, number] = [distance * Math.cos(orbitalPhase * 0.3), 0, -zDepth];

  const isMerged = t >= T.merge;
  const burst = interpolate(t, [T.merge, T.merge + 0.35, T.merge + 1.2], [0, 1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const shockwaveScale = interpolate(burst, [0, 1], [0.8, 2.0]);
  const shockwaveOpacity = burst * 0.85 * v;

  const s = (0.85 + burst * 0.25) * (0.7 + 0.3 * v);

  return (
    <group position={[0, 2.4, 0]} scale={s}>
      {/* Centered 3D Backdrop Halo Stage */}
      <mesh position={[0, 0, -1.0]} rotation={[0.22, 0, 0]} scale={[1.4, 0.85, 1]}>
        <torusGeometry args={[2.1, 0.016, 16, 120]} />
        <meshStandardMaterial
          color={COLORS.blue}
          emissive={COLORS.blue}
          emissiveIntensity={0.7}
          roughness={0.2}
          metalness={0.8}
          transparent
          opacity={0.45 * v}
        />
      </mesh>
      <pointLight position={[0, 0, -1.2]} intensity={3.0 * v} distance={10} color="#38BDF8" />

      {/* Blue AI Glass Sphere */}
      <group position={isMerged ? [0, 0, 0] : bluePos} rotation={[frame * 0.008, frame * 0.012, 0]}>
        <mesh>
          <sphereGeometry args={[1.0, 36, 36]} />
          <meshPhysicalMaterial
            color={COLORS.blue}
            roughness={0.12}
            metalness={0.15}
            transmission={0.82}
            thickness={1.5}
            ior={1.48}
            transparent
            opacity={0.88 * v}
          />
        </mesh>
        <mesh rotation={[Math.PI / 4, frame * 0.015, 0]}>
          <torusGeometry args={[1.18, 0.012, 16, 80]} />
          <meshStandardMaterial
            color={COLORS.blue}
            emissive={COLORS.blue}
            emissiveIntensity={0.6}
            metalness={0.9}
            roughness={0.1}
            transparent
            opacity={0.75 * v}
          />
        </mesh>
      </group>

      {/* Amber Human Editor Crystal */}
      <group
        position={isMerged ? [0, 0, 0] : amberPos}
        rotation={[frame * 0.014, -frame * 0.018, frame * 0.01]}
        scale={isMerged ? 0.58 : 0.85}
      >
        <mesh>
          <octahedronGeometry args={[0.9, 0]} />
          <meshStandardMaterial
            color={COLORS.yellow}
            emissive="#D97706"
            emissiveIntensity={isMerged ? 1.6 : 0.45}
            flatShading
            roughness={0.15}
            metalness={0.65}
            transparent
            opacity={0.95 * v}
          />
        </mesh>
        <mesh scale={0.42}>
          <sphereGeometry args={[1, 24, 24]} />
          <meshBasicMaterial color="#FEF08A" />
        </mesh>
      </group>

      {/* Shockwave on convergence */}
      {shockwaveOpacity > 0.01 && (
        <mesh rotation={[0.22, 0, 0]} scale={shockwaveScale}>
          <ringGeometry args={[1.1, 1.15, 64]} />
          <meshBasicMaterial
            color={COLORS.yellow}
            transparent
            opacity={shockwaveOpacity}
            side={THREE.DoubleSide}
          />
        </mesh>
      )}

      {/* Post-Merge Symbiotic Gyro Rings */}
      {isMerged && (
        <group rotation={[frame * 0.01, frame * 0.015, 0]} scale={1.0}>
          <mesh rotation={[Math.PI / 3, 0, 0]}>
            <torusGeometry args={[1.35, 0.012, 16, 90]} />
            <meshStandardMaterial
              color={COLORS.yellow}
              emissive={COLORS.yellow}
              emissiveIntensity={0.6}
              metalness={0.9}
              roughness={0.1}
              transparent
              opacity={0.8 * v}
            />
          </mesh>
        </group>
      )}
    </group>
  );
};

// OUTRO — Gyroscope rings orbiting inside the 9:16 portrait viewport
const RingsVertical: React.FC = () => {
  const {frame, t} = useT();
  const {T} = useSceneConfig();
  const v = vis(t, T.outro[0] + 0.3, T.outro[1] + 1, 1.2);
  if (v < 0.01) return null;

  const morphOut = interpolate(t, [52.8, 53.3], [1, 0.05], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.in(Easing.cubic),
  });
  const spinBoost = interpolate(t, [52.0, 53.2], [1, 3.5], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  return (
    <group scale={(0.6 + 0.4 * v) * morphOut}>
      {[0, 1, 2].map((i) => (
        <mesh
          key={i}
          rotation={[frame * 0.004 * (i + 1) * spinBoost + i, frame * 0.006 * spinBoost - i, i * 1.1]}
        >
          {/* Calibrated radii: 2.2, 2.65, 3.1 - gracefully frames the logo badge without clipping */}
          <torusGeometry args={[2.2 + i * 0.45, 0.014, 16, 180]} />
          <meshStandardMaterial
            color={i === 1 ? COLORS.yellow : COLORS.blue}
            emissive={i === 1 ? COLORS.yellow : COLORS.blue}
            emissiveIntensity={0.4}
            roughness={0.15}
            metalness={0.85}
            transparent
            opacity={(0.6 - i * 0.12) * v * morphOut}
          />
        </mesh>
      ))}
    </group>
  );
};

export interface Scene3DVerticalProps {
  audioData?: AudioData | null;
  tConfig?: any;
  toolsConfig?: any;
}

export const Scene3DVertical: React.FC<Scene3DVerticalProps> = ({
  audioData,
  tConfig = T,
  toolsConfig = TOOLS,
}) => {
  const contextValue = useMemo(
    () => ({
      T: tConfig,
      TOOLS: toolsConfig,
    }),
    [tConfig, toolsConfig],
  );

  return (
    <SceneConfigContext.Provider value={contextValue}>
      <LightingVertical />
      <CameraRigVertical />
      <ParticlesVertical />
      <CoreVertical />
      <OrbitVertical />
      <WaveformVertical audioData={audioData} />
      <MergeVertical />
      <RingsVertical />
    </SceneConfigContext.Provider>
  );
};
