import React from 'react';
import {AbsoluteFill, Audio, Easing, Img, interpolate, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {ThreeCanvas} from '@remotion/three';
import {useAudioData} from '@remotion/media-utils';
import {Scene3D} from './Scene3D';
import {PhraseEN, ToolCardEN} from './KineticEN';
import {fontFamily} from './Kinetic';
import {
  CHANNEL,
  COLORS,
  DURATION_FRAMES,
  FPS,
  HEIGHT,
  HOOK_EN,
  LOGO_AT,
  PIVOT_EN,
  PRESENTER,
  SIGNOFF_AT,
  T,
  TAGLINE_AT,
  THESIS_EN,
  TOOLS_EN,
  VOICEOVER_FILE,
  WIDTH,
} from './configEN';

const Backdrop: React.FC = () => (
  <>
    <AbsoluteFill
      style={{
        background: `radial-gradient(ellipse at 50% 35%, ${COLORS.bg2} 0%, ${COLORS.bg1} 70%)`,
      }}
    />
    <AbsoluteFill
      style={{
        opacity: 0.07,
        backgroundImage:
          'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)',
        backgroundSize: '90px 90px',
      }}
    />
  </>
);

const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{
      background: 'radial-gradient(ellipse at center, transparent 55%, rgba(0,0,0,0.55) 100%)',
      pointerEvents: 'none',
    }}
  />
);

const Watermark: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const o = interpolate(t, [0.5, 1.2, T.outro[0] - 0.3, T.outro[0]], [0, 0.7, 0.7, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  return (
    <div
      dir="ltr"
      style={{
        position: 'absolute',
        top: 48,
        left: 64,
        fontFamily,
        fontWeight: 900,
        fontSize: 28,
        letterSpacing: '0.15em',
        color: COLORS.white,
        opacity: o,
        WebkitFontSmoothing: 'antialiased',
        textRendering: 'optimizeLegibility',
        textShadow: '0 2px 10px rgba(0,0,0,0.8)',
        zIndex: 40,
      }}
    >
      {CHANNEL.en}
    </div>
  );
};

const Progress: React.FC = () => {
  const frame = useCurrentFrame();
  const w = interpolate(frame, [0, DURATION_FRAMES], [0, 100]);
  return (
    <div style={{position: 'absolute', left: 0, bottom: 0, width: '100%', height: 6, zIndex: 40}}>
      <div
        style={{
          height: '100%',
          width: `${w}%`,
          background: `linear-gradient(90deg, ${COLORS.blue}, ${COLORS.yellow})`,
        }}
      />
    </div>
  );
};

const LogoMorph: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const startAt = 52.6;
  if (t < startAt) return null;

  const progress = interpolate(t, [startAt, startAt + 0.65], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.out(Easing.back(1.4)),
  });

  const flare = interpolate(t, [startAt, startAt + 0.22, startAt + 0.75], [0, 1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  const sheen = interpolate(t, [startAt + 0.45, startAt + 1.5], [-120, 220], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  return (
    <div
      style={{
        position: 'absolute',
        inset: 0,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        pointerEvents: 'none',
        zIndex: 50,
      }}
    >
      {flare > 0.01 && (
        <div
          style={{
            position: 'absolute',
            width: 1100,
            height: 1100,
            borderRadius: '50%',
            background:
              'radial-gradient(circle, rgba(255,255,255,0.95) 0%, rgba(61,139,255,0.7) 40%, transparent 70%)',
            opacity: flare,
            transform: `scale(${1 + flare * 0.8})`,
            filter: 'blur(40px)',
          }}
        />
      )}

      <div
        style={{
          position: 'relative',
          width: 440,
          height: 440,
          borderRadius: '50%',
          overflow: 'hidden',
          transform: `scale(${progress})`,
          opacity: Math.min(1, progress * 2.5),
          boxShadow: `0 0 80px rgba(61, 139, 255, 0.9), 0 0 140px rgba(0, 242, 254, 0.4), 0 30px 70px rgba(0,0,0,0.95)`,
          border: `4px solid ${COLORS.blue}`,
        }}
      >
        <Img
          src={staticFile('harfen_logo.png')}
          style={{
            width: '100%',
            height: '100%',
            objectFit: 'cover',
          }}
        />

        <div
          style={{
            position: 'absolute',
            inset: 0,
            background: `linear-gradient(115deg, transparent 0%, rgba(255,255,255,0.6) 45%, rgba(255,255,255,0.9) 50%, rgba(255,255,255,0.6) 55%, transparent 100%)`,
            transform: `translateX(${sheen}%)`,
            pointerEvents: 'none',
          }}
        />
      </div>
    </div>
  );
};

const SoundDesign: React.FC = () => {
  return (
    <>
      {/* 1. Cinematic Whooshes */}
      <Sequence from={Math.round(0.0 * FPS)}>
        <Audio src={staticFile('sfx_whoosh.wav')} volume={0.35} />
      </Sequence>
      {/* Opus Pre-Whoosh @ 00:06.12 = Frame 192 */}
      <Sequence from={192}>
        <Audio src={staticFile('sfx_whoosh.wav')} volume={0.32} />
      </Sequence>
      <Sequence from={Math.round(10.55 * FPS)}>
        <Audio src={staticFile('sfx_whoosh.wav')} volume={0.32} />
      </Sequence>
      <Sequence from={Math.round(15.00 * FPS)}>
        <Audio src={staticFile('sfx_whoosh.wav')} volume={0.32} />
      </Sequence>
      <Sequence from={Math.round(18.15 * FPS)}>
        <Audio src={staticFile('sfx_whoosh.wav')} volume={0.32} />
      </Sequence>
      <Sequence from={Math.round(22.15 * FPS)}>
        <Audio src={staticFile('sfx_whoosh.wav')} volume={0.35} />
      </Sequence>

      {/* 2. UI Pops — Locked 1:1 with perceptual acoustic peaks (Opus Clip @ 00:06.20 = Frame 200) */}
      <Sequence from={200}>
        <Audio src={staticFile('sfx_ui_pop.wav')} volume={0.42} />
      </Sequence>
      <Sequence from={Math.round(10.80 * FPS)}>
        <Audio src={staticFile('sfx_ui_pop.wav')} volume={0.42} />
      </Sequence>
      <Sequence from={Math.round(15.25 * FPS)}>
        <Audio src={staticFile('sfx_ui_pop.wav')} volume={0.42} />
      </Sequence>
      <Sequence from={Math.round(18.40 * FPS)}>
        <Audio src={staticFile('sfx_ui_pop.wav')} volume={0.42} />
      </Sequence>
      <Sequence from={Math.round(50.4 * FPS)}>
        <Audio src={staticFile('sfx_ui_pop.wav')} volume={0.45} />
      </Sequence>

      {/* 3. Tape Stop at Silence */}
      <Sequence from={Math.round(30.6 * FPS)}>
        <Audio src={staticFile('sfx_tape_stop.wav')} volume={0.45} />
      </Sequence>

      {/* 4. Sub Bass Booms */}
      <Sequence from={Math.round(41.0 * FPS)}>
        <Audio src={staticFile('sfx_sub_boom.wav')} volume={0.58} />
      </Sequence>
      <Sequence from={Math.round(52.7 * FPS)}>
        <Audio src={staticFile('sfx_sub_boom.wav')} volume={0.78} />
      </Sequence>
    </>
  );
};

export const VideoEN: React.FC = () => {
  const frame = useCurrentFrame();
  const END = 52.6;
  const audioData = useAudioData(staticFile(VOICEOVER_FILE || 'mariya_voiceover_en.wav'));

  const signoff = "I'm *Mariya*, and this is";

  return (
    <AbsoluteFill style={{backgroundColor: COLORS.bg1}}>
      <style>{`
        @font-face {
          font-family: 'Cairo';
          font-style: normal;
          font-weight: 700 900;
          font-display: swap;
          src: url('${staticFile('fonts/cairo-latin.woff2')}') format('woff2');
          unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
        }
      `}</style>

      <Backdrop />

      <ThreeCanvas
        width={WIDTH}
        height={HEIGHT}
        camera={{position: [0, 0, 11], fov: 48}}
        style={{position: 'absolute', inset: 0}}
      >
        <Scene3D audioData={audioData} tConfig={T} toolsConfig={TOOLS_EN} />
      </ThreeCanvas>

      <Vignette />

      {/* 0–5.4s HOOK */}
      {HOOK_EN.map((p, i) => (
        <PhraseEN key={`h_en_${i}`} {...p} />
      ))}

      {/* 5.2–22.4s TOOLS */}
      {TOOLS_EN.map((tool, i) => (
        <ToolCardEN key={`tool_en_${tool.name}`} {...tool} index={i} total={TOOLS_EN.length} />
      ))}

      {/* 22.3–37.0s PIVOT */}
      {PIVOT_EN.map((p, i) => (
        <PhraseEN key={`p_en_${i}`} {...p} />
      ))}

      {/* 37.0–48.0s THESIS */}
      {THESIS_EN.map((p, i) => (
        <PhraseEN key={`t_en_${i}`} {...p} />
      ))}

      {/* 48–53s SIGN-OFF */}
      <PhraseEN at={SIGNOFF_AT} until={END} y={-200} size={54} weight={700} color={COLORS.white} text={signoff} />
      <PhraseEN at={LOGO_AT} until={END} y={-80} size={130} text={`HARFEN W *LAKEN*`} />
      <PhraseEN
        at={TAGLINE_AT}
        until={END}
        y={40}
        size={46}
        weight={900}
        accentColor="#38BDF8"
        color="#FFFFFF"
        text={`*CREATIVE AI FRONTIER*`}
      />
      <PhraseEN at={TAGLINE_AT + 0.6} until={END} y={110} size={40} weight={700} color="#F8FAFC" text={CHANNEL.tagline} />

      <LogoMorph />

      <Watermark />
      <Progress />

      <SoundDesign />

      {VOICEOVER_FILE ? <Audio src={staticFile(VOICEOVER_FILE)} volume={1.0} /> : null}
      <Audio
        src={staticFile('bg_music.wav')}
        volume={(f) => {
          const t = f / FPS;
          if (t >= 30.6 && t <= 33.1) {
            return 0.58;
          }
          if (t > 33.1 && t <= 33.4) {
            return interpolate(t, [33.1, 33.4], [0.58, 0.28], {
              extrapolateLeft: 'clamp',
              extrapolateRight: 'clamp',
            });
          }
          if (t < 50.0) {
            return 0.28;
          }
          if (t >= 50.0 && t <= 53.6) {
            return interpolate(t, [50.0, 51.5], [0.28, 0.68], {extrapolateRight: 'clamp'});
          }
          return interpolate(t, [53.6, 55.0], [0.68, 0.0], {
            extrapolateLeft: 'clamp',
            extrapolateRight: 'clamp',
            easing: Easing.out(Easing.cubic),
          });
        }}
      />
    </AbsoluteFill>
  );
};

