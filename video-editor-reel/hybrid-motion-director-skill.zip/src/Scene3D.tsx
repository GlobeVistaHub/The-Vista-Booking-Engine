import React, {useMemo} from 'react';
import {Easing, interpolate, random, useCurrentFrame} from 'remotion';
import {useThree} from '@react-three/fiber';
import * as THREE from 'three';
import {visualizeAudio, AudioData} from '@remotion/media-utils';
import {COLORS, FPS, T, TOOLS} from './config';

export interface SceneConfigType {
  T: any;
  TOOLS: any;
}

const SceneConfigContext = React.createContext<SceneConfigType>({
  T,
  TOOLS,
});

export const useSceneConfig = () => React.useContext(SceneConfigContext);

// 0 → 1 → 0 visibility window in seconds, eased.
const vis = (t: number, a: number, b: number, fade = 0.7) =>
  interpolate(t, [a, a + fade, b - fade, b], [0, 1, 1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.inOut(Easing.cubic),
  });

const useT = () => {
  const frame = useCurrentFrame();
  return {frame, t: frame / FPS};
};

// Studio Lighting Rig — Gives rich 3D specular depth, rim highlights, and reflections.
const Lighting: React.FC = () => {
  return (
    <>
      <ambientLight intensity={0.7} />
      {/* Key Light */}
      <directionalLight position={[6, 8, 8]} intensity={2.2} color="#FFFFFF" />
      {/* Cyan Rim Light */}
      <pointLight position={[-9, 2, 4]} intensity={3.5} distance={30} color={COLORS.blue} />
      {/* Warm Amber Rim Light */}
      <pointLight position={[9, 3, 4]} intensity={3.8} distance={30} color={COLORS.yellow} />
      {/* Deep Under-Rim Backlight */}
      <directionalLight position={[0, -6, -5]} intensity={1.2} color="#38BDF8" />
    </>
  );
};

// Slow cinematic camera drift.
const CameraRig: React.FC = () => {
  const {t} = useT();
  const camera = useThree((s) => s.camera);
  camera.position.x = Math.sin(t * 0.35) * 0.45;
  camera.position.y = Math.cos(t * 0.27) * 0.25;
  camera.position.z = 10.5 - t * 0.015;
  camera.lookAt(0, 0, 0);
  return null;
};

// Floating ambient depth dust.
const Particles: React.FC = () => {
  const {frame} = useT();
  const N = 650;
  const positions = useMemo(() => {
    const arr = new Float32Array(N * 3);
    for (let i = 0; i < N; i++) {
      arr[i * 3] = (random(`x${i}`) - 0.5) * 36;
      arr[i * 3 + 1] = (random(`y${i}`) - 0.5) * 22;
      arr[i * 3 + 2] = -random(`z${i}`) * 26 + 4;
    }
    return arr;
  }, []);
  return (
    <points rotation={[0, frame * 0.0012, 0]} position={[0, -frame * 0.0005, 0]}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" count={N} array={positions} itemSize={3} args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial
        color={COLORS.blue}
        size={0.065}
        transparent
        opacity={0.65}
        sizeAttenuation
        depthWrite={false}
      />
    </points>
  );
};

// HOOK + OUTRO — Luxury Volumetric Orb (Frosted Glass Outer Shell + Luminous Nucleus).
const Core: React.FC = () => {
  const {frame, t} = useT();
  const {T} = useSceneConfig();
  const hook = vis(t, T.hook[0] - 1, T.hook[1] + 0.4, 0.9);
  const out = vis(t, T.outro[0], T.outro[1] + 1, 1.2);
  const v = Math.max(hook, out);
  if (v < 0.01) return null;
  const morphOut = interpolate(t, [52.8, 53.3], [1, 0.05], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.in(Easing.cubic),
  });
  const s = (hook > out ? 2.8 : 1.5) * (0.6 + 0.4 * v) * (out > 0.01 ? morphOut : 1);
  return (
    <group scale={s} rotation={[frame * 0.006, frame * 0.009, 0]}>
      {/* Outer Frosted Glass Sphere */}
      <mesh>
        <sphereGeometry args={[1.1, 36, 36]} />
        <meshPhysicalMaterial
          color={COLORS.blue}
          roughness={0.15}
          metalness={0.1}
          transmission={0.82}
          thickness={1.4}
          ior={1.45}
          transparent
          opacity={0.85 * v}
        />
      </mesh>
      {/* Delicate Latitude Gimbal Ring */}
      <mesh rotation={[frame * 0.015, 0, frame * 0.01]}>
        <torusGeometry args={[1.35, 0.012, 16, 90]} />
        <meshStandardMaterial
          color={COLORS.blue}
          emissive={COLORS.blue}
          emissiveIntensity={0.6}
          roughness={0.1}
          metalness={0.9}
          transparent
          opacity={0.9 * v}
        />
      </mesh>
      {/* Inner Glowing Crystal Core */}
      <mesh scale={0.52} rotation={[-frame * 0.01, frame * 0.012, 0]}>
        <octahedronGeometry args={[1, 0]} />
        <meshStandardMaterial
          color={COLORS.yellow}
          emissive={COLORS.yellow}
          emissiveIntensity={0.65}
          flatShading
          roughness={0.15}
          metalness={0.6}
          transparent
          opacity={0.95 * v}
        />
      </mesh>
    </group>
  );
};

// TOOLS — 4 Orbiting Satellites with Specular Highlights.
const Orbit: React.FC = () => {
  const {frame, t} = useT();
  const {T, TOOLS} = useSceneConfig();
  const v = vis(t, T.tools[0], T.tools[1], 0.8);
  if (v < 0.01) return null;
  const active = TOOLS.findIndex((tool: any) => t >= tool.at && t < tool.until);
  const R = 5.6;
  return (
    <group scale={0.7 + 0.3 * v} rotation={[0.35, 0, 0]}>
      <mesh rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[R, 0.016, 16, 160]} />
        <meshStandardMaterial
          color={COLORS.blue}
          emissive={COLORS.blue}
          emissiveIntensity={0.4}
          roughness={0.2}
          metalness={0.8}
          transparent
          opacity={0.55 * v}
        />
      </mesh>
      {TOOLS.map((_: any, i: number) => {
        const a = (i / TOOLS.length) * Math.PI * 2 + frame * 0.012;
        const on = i === active;
        const pulse = on ? 1 + 0.22 * Math.sin(frame * 0.25) : 1;
        return (
          <group key={i} position={[Math.cos(a) * R, 0, Math.sin(a) * R]}>
            <mesh scale={(on ? 0.36 : 0.22) * pulse}>
              <sphereGeometry args={[1, 32, 32]} />
              <meshStandardMaterial
                color={on ? COLORS.yellow : COLORS.blue}
                emissive={on ? COLORS.yellow : COLORS.blue}
                emissiveIntensity={on ? 0.8 : 0.35}
                roughness={0.15}
                metalness={0.7}
                transparent
                opacity={v}
              />
            </mesh>
            {on && (
              <mesh scale={0.65 * pulse}>
                <sphereGeometry args={[1, 24, 24]} />
                <meshStandardMaterial
                  color={COLORS.yellow}
                  transparent
                  opacity={0.22 * v}
                  roughness={0.1}
                />
              </mesh>
            )}
          </group>
        );
      })}
    </group>
  );
};

// PIVOT — 64-Band Real Audio FFT Waveform.
// Driven directly by Mariya's voiceover stem. Flatlines to true zero during the 30.5s–34.0s silence.
// Stays active through 00:36.70 and completes graceful exit at exactly 00:37.06.
const BARS = 64;
const Waveform: React.FC<{audioData?: AudioData | null}> = ({audioData}) => {
  const {frame, t} = useT();
  const {T} = useSceneConfig();

  // Entrance at 22.3s, holds 100% active through 36.7s, dissolves cleanly to zero at exactly 37.06s
  const enter = interpolate(t, [22.3, 23.1], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.out(Easing.cubic),
  });
  const exit = interpolate(t, [36.7, 37.06], [1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.in(Easing.cubic),
  });
  const v = Math.min(enter, exit);
  if (v < 0.005) return null;

  // Silence Envelope: Drops to zero at silenceStart, recovers smoothly after silenceEnd
  const loud = interpolate(t, [T.silenceStart, T.silenceStart + 0.4], [1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.out(Easing.cubic),
  });
  const back = interpolate(t, [T.silenceEnd, T.silenceEnd + 0.18], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const ampEnvelope = Math.max(loud, back);

  // Real Audio FFT Visualization
  const visualization = audioData
    ? visualizeAudio({
        audioData,
        frame,
        fps: FPS,
        numberOfSamples: 64,
        smoothing: true,
      })
    : null;

  const color = new THREE.Color(COLORS.blue).lerp(
    new THREE.Color(COLORS.yellow),
    1 - ampEnvelope,
  );

  return (
    <group position={[0, -3.45, 0]}>
      {Array.from({length: BARS}).map((_, i) => {
        const x = (i - (BARS - 1) / 2) * 0.28;

        // Map frequency bins symmetrically from center outwards:
        // Center = low-mid vocal fundamentals, Wings = upper harmonics and sibilants
        const center = (BARS - 1) / 2;
        const distFromCenter = Math.abs(i - center);
        const normDist = distFromCenter / center; // 0 (center) to 1 (wings)
        const binIndex = Math.min(63, Math.floor(normDist * 52));

        const rawSample = visualization ? visualization[binIndex] : 0;

        // Perceptual boost for vocal range
        const voiceBoost = 1.0 + (1 - normDist) * 2.2;
        const dynamicHeight = rawSample * 7.5 * voiceBoost;

        // Final height: baseline of 0.06 + real FFT audio amplitude multiplied by silence envelope
        const h = Math.max(0.06, 0.06 + dynamicHeight * ampEnvelope * v);

        return (
          <mesh key={i} position={[x, 0, 0]} scale={[1, h, 1]}>
            <boxGeometry args={[0.12, 1, 0.12]} />
            <meshStandardMaterial
              color={color}
              emissive={color}
              emissiveIntensity={0.5}
              roughness={0.2}
              metalness={0.8}
              transparent
              opacity={0.92 * v}
            />
          </mesh>
        );
      })}
    </group>
  );
};

// THESIS — The AI Sphere & The Human Editor Prism.
// They orbit and switch roles on the centered 3D halo stage, then fuse into a symbiotic entity at 41.0s.
const Merge: React.FC = () => {
  const {frame, t} = useT();
  const {T} = useSceneConfig();
  const v = vis(t, T.thesis[0], T.thesis[1], 0.8);
  if (v < 0.01) return null;

  // Approach and role-switch interpolation (37.5s -> 41.0s)
  const k = interpolate(t, [T.thesis[0] + 0.4, T.merge], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.inOut(Easing.cubic),
  });

  // Orbital positions: Both shapes glide towards center while performing a 3D Z-depth pirouette
  // Blue AI moves from Left (-5.2) -> Center (0)
  // Amber Human moves from Right (+5.2) -> Center (0)
  const distance = 5.2 * (1 - k);
  const orbitalPhase = k * Math.PI; // 0 to 180 degrees
  const zDepth = Math.sin(orbitalPhase) * 0.85;

  const bluePos: [number, number, number] = [-distance * Math.cos(orbitalPhase * 0.3), 0, zDepth];
  const amberPos: [number, number, number] = [distance * Math.cos(orbitalPhase * 0.3), 0, -zDepth];

  // Post-merge state (41.0s onwards)
  const isMerged = t >= T.merge;
  const burst = interpolate(t, [T.merge, T.merge + 0.35, T.merge + 1.2], [0, 1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const shockwaveScale = interpolate(burst, [0, 1], [0.9, 3.2]);
  const shockwaveOpacity = burst * 0.85 * v;

  const s = (1.0 + burst * 0.35) * (0.7 + 0.3 * v);

  return (
    <group position={[0, 2.7, 0]} scale={s}>
      {/* 1. Centered 3D Backdrop Halo Stage — Physically centered with the shapes */}
      <mesh position={[0, 0, -1.0]} rotation={[0.22, 0, 0]} scale={[1.75, 0.85, 1]}>
        <torusGeometry args={[3.2, 0.018, 16, 120]} />
        <meshStandardMaterial
          color={COLORS.blue}
          emissive={COLORS.blue}
          emissiveIntensity={0.7}
          roughness={0.2}
          metalness={0.8}
          transparent
          opacity={0.45 * v}
        />
      </mesh>
      {/* Centered Point Backlight */}
      <pointLight position={[0, 0, -1.2]} intensity={3.0 * v} distance={10} color="#38BDF8" />

      {/* 2. Shape 1: Blue AI Core (Frosted Glass Translucent Sphere) */}
      <group position={isMerged ? [0, 0, 0] : bluePos} rotation={[frame * 0.008, frame * 0.012, 0]}>
        {/* Outer Glass Shell */}
        <mesh>
          <sphereGeometry args={[1.25, 36, 36]} />
          <meshPhysicalMaterial
            color={COLORS.blue}
            roughness={0.12}
            metalness={0.15}
            transmission={0.82}
            thickness={1.5}
            ior={1.48}
            transparent
            opacity={0.88 * v}
          />
        </mesh>
        {/* Sleek Orbit Ring */}
        <mesh rotation={[Math.PI / 4, frame * 0.015, 0]}>
          <torusGeometry args={[1.45, 0.012, 16, 80]} />
          <meshStandardMaterial
            color={COLORS.blue}
            emissive={COLORS.blue}
            emissiveIntensity={0.6}
            metalness={0.9}
            roughness={0.1}
            transparent
            opacity={0.75 * v}
          />
        </mesh>
      </group>

      {/* 3. Shape 2: Amber Human Prism (Faceted Specular Crystal) */}
      {/* Before merge: orbits on the right and slips into Z-depth */}
      {/* After merge: smoothly docks INSIDE the translucent blue glass sphere, glowing from within! */}
      <group
        position={isMerged ? [0, 0, 0] : amberPos}
        rotation={[frame * 0.014, -frame * 0.018, frame * 0.01]}
        scale={isMerged ? 0.68 : 1.0}
      >
        <mesh>
          <octahedronGeometry args={[1.05, 0]} />
          <meshStandardMaterial
            color={COLORS.yellow}
            emissive="#D97706"
            emissiveIntensity={isMerged ? 1.6 : 0.45}
            flatShading
            roughness={0.15}
            metalness={0.65}
            transparent
            opacity={0.95 * v}
          />
        </mesh>
        {/* Glowing Amber Nucleus */}
        <mesh scale={0.48}>
          <sphereGeometry args={[1, 24, 24]} />
          <meshBasicMaterial color="#FEF08A" />
        </mesh>
      </group>

      {/* 4. Radiant Laser Energy Shockwave on Convergence (41.0s) */}
      {shockwaveOpacity > 0.01 && (
        <mesh rotation={[0.22, 0, 0]} scale={shockwaveScale}>
          <ringGeometry args={[1.3, 1.35, 64]} />
          <meshBasicMaterial
            color={COLORS.yellow}
            transparent
            opacity={shockwaveOpacity}
            side={THREE.DoubleSide}
          />
        </mesh>
      )}

      {/* 5. Post-Merge Symbiotic Gyro Rings (Unified Superhuman Creator) */}
      {isMerged && (
        <group rotation={[frame * 0.01, frame * 0.015, 0]} scale={1.0}>
          <mesh rotation={[Math.PI / 3, 0, 0]}>
            <torusGeometry args={[1.65, 0.012, 16, 90]} />
            <meshStandardMaterial
              color={COLORS.yellow}
              emissive={COLORS.yellow}
              emissiveIntensity={0.6}
              metalness={0.9}
              roughness={0.1}
              transparent
              opacity={0.8 * v}
            />
          </mesh>
        </group>
      )}
    </group>
  );
};

// OUTRO — Gyroscope rings orbiting the final brand mark.
const Rings: React.FC = () => {
  const {frame, t} = useT();
  const {T} = useSceneConfig();
  const v = vis(t, T.outro[0] + 0.3, T.outro[1] + 1, 1.2);
  if (v < 0.01) return null;

  const morphOut = interpolate(t, [52.8, 53.3], [1, 0.05], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.in(Easing.cubic),
  });
  const spinBoost = interpolate(t, [52.0, 53.2], [1, 3.5], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  return (
    <group scale={(0.6 + 0.4 * v) * morphOut}>
      {[0, 1, 2].map((i) => (
        <mesh
          key={i}
          rotation={[frame * 0.004 * (i + 1) * spinBoost + i, frame * 0.006 * spinBoost - i, i * 1.1]}
        >
          <torusGeometry args={[4.4 + i * 0.9, 0.014, 16, 200]} />
          <meshStandardMaterial
            color={i === 1 ? COLORS.yellow : COLORS.blue}
            emissive={i === 1 ? COLORS.yellow : COLORS.blue}
            emissiveIntensity={0.4}
            roughness={0.15}
            metalness={0.85}
            transparent
            opacity={(0.6 - i * 0.12) * v * morphOut}
          />
        </mesh>
      ))}
    </group>
  );
};

export interface Scene3DProps {
  audioData?: AudioData | null;
  tConfig?: any;
  toolsConfig?: any;
}

export const Scene3D: React.FC<Scene3DProps> = ({
  audioData,
  tConfig = T,
  toolsConfig = TOOLS,
}) => {
  const contextValue = useMemo(
    () => ({
      T: tConfig,
      TOOLS: toolsConfig,
    }),
    [tConfig, toolsConfig],
  );

  return (
    <SceneConfigContext.Provider value={contextValue}>
      <Lighting />
      <CameraRig />
      <Particles />
      <Core />
      <Orbit />
      <Waveform audioData={audioData} />
      <Merge />
      <Rings />
    </SceneConfigContext.Provider>
  );
};
