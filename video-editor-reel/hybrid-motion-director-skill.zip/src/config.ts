// ─────────────────────────────────────────────────────────────
//  Everything you will want to edit lives in this file:
//  size, colors, the Arabic script and its timing (in seconds).
//  After you record / generate the voice-over, only change the
//  `at` / `until` numbers below so each phrase lands on its beat.
// ─────────────────────────────────────────────────────────────

// Landscape 16:9. For vertical Shorts/Reels use WIDTH = 1080, HEIGHT = 1920
// (the 3D scene and text are laid out relative to the frame, but re-check
// font sizes — see README).
export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;
export const DURATION_S = 55;
export const DURATION_FRAMES = FPS * DURATION_S;

// Put your narration in /public and set its name here, e.g. 'voiceover.mp3'
export const VOICEOVER_FILE: string | null = 'mariya_voiceover.wav';

export const PRESENTER = 'ماريا';

export const CHANNEL = {
  ar: 'حرفين و لكن',
  en: 'HARFEN W LAKEN',
  tagline: 'أخبار الذكاء الاصطناعي بلغتنا',
};

export const COLORS = {
  bg1: '#070B16', // deep charcoal-blue
  bg2: '#0E1A33',
  white: '#F5F7FF',
  blue: '#3D8BFF',
  yellow: '#FFD23F',
  dim: 'rgba(245,247,255,0.55)',
};

export const sec = (s: number) => Math.round(s * FPS);

// Scene windows (seconds) — Calibrated to Mariya's Vocal Stems
export const T = {
  hook: [0, 5.4],
  tools: [5.2, 22.4],
  pivot: [22.3, 37.0],
  thesis: [37.0, 48.0],
  outro: [48.0, 55.0],
  // waveform: music/voice fades to nothing, then holds in silence
  silenceStart: 30.5,
  silenceEnd: 34.0,
  // the two ideas in the thesis scene merge here
  merge: 41.0,
} as const;

export type PhraseData = {
  at: number;
  until: number;
  text: string; // wrap highlighted words in *stars*
  y?: number; // vertical offset from center, px
  size?: number;
};

// 0–5.4s  THE HOOK — Apocalypse to Reality Transition
export const HOOK: PhraseData[] = [
  {at: 0.2, until: 5.2, y: -150, size: 100, text: 'المانشيتات بتقول:'},
  {at: 1.68, until: 5.2, y: 0, size: 100, text: '*نهاية عصر المونتيرين!*'},
  {at: 3.8, until: 5.2, y: 150, size: 100, text: '*هل ده بجد؟ تعالوا نشوف.*'},
];

// 5.2–22.4s  THE TOOLS — builds credibility (Calibrated to voice beats)
export const TOOLS = [
  {name: 'Opus Clip', desc: 'بيحوّل الفيديو الطويل لريلز في ثواني', at: 5.6, until: 9.7},
  {name: 'CapCut', desc: 'تفريغ وترجمة فورية لكل كلمة بتتقال', at: 10.1, until: 13.5},
  {name: 'Premiere Pro', desc: 'جينيراتيف فيل بيملا الكادر بضغطة زر', at: 13.9, until: 17.3},
  {name: 'Kling', desc: 'مشاهد سينمائية كاملة من سطر نص', at: 17.7, until: 22.3},
];

// 22.3–37.0s  THE EMOTIONAL PIVOT — human taste
export const PIVOT: PhraseData[] = [
  {at: 22.6, until: 26.6, y: -90, size: 96, text: 'الذكاء الاصطناعي *يقدر يقطع مشهد*'},
  {at: 24.1, until: 26.6, y: 90, size: 96, text: 'بس *مستحيل يحسه*'},
  {at: 26.8, until: 30.5, y: 0, size: 96, text: 'وميعرفش امتى يسيب *الكادر يتنفس*'},
  // holds through the silence on purpose
  {at: 34.0, until: 37.0, y: 0, size: 96, text: 'حين يكون *الصمت* أقوى من أعلى مزيكا'},
];

// 37.0–48.0s  THE MINDSET SHIFT — the thesis
export const THESIS: PhraseData[] = [
  {at: 37.3, until: 40.8, y: -80, size: 96, text: 'المحررين اللي *هيخسروا*'},
  {at: 39.0, until: 40.8, y: 80, size: 96, text: 'مش قدام *الذكاء الاصطناعي*'},
  {at: 41.0, until: 43.8, y: 0, size: 104, text: 'بل قدام *مونتيرين بيستخدموه*'},
  {at: 44.0, until: 47.8, y: -170, size: 120, text: 'لا تحاربه.'},
  {at: 45.0, until: 47.8, y: 0, size: 120, text: '*اتعلّمه.*'},
  {at: 46.0, until: 47.8, y: 170, size: 120, text: '*استخدمه.*'},
];

// 48.0–53.0s  BRAND SIGN-OFF
export const SIGNOFF_AT = 48.3;
export const LOGO_AT = 49.5;
export const TAGLINE_AT = 50.4;
