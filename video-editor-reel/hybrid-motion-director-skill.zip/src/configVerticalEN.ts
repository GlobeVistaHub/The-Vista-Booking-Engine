// ─────────────────────────────────────────────────────────────
//  HARFEN W LAKEN — ENGLISH VERTICAL 9:16 CONFIGURATION (1080 x 1920)
//  Calibrated for TikTok, Instagram Reels, and YouTube Shorts
//  Strict mobile safe zones (Y: 280px to 1540px)
// ─────────────────────────────────────────────────────────────

import {
  FPS,
  DURATION_S,
  DURATION_FRAMES,
  VOICEOVER_FILE,
  PRESENTER,
  CHANNEL,
  COLORS,
  T,
  sec,
  TOOLS_EN,
  PhraseData
} from './configEN';

export {
  FPS,
  DURATION_S,
  DURATION_FRAMES,
  VOICEOVER_FILE,
  PRESENTER,
  CHANNEL,
  COLORS,
  T,
  sec
};

export const WIDTH_V = 1080;
export const HEIGHT_V = 1920;

// 0–6.2s THE HOOK — Precision-calibrated for 9:16 mobile portrait (00:05.13 = Frame 163)
export const HOOK_V_EN: PhraseData[] = [
  {at: 0.20, until: 6.25, y: -250, size: 68, text: 'Headlines are screaming:'},
  {at: 2.20, until: 6.25, y: -90, size: 82, text: '*The Death of Video Editors!*'},
  {at: 3.88, until: 6.25, y: 50, size: 66, text: '*Is it real?*'},
  {at: 163 / 30, until: 6.25, y: 180, size: 78, text: '*Let\'s find out.*'},
];

// 6.67–22.4s THE TOOLS — Vertical layout (Opus Clip @ 00:06.20 = Frame 200)
export const TOOLS_V_EN = TOOLS_EN;

// 22.3–37.0s THE EMOTIONAL PIVOT — Mobile scannable text (00:28.02 = Frame 842)
export const PIVOT_V_EN: PhraseData[] = [
  {at: 23.0, until: 26.8, y: -120, size: 68, text: 'Artificial intelligence *can cut a scene...*'},
  {at: 24.6, until: 26.8, y: 120, size: 76, text: 'but it will *never feel it.*'},
  {at: 842 / 30, until: 30.65, y: 0, size: 72, text: 'And it never knows when to let the *frame breathe.*'},
  // Holds through the silence on purpose
  {at: 33.15, until: 36.8, y: 0, size: 68, text: 'When *silence* is louder than the heaviest music.'},
];

// 37.0–48.0s THE MINDSET SHIFT — The thesis
export const THESIS_V_EN: PhraseData[] = [
  {at: 37.2, until: 40.6, y: -100, size: 70, text: 'The editors who *will lose...*'},
  {at: 38.8, until: 40.6, y: 100, size: 70, text: 'won\'t lose to *artificial intelligence.*'},
  {at: 41.0, until: 43.6, y: 0, size: 76, text: '...they will lose to *editors who master it.*'},
  {at: 43.8, until: 47.8, y: -200, size: 86, text: 'Don\'t fight it.'},
  {at: 44.9, until: 47.8, y: 0, size: 90, text: '*Learn it.*'},
  {at: 46.0, until: 47.8, y: 200, size: 90, text: '*Use it.*'},
];

export const SIGNOFF_AT = 48.3;
export const LOGO_AT = 49.5;
export const TAGLINE_AT = 50.4;
