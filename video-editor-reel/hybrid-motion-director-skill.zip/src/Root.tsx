import React from 'react';
import {Composition} from 'remotion';
import {Video} from './Video';
import {DURATION_FRAMES, FPS, HEIGHT, WIDTH} from './config';
import {VideoVertical} from './VideoVertical';
import {HEIGHT_V, WIDTH_V} from './configVertical';
import {VideoEN} from './VideoEN';
import {VideoVerticalEN} from './VideoVerticalEN';
import {AkkariCommercialAd} from './AkkariCommercialAd';

export const Root: React.FC = () => (
  <>
    <Composition
      id="AkkariCommercialAd"
      component={AkkariCommercialAd}
      durationInFrames={1248}
      fps={30}
      width={1080}
      height={1920}
    />
    {/* Arabic Editions (Untouched Reference Masters) */}
    <Composition
      id="Main"
      component={Video}
      durationInFrames={DURATION_FRAMES}
      fps={FPS}
      width={WIDTH}
      height={HEIGHT}
    />
    <Composition
      id="Vertical"
      component={VideoVertical}
      durationInFrames={DURATION_FRAMES}
      fps={FPS}
      width={WIDTH_V}
      height={HEIGHT_V}
    />
    {/* English Editions (Calibrated LTR Masters) */}
    <Composition
      id="MainEN"
      component={VideoEN}
      durationInFrames={DURATION_FRAMES}
      fps={FPS}
      width={WIDTH}
      height={HEIGHT}
    />
    <Composition
      id="VerticalEN"
      component={VideoVerticalEN}
      durationInFrames={DURATION_FRAMES}
      fps={FPS}
      width={WIDTH_V}
      height={HEIGHT_V}
    />
  </>
);
