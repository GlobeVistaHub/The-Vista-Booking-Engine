import React from 'react';
import {AbsoluteFill, Audio, Easing, Img, interpolate, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {ThreeCanvas} from '@remotion/three';
import {useAudioData} from '@remotion/media-utils';
import {Scene3DVertical} from './Scene3DVertical';
import {PhraseVertical, ToolCardVertical} from './KineticVertical';
import {fontFamily} from './Kinetic';
import {
  CHANNEL,
  COLORS,
  DURATION_FRAMES,
  FPS,
  HEIGHT_V,
  HOOK_V,
  LOGO_AT,
  PIVOT_V,
  PRESENTER,
  SIGNOFF_AT,
  T,
  TAGLINE_AT,
  THESIS_V,
  TOOLS_V,
  VOICEOVER_FILE,
  WIDTH_V,
} from './configVertical';

const BackdropVertical: React.FC = () => (
  <>
    <AbsoluteFill
      style={{
        background: `radial-gradient(ellipse at 50% 40%, ${COLORS.bg2} 0%, ${COLORS.bg1} 75%)`,
      }}
    />
    <AbsoluteFill
      style={{
        opacity: 0.08,
        backgroundImage:
          'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)',
        backgroundSize: '75px 75px',
      }}
    />
  </>
);

const VignetteVertical: React.FC = () => (
  <AbsoluteFill
    style={{
      background: 'radial-gradient(ellipse at center, transparent 45%, rgba(0,0,0,0.65) 100%)',
      pointerEvents: 'none',
    }}
  />
);

const WatermarkVertical: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const o = interpolate(t, [0.5, 1.2, T.outro[0] - 0.3, T.outro[0]], [0, 0.75, 0.75, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  return (
    <div
      dir="rtl"
      style={{
        position: 'absolute',
        top: 130, // Safely below phone status bars / reels icon
        right: 56,
        fontFamily,
        fontWeight: 900,
        fontSize: 32,
        color: COLORS.white,
        opacity: o,
        WebkitFontSmoothing: 'antialiased',
        textRendering: 'optimizeLegibility',
        textShadow: '0 2px 12px rgba(0,0,0,0.9)',
        zIndex: 40,
      }}
    >
      {CHANNEL.ar}
    </div>
  );
};

const ProgressVertical: React.FC = () => {
  const frame = useCurrentFrame();
  const w = interpolate(frame, [0, DURATION_FRAMES], [0, 100]);
  return (
    <div style={{position: 'absolute', left: 0, bottom: 0, width: '100%', height: 10, zIndex: 40}}>
      <div
        style={{
          height: '100%',
          width: `${w}%`,
          background: `linear-gradient(90deg, ${COLORS.blue}, ${COLORS.yellow})`,
        }}
      />
    </div>
  );
};

const LogoMorphVertical: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const startAt = 52.6;
  if (t < startAt) return null;

  const progress = interpolate(t, [startAt, startAt + 0.65], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.out(Easing.back(1.4)),
  });

  const flare = interpolate(t, [startAt, startAt + 0.22, startAt + 0.75], [0, 1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  const sheen = interpolate(t, [startAt + 0.45, startAt + 1.5], [-120, 220], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  return (
    <div
      style={{
        position: 'absolute',
        inset: 0,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        pointerEvents: 'none',
        zIndex: 50,
      }}
    >
      {flare > 0.01 && (
        <div
          style={{
            position: 'absolute',
            width: 950,
            height: 950,
            borderRadius: '50%',
            background:
              'radial-gradient(circle, rgba(255,255,255,0.95) 0%, rgba(61,139,255,0.7) 40%, transparent 70%)',
            opacity: flare,
            transform: `scale(${1 + flare * 0.9})`,
            filter: 'blur(35px)',
          }}
        />
      )}

      {/* Boosted to 500px high-impact luxury medallion */}
      <div
        style={{
          position: 'relative',
          width: 500,
          height: 500,
          borderRadius: '50%',
          overflow: 'hidden',
          transform: `scale(${progress})`,
          opacity: Math.min(1, progress * 2.5),
          boxShadow: `0 0 90px rgba(61, 139, 255, 0.95), 0 0 160px rgba(0, 242, 254, 0.45), 0 35px 85px rgba(0,0,0,0.98)`,
          border: `4px solid ${COLORS.blue}`,
        }}
      >
        <Img
          src={staticFile('harfen_logo.png')}
          style={{
            width: '100%',
            height: '100%',
            objectFit: 'cover',
          }}
        />

        <div
          style={{
            position: 'absolute',
            inset: 0,
            background: `linear-gradient(115deg, transparent 0%, rgba(255,255,255,0.6) 45%, rgba(255,255,255,0.9) 50%, rgba(255,255,255,0.6) 55%, transparent 100%)`,
            transform: `translateX(${sheen}%)`,
            pointerEvents: 'none',
          }}
        />
      </div>
    </div>
  );
};

const SoundDesignVertical: React.FC = () => {
  return (
    <>
      {/* 1. Cinematic Whooshes */}
      <Sequence from={Math.round(0.0 * FPS)}>
        <Audio src={staticFile('sfx_whoosh.wav')} volume={0.35} />
      </Sequence>
      <Sequence from={Math.round(5.0 * FPS)}>
        <Audio src={staticFile('sfx_whoosh.wav')} volume={0.32} />
      </Sequence>
      <Sequence from={Math.round(9.5 * FPS)}>
        <Audio src={staticFile('sfx_whoosh.wav')} volume={0.32} />
      </Sequence>
      <Sequence from={Math.round(13.3 * FPS)}>
        <Audio src={staticFile('sfx_whoosh.wav')} volume={0.32} />
      </Sequence>
      <Sequence from={Math.round(17.1 * FPS)}>
        <Audio src={staticFile('sfx_whoosh.wav')} volume={0.32} />
      </Sequence>
      <Sequence from={Math.round(21.8 * FPS)}>
        <Audio src={staticFile('sfx_whoosh.wav')} volume={0.35} />
      </Sequence>

      {/* 2. UI Pops */}
      <Sequence from={Math.round(5.6 * FPS)}>
        <Audio src={staticFile('sfx_ui_pop.wav')} volume={0.42} />
      </Sequence>
      <Sequence from={Math.round(10.1 * FPS)}>
        <Audio src={staticFile('sfx_ui_pop.wav')} volume={0.42} />
      </Sequence>
      <Sequence from={Math.round(13.9 * FPS)}>
        <Audio src={staticFile('sfx_ui_pop.wav')} volume={0.42} />
      </Sequence>
      <Sequence from={Math.round(17.7 * FPS)}>
        <Audio src={staticFile('sfx_ui_pop.wav')} volume={0.42} />
      </Sequence>
      <Sequence from={Math.round(50.4 * FPS)}>
        <Audio src={staticFile('sfx_ui_pop.wav')} volume={0.45} />
      </Sequence>

      {/* 3. Tape Stop */}
      <Sequence from={Math.round(30.4 * FPS)}>
        <Audio src={staticFile('sfx_tape_stop.wav')} volume={0.45} />
      </Sequence>

      {/* 4. Sub Bass Boom */}
      <Sequence from={Math.round(41.0 * FPS)}>
        <Audio src={staticFile('sfx_sub_boom.wav')} volume={0.58} />
      </Sequence>
      <Sequence from={Math.round(52.7 * FPS)}>
        <Audio src={staticFile('sfx_sub_boom.wav')} volume={0.78} />
      </Sequence>
    </>
  );
};

export const VideoVertical: React.FC = () => {
  const frame = useCurrentFrame();
  const END = 52.6;
  const audioData = useAudioData(staticFile(VOICEOVER_FILE || 'mariya_voiceover.wav'));

  const signoff = PRESENTER
    ? `أنا *${PRESENTER}* وهذه قناة`
    : 'وهذه قناتك للذكاء الاصطناعي';

  return (
    <AbsoluteFill style={{backgroundColor: COLORS.bg1}}>
      {/* Offline Local Font Resilience */}
      <style>{`
        @font-face {
          font-family: 'Cairo';
          font-style: normal;
          font-weight: 700 900;
          font-display: swap;
          src: url('${staticFile('fonts/cairo-arabic.woff2')}') format('woff2');
          unicode-range: U+0600-06FF, U+0750-077F, U+0870-088E, U+0890-0891, U+08A0-08E1, U+08E3-08FF, U+200C-200E, U+2010-2011, U+204F, U+2E41, U+FB50-FDFF, U+FE70-FE74, U+FE76-FEFC;
        }
        @font-face {
          font-family: 'Cairo';
          font-style: normal;
          font-weight: 700 900;
          font-display: swap;
          src: url('${staticFile('fonts/cairo-latin.woff2')}') format('woff2');
          unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
        }
      `}</style>

      <BackdropVertical />

      {/* 3D Visualizer adapted for 9:16 portrait viewport */}
      <ThreeCanvas
        width={WIDTH_V}
        height={HEIGHT_V}
        camera={{position: [0, 0, 15.5], fov: 52}}
        style={{position: 'absolute', inset: 0}}
      >
        <Scene3DVertical audioData={audioData} />
      </ThreeCanvas>

      <VignetteVertical />

      {/* 0–5.4s HOOK */}
      {HOOK_V.map((p, i) => (
        <PhraseVertical key={`h_v_${i}`} {...p} />
      ))}

      {/* 5.2–22.4s TOOLS */}
      {TOOLS_V.map((tool, i) => (
        <ToolCardVertical key={`tool_v_${tool.name}`} {...tool} index={i} total={TOOLS_V.length} />
      ))}

      {/* 22.3–37.0s PIVOT */}
      {PIVOT_V.map((p, i) => (
        <PhraseVertical key={`p_v_${i}`} {...p} />
      ))}

      {/* 37.0–48.0s THESIS */}
      {THESIS_V.map((p, i) => (
        <PhraseVertical key={`t_v_${i}`} {...p} />
      ))}

      {/* 48–53s SIGN-OFF */}
      <PhraseVertical at={SIGNOFF_AT} until={END} y={-330} size={50} weight={700} color={COLORS.white} text={signoff} />
      <PhraseVertical at={LOGO_AT} until={END} y={-135} size={150} text={`حرفين و *لكن*`} />
      <PhraseVertical
        at={TAGLINE_AT}
        until={END}
        y={65}
        size={46}
        weight={900}
        latin
        accentColor="#38BDF8"
        color="#FFFFFF"
        text={`*${CHANNEL.en}*`}
      />
      <PhraseVertical at={TAGLINE_AT + 0.6} until={END} y={155} size={42} weight={700} color="#F8FAFC" text={CHANNEL.tagline} />

      <LogoMorphVertical />

      <WatermarkVertical />
      <ProgressVertical />

      <SoundDesignVertical />

      {VOICEOVER_FILE ? <Audio src={staticFile(VOICEOVER_FILE)} volume={1.0} /> : null}
      <Audio
        src={staticFile('bg_music.wav')}
        volume={(f) => {
          const t = f / FPS;
          if (t >= 30.3 && t <= 34.2) {
            return 0.58;
          }
          if (t < 50.0) {
            return 0.28;
          }
          if (t >= 50.0 && t <= 53.6) {
            return interpolate(t, [50.0, 51.5], [0.28, 0.68], {extrapolateRight: 'clamp'});
          }
          return interpolate(t, [53.6, 55.0], [0.68, 0.0], {
            extrapolateLeft: 'clamp',
            extrapolateRight: 'clamp',
            easing: Easing.out(Easing.cubic),
          });
        }}
      />
    </AbsoluteFill>
  );
};
