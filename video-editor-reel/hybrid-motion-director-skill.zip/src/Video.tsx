import React from 'react';
import {AbsoluteFill, Audio, Easing, Img, interpolate, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {ThreeCanvas} from '@remotion/three';
import {useAudioData} from '@remotion/media-utils';
import {Scene3D} from './Scene3D';
import {Phrase, ToolCard, fontFamily} from './Kinetic';
import {
  CHANNEL,
  COLORS,
  DURATION_FRAMES,
  FPS,
  HEIGHT,
  HOOK,
  LOGO_AT,
  PIVOT,
  PRESENTER,
  SIGNOFF_AT,
  T,
  TAGLINE_AT,
  THESIS,
  TOOLS,
  VOICEOVER_FILE,
  WIDTH,
} from './config';

const Backdrop: React.FC = () => (
  <>
    <AbsoluteFill
      style={{
        background: `radial-gradient(ellipse at 50% 35%, ${COLORS.bg2} 0%, ${COLORS.bg1} 70%)`,
      }}
    />
    {/* faint grid for a "tech" feel */}
    <AbsoluteFill
      style={{
        opacity: 0.07,
        backgroundImage:
          'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)',
        backgroundSize: '90px 90px',
      }}
    />
  </>
);

const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{
      background: 'radial-gradient(ellipse at center, transparent 55%, rgba(0,0,0,0.55) 100%)',
      pointerEvents: 'none',
    }}
  />
);

const Watermark: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const o = interpolate(t, [0.5, 1.2, T.outro[0] - 0.3, T.outro[0]], [0, 0.7, 0.7, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  return (
    <div
      dir="rtl"
      style={{
        position: 'absolute',
        top: 48,
        right: 64,
        fontFamily,
        fontWeight: 900,
        fontSize: 40,
        color: COLORS.white,
        opacity: o,
        WebkitFontSmoothing: 'antialiased',
        textRendering: 'optimizeLegibility',
        WebkitBackfaceVisibility: 'hidden',
        backfaceVisibility: 'hidden',
        textShadow: '0 2px 10px rgba(0,0,0,0.85)',
      }}
    >
      {CHANNEL.ar}
    </div>
  );
};

const Progress: React.FC = () => {
  const frame = useCurrentFrame();
  const w = interpolate(frame, [0, DURATION_FRAMES], [0, 100]);
  return (
    <div style={{position: 'absolute', left: 0, bottom: 0, width: '100%', height: 8}}>
      <div
        style={{
          height: '100%',
          width: `${w}%`,
          background: `linear-gradient(90deg, ${COLORS.blue}, ${COLORS.yellow})`,
        }}
      />
    </div>
  );
};

const LogoMorph: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const startAt = 52.6;
  if (t < startAt) return null;

  // Spring scale entrance
  const progress = interpolate(t, [startAt, startAt + 0.65], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.out(Easing.back(1.4)),
  });

  // Radiant flare on entrance
  const flare = interpolate(t, [startAt, startAt + 0.22, startAt + 0.75], [0, 1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  // Specular sheen sweep across the logo
  const sheen = interpolate(t, [startAt + 0.45, startAt + 1.5], [-120, 220], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  return (
    <div
      style={{
        position: 'absolute',
        inset: 0,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        pointerEvents: 'none',
        zIndex: 50,
      }}
    >
      {/* Central Quantum Flash */}
      {flare > 0.01 && (
        <div
          style={{
            position: 'absolute',
            width: 850,
            height: 850,
            borderRadius: '50%',
            background:
              'radial-gradient(circle, rgba(255,255,255,0.95) 0%, rgba(61,139,255,0.7) 40%, transparent 70%)',
            opacity: flare,
            transform: `scale(${1 + flare * 0.9})`,
            filter: 'blur(35px)',
          }}
        />
      )}

      {/* 3D Circular Medallion Emblem */}
      <div
        style={{
          position: 'relative',
          width: 440,
          height: 440,
          borderRadius: '50%',
          overflow: 'hidden',
          transform: `scale(${progress})`,
          opacity: Math.min(1, progress * 2.5),
          boxShadow: `0 0 70px rgba(61, 139, 255, 0.75), 0 30px 70px rgba(0,0,0,0.95)`,
          border: `4px solid ${COLORS.blue}`,
        }}
      >
        <Img
          src={staticFile('harfen_logo.png')}
          style={{
            width: '100%',
            height: '100%',
            objectFit: 'cover',
          }}
        />

        {/* Diagonal Specular Sheen Sweep */}
        <div
          style={{
            position: 'absolute',
            inset: 0,
            background: `linear-gradient(115deg, transparent 0%, rgba(255,255,255,0.6) 45%, rgba(255,255,255,0.9) 50%, rgba(255,255,255,0.6) 55%, transparent 100%)`,
            transform: `translateX(${sheen}%)`,
            pointerEvents: 'none',
          }}
        />
      </div>
    </div>
  );
};

const SoundDesign: React.FC = () => {
  return (
    <>
      {/* 1. Cinematic Whooshes */}
      {/* Intro Hook */}
      <Sequence from={Math.round(0.0 * FPS)}>
        <Audio src={staticFile('sfx_whoosh.wav')} volume={0.35} />
      </Sequence>
      {/* Tool 1: Opus Clip */}
      <Sequence from={Math.round(5.0 * FPS)}>
        <Audio src={staticFile('sfx_whoosh.wav')} volume={0.32} />
      </Sequence>
      {/* Tool 2: CapCut */}
      <Sequence from={Math.round(9.5 * FPS)}>
        <Audio src={staticFile('sfx_whoosh.wav')} volume={0.32} />
      </Sequence>
      {/* Tool 3: Premiere Pro */}
      <Sequence from={Math.round(13.3 * FPS)}>
        <Audio src={staticFile('sfx_whoosh.wav')} volume={0.32} />
      </Sequence>
      {/* Tool 4: Kling */}
      <Sequence from={Math.round(17.1 * FPS)}>
        <Audio src={staticFile('sfx_whoosh.wav')} volume={0.32} />
      </Sequence>
      {/* Pivot transition */}
      <Sequence from={Math.round(21.8 * FPS)}>
        <Audio src={staticFile('sfx_whoosh.wav')} volume={0.35} />
      </Sequence>

      {/* 2. UI Pops on Card & Title Locks */}
      <Sequence from={Math.round(5.6 * FPS)}>
        <Audio src={staticFile('sfx_ui_pop.wav')} volume={0.42} />
      </Sequence>
      <Sequence from={Math.round(10.1 * FPS)}>
        <Audio src={staticFile('sfx_ui_pop.wav')} volume={0.42} />
      </Sequence>
      <Sequence from={Math.round(13.9 * FPS)}>
        <Audio src={staticFile('sfx_ui_pop.wav')} volume={0.42} />
      </Sequence>
      <Sequence from={Math.round(17.7 * FPS)}>
        <Audio src={staticFile('sfx_ui_pop.wav')} volume={0.42} />
      </Sequence>
      <Sequence from={Math.round(50.4 * FPS)}>
        <Audio src={staticFile('sfx_ui_pop.wav')} volume={0.45} />
      </Sequence>

      {/* 3. Tape Stop — Middle waveform smoothly balanced into silence window */}
      <Sequence from={Math.round(30.4 * FPS)}>
        <Audio src={staticFile('sfx_tape_stop.wav')} volume={0.45} />
      </Sequence>

      {/* 4. Sub Bass Boom — Thesis Fusion & 3D Logo Reveal */}
      {/* Thesis Fusion ("بل قدام مونتيرين بيستخدموه") */}
      <Sequence from={Math.round(41.0 * FPS)}>
        <Audio src={staticFile('sfx_sub_boom.wav')} volume={0.58} />
      </Sequence>
      {/* 3D Harfen Medallion Logo Burst */}
      <Sequence from={Math.round(52.7 * FPS)}>
        <Audio src={staticFile('sfx_sub_boom.wav')} volume={0.78} />
      </Sequence>
    </>
  );
};

export const Video: React.FC = () => {
  const frame = useCurrentFrame();
  const END = 52.6; // Text clears at 52.6s so the logo morph takes center stage

  const audioData = useAudioData(staticFile(VOICEOVER_FILE || 'mariya_voiceover.wav'));

  const signoff = PRESENTER
    ? `أنا *${PRESENTER}* وهذه قناة`
    : 'وهذه قناتك للذكاء الاصطناعي';

  return (
    <AbsoluteFill style={{backgroundColor: COLORS.bg1}}>
      <Backdrop />

      <ThreeCanvas
        width={WIDTH}
        height={HEIGHT}
        camera={{position: [0, 0, 10.5], fov: 50}}
        style={{position: 'absolute', inset: 0}}
      >
        <Scene3D audioData={audioData} />
      </ThreeCanvas>

      <Vignette />

      {/* 0–3s hook */}
      {HOOK.map((p, i) => (
        <Phrase key={`h${i}`} {...p} />
      ))}

      {/* 3–18s tools */}
      {TOOLS.map((tool, i) => (
        <ToolCard key={tool.name} {...tool} index={i} total={TOOLS.length} />
      ))}

      {/* 18–35s pivot */}
      {PIVOT.map((p, i) => (
        <Phrase key={`p${i}`} {...p} />
      ))}

      {/* 35–45s thesis */}
      {THESIS.map((p, i) => (
        <Phrase key={`t${i}`} {...p} />
      ))}

      {/* 45–53s sign-off */}
      <Phrase at={SIGNOFF_AT} until={END} y={-250} size={64} weight={700} color={COLORS.white} text={signoff} />
      <Phrase at={LOGO_AT} until={END} y={-40} size={210} text={`حرفين و *لكن*`} />
      <Phrase
        at={TAGLINE_AT}
        until={END}
        y={150}
        size={34}
        weight={700}
        latin
        accentColor={COLORS.blue}
        text={`*${CHANNEL.en}*`}
      />
      <Phrase at={TAGLINE_AT + 0.6} until={END} y={240} size={46} weight={700} color={COLORS.white} text={CHANNEL.tagline} />

      <LogoMorph />

      <Watermark />
      <Progress />

      <SoundDesign />

      {VOICEOVER_FILE ? <Audio src={staticFile(VOICEOVER_FILE)} volume={1.0} /> : null}
      <Audio
        src={staticFile('bg_music.wav')}
        volume={(f) => {
          const t = f / FPS;
          // During Mariya's silence window (30.5s - 34.0s), the melancholy violin swells to center stage
          if (t >= 30.3 && t <= 34.2) {
            return 0.58;
          }
          // While Mariya is speaking (0 to 50s)
          if (t < 50.0) {
            return 0.28;
          }
          // Outro & Logo Morph swell (50.0s -> 53.6s)
          if (t >= 50.0 && t <= 53.6) {
            return interpolate(t, [50.0, 51.5], [0.28, 0.68], {extrapolateRight: 'clamp'});
          }
          // Gentle, non-steep organic fade on the final resolve (53.6s -> 55.0s)
          return interpolate(t, [53.6, 55.0], [0.68, 0.0], {
            extrapolateLeft: 'clamp',
            extrapolateRight: 'clamp',
            easing: Easing.out(Easing.cubic),
          });
        }}
      />
    </AbsoluteFill>
  );
};
