import React from 'react';
import {Easing, interpolate, useCurrentFrame} from 'remotion';
import {fontFamily} from './Kinetic';
import {COLORS, FPS} from './config';

// Smooth "expo-out" curve — fast start, long soft landing (no linear snaps or jitter).
const easeOut = Easing.bezier(0.16, 1, 0.3, 1);
const easeIn = Easing.bezier(0.5, 0, 0.9, 0.4);

type Word = {t: string; accent: boolean};

const parse = (text: string): Word[] =>
  text
    .split('*')
    .flatMap((seg, i) =>
      seg
        .split(/\s+/)
        .filter(Boolean)
        .map((t) => ({t, accent: i % 2 === 1})),
    );

type PhraseProps = {
  at: number;
  until: number;
  text: string;
  y?: number;
  size?: number;
  accentColor?: string;
  latin?: boolean;
  weight?: 700 | 900;
  color?: string;
};

export const PhraseVertical: React.FC<PhraseProps> = ({
  at,
  until,
  text,
  y = 0,
  size = 72,
  accentColor = COLORS.yellow,
  latin = false,
  weight = 900,
  color = COLORS.white,
}) => {
  const frame = useCurrentFrame();
  const f0 = at * FPS;
  const f1 = until * FPS;
  if (frame < f0 - 1 || frame > f1 + 16) return null;

  const exit = interpolate(frame, [f1, f1 + 12], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: easeIn,
  });
  const words = parse(text);

  return (
    <div
      style={{
        position: 'absolute',
        inset: 0,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '0 64px',
        transform: `translate3d(0, ${y - exit * 36}px, 0)`,
        opacity: 1 - exit,
        willChange: 'transform, opacity',
        WebkitBackfaceVisibility: 'hidden',
        backfaceVisibility: 'hidden',
      }}
    >
      <div
        dir={latin ? 'ltr' : 'rtl'}
        style={{
          display: 'flex',
          flexWrap: 'wrap',
          justifyContent: 'center',
          gap: `0 ${size * 0.24}px`,
          fontFamily,
          fontWeight: weight,
          fontSize: size,
          lineHeight: 1.35,
          letterSpacing: latin ? '0.28em' : 0,
          textAlign: 'center',
          color,
          WebkitFontSmoothing: 'antialiased',
          textRendering: 'optimizeLegibility',
          WebkitBackfaceVisibility: 'hidden',
          backfaceVisibility: 'hidden',
          textShadow: '0 4px 24px rgba(0,0,0,0.95)',
        }}
      >
        {words.map((w, i) => {
          // Staggered word entrance with smooth exponent decay & soft optical blur
          const p = interpolate(frame, [f0 + i * 3, f0 + i * 3 + 18], [0, 1], {
            extrapolateLeft: 'clamp',
            extrapolateRight: 'clamp',
            easing: easeOut,
          });
          const isDone = p >= 1;
          const ty = (1 - p) * 52;
          const sc = 0.92 + p * 0.08;
          const blurVal = (1 - p) * 12;

          return (
            <span
              key={`${w.t}-${i}`}
              style={{
                display: 'inline-block',
                opacity: p,
                transform: isDone
                  ? 'translate3d(0, 0, 0)'
                  : `translate3d(0, ${ty}px, 0) scale(${sc})`,
                filter: isDone || blurVal < 0.15 ? 'none' : `blur(${blurVal}px)`,
                willChange: isDone ? 'auto' : 'transform, opacity, filter',
                WebkitBackfaceVisibility: 'hidden',
                backfaceVisibility: 'hidden',
                transformOrigin: 'center center',
                color: w.accent ? accentColor : color,
                textShadow: w.accent
                  ? `0 0 38px ${accentColor}66, 0 3px 14px rgba(0,0,0,0.95)`
                  : '0 3px 14px rgba(0,0,0,0.9), 0 1px 3px rgba(0,0,0,0.95)',
              }}
            >
              {w.t}
            </span>
          );
        })}
      </div>
    </div>
  );
};

// Rich SVGs with authentic brand styling from the master horizontal version
const renderToolLogo = (name: string, size = 150) => {
  switch (name) {
    case 'Opus Clip':
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" fill="none">
          <defs>
            <linearGradient id="opusGradV" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
              <stop stopColor="#FFD23F" />
              <stop offset="0.5" stopColor="#FF7A00" />
              <stop offset="1" stopColor="#3D8BFF" />
            </linearGradient>
            <filter id="opusGlowV" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="4" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>
          <rect width="100" height="100" rx="26" fill="#0C1428" stroke="rgba(255,210,63,0.4)" strokeWidth="2.5" />
          <g filter="url(#opusGlowV)">
            <path
              d="M32 30 C32 24, 46 22, 58 28 C70 34, 74 48, 68 60 C62 72, 48 78, 38 72 C28 66, 24 52, 30 40 C34 32, 44 30, 52 34 C60 38, 62 48, 58 54 C54 60, 46 62, 42 58"
              stroke="url(#opusGradV)"
              strokeWidth="9"
              strokeLinecap="round"
              fill="none"
            />
          </g>
        </svg>
      );
    case 'CapCut':
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" fill="none">
          <defs>
            <filter id="ccGlowV" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="4" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>
          <rect width="100" height="100" rx="26" fill="#070B16" stroke="rgba(61,139,255,0.45)" strokeWidth="2.5" />
          <g filter="url(#ccGlowV)">
            <path d="M22 36 L48 24 L78 39 L52 51 Z" fill="#FFFFFF" />
            <path d="M22 64 L48 76 L78 61 L52 49 Z" fill="#3D8BFF" />
          </g>
        </svg>
      );
    case 'Premiere Pro':
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" fill="none">
          <defs>
            <linearGradient id="prGradV" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
              <stop stopColor="#1B0A33" />
              <stop offset="1" stopColor="#07031A" />
            </linearGradient>
            <filter id="prGlowV" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="4" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>
          <rect width="100" height="100" rx="24" fill="url(#prGradV)" stroke="#9999FF" strokeWidth="3" />
          <g filter="url(#prGlowV)">
            <path d="M30 72 V28 H46 C54 28 60 33 60 41 C60 49 54 54 46 54 H38 V72 H30 Z M38 46 H45 C49 46 52 44 52 41 C52 38 49 36 45 36 H38 V46 Z" fill="#E685FF" />
            <path d="M64 72 V43 H71 V48 C73 44 77 42 81 42 V50 C76 50 72 53 72 58 V72 H64 Z" fill="#9999FF" />
          </g>
        </svg>
      );
    case 'Kling':
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" fill="none">
          <defs>
            <linearGradient id="klingGradV" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
              <stop stopColor="#FFD23F" />
              <stop offset="0.5" stopColor="#00F2FE" />
              <stop offset="1" stopColor="#3D8BFF" />
            </linearGradient>
            <filter id="klingGlowV" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="5" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>
          <rect width="100" height="100" rx="26" fill="#0A0F1E" stroke="rgba(255,210,63,0.4)" strokeWidth="2.5" />
          <g filter="url(#klingGlowV)">
            <path d="M50 16 L56 42 L82 48 L56 54 L50 80 L44 54 L18 48 L44 42 Z" fill="url(#klingGradV)" />
            <circle cx="50" cy="48" r="5" fill="#FFFFFF" />
          </g>
        </svg>
      );
    default:
      return null;
  }
};

type ToolCardVerticalProps = {
  name: string;
  desc: string;
  at: number;
  until: number;
  index: number;
  total: number;
};

export const ToolCardVertical: React.FC<ToolCardVerticalProps> = ({name, desc, at, until, index, total}) => {
  const frame = useCurrentFrame();
  const f0 = at * FPS;
  const f1 = until * FPS;
  if (frame < f0 - 1 || frame > f1 + 16) return null;

  const enter = interpolate(frame, [f0, f0 + 22], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: easeOut,
  });
  const exit = interpolate(frame, [f1, f1 + 12], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: easeIn,
  });
  const descIn = interpolate(frame, [f0 + 10, f0 + 30], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: easeOut,
  });
  const underline = interpolate(frame, [f0 + 6, f0 + 28], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: easeOut,
  });

  const isEnterDone = enter >= 1;
  const isDescDone = descIn >= 1;

  return (
    <div
      style={{
        position: 'absolute',
        inset: 0,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '0 48px',
        opacity: (1 - exit) * enter,
        transform: isEnterDone && exit === 0
          ? 'translate3d(0, 0, 0)'
          : `translate3d(${(1 - enter) * 120 - exit * 90}px, 0, 0)`,
        willChange: isEnterDone && exit === 0 ? 'auto' : 'transform, opacity',
        WebkitBackfaceVisibility: 'hidden',
        backfaceVisibility: 'hidden',
      }}
    >
      <div
        style={{
          textAlign: 'center',
          fontFamily,
          maxWidth: '100%',
          WebkitFontSmoothing: 'antialiased',
          textRendering: 'optimizeLegibility',
          WebkitBackfaceVisibility: 'hidden',
          backfaceVisibility: 'hidden',
        }}
      >
        {/* Step Badge */}
        <div
          dir="ltr"
          style={{
            fontSize: 28,
            fontWeight: 700,
            letterSpacing: '0.3em',
            color: COLORS.blue,
            marginBottom: 20,
            textShadow: '0 2px 10px rgba(0,0,0,0.85)',
          }}
        >
          {String(index + 1).padStart(2, '0')} / {String(total).padStart(2, '0')}
        </div>

        {/* SVG Brand Mark */}
        <div
          style={{
            display: 'flex',
            justifyContent: 'center',
            marginBottom: 24,
            transform: isEnterDone ? 'scale(1)' : `scale(${0.8 + enter * 0.2})`,
            opacity: enter,
            WebkitBackfaceVisibility: 'hidden',
            backfaceVisibility: 'hidden',
          }}
        >
          {renderToolLogo(name, 150)}
        </div>

        {/* Tool Name */}
        <div
          dir="ltr"
          style={{
            fontSize: 96,
            fontWeight: 900,
            lineHeight: 1.1,
            color: COLORS.yellow,
            textShadow: `0 0 50px ${COLORS.yellow}55, 0 3px 20px rgba(0,0,0,0.9)`,
            WebkitBackfaceVisibility: 'hidden',
            backfaceVisibility: 'hidden',
          }}
        >
          {name}
        </div>

        {/* Neon Gradient Underline */}
        <div
          style={{
            height: 6,
            borderRadius: 3,
            margin: '20px auto 28px',
            width: 360 * underline,
            background: `linear-gradient(90deg, ${COLORS.blue}, ${COLORS.yellow})`,
            boxShadow: `0 0 16px ${COLORS.blue}88`,
          }}
        />

        {/* Description */}
        <div
          dir="rtl"
          style={{
            fontSize: 46,
            fontWeight: 700,
            lineHeight: 1.45,
            color: COLORS.white,
            marginTop: 260,
            opacity: descIn,
            transform: isDescDone
              ? 'translate3d(0, 0, 0)'
              : `translate3d(0, ${(1 - descIn) * 30}px, 0)`,
            willChange: isDescDone ? 'auto' : 'transform, opacity',
            textShadow: '0 3px 14px rgba(0,0,0,0.95), 0 1px 3px rgba(0,0,0,0.98)',
            WebkitBackfaceVisibility: 'hidden',
            backfaceVisibility: 'hidden',
          }}
        >
          {desc}
        </div>
      </div>
    </div>
  );
};
