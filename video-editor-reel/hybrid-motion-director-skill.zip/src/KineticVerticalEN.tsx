import React from 'react';
import {Easing, interpolate, useCurrentFrame} from 'remotion';
import {fontFamily, renderToolLogo} from './Kinetic';
import {COLORS, FPS} from './configEN';

const easeOut = Easing.bezier(0.16, 1, 0.3, 1);
const easeIn = Easing.bezier(0.5, 0, 0.9, 0.4);

type Word = {t: string; accent: boolean};

const parse = (text: string): Word[] =>
  text
    .split('*')
    .flatMap((seg, i) =>
      seg
        .split(/\s+/)
        .filter(Boolean)
        .map((t) => ({t, accent: i % 2 === 1})),
    );

type PhraseProps = {
  at: number;
  until: number;
  text: string;
  y?: number;
  size?: number;
  accentColor?: string;
  weight?: 700 | 900;
  color?: string;
};

export const PhraseVerticalEN: React.FC<PhraseProps> = ({
  at,
  until,
  text,
  y = 0,
  size = 72,
  accentColor = COLORS.yellow,
  weight = 900,
  color = COLORS.white,
}) => {
  const frame = useCurrentFrame();
  const f0 = at * FPS;
  const f1 = until * FPS;
  if (frame < f0 - 1 || frame > f1 + 16) return null;

  const exit = interpolate(frame, [f1, f1 + 12], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: easeIn,
  });
  const words = parse(text);

  return (
    <div
      style={{
        position: 'absolute',
        inset: 0,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '0 64px',
        transform: `translate3d(0, ${y - exit * 36}px, 0)`,
        opacity: 1 - exit,
        willChange: 'transform, opacity',
        WebkitBackfaceVisibility: 'hidden',
        backfaceVisibility: 'hidden',
      }}
    >
      <div
        dir="ltr"
        style={{
          display: 'flex',
          flexWrap: 'wrap',
          justifyContent: 'center',
          gap: `0 ${size * 0.22}px`,
          fontFamily,
          fontWeight: weight,
          fontSize: size,
          lineHeight: 1.25,
          letterSpacing: '-0.02em',
          textAlign: 'center',
          color,
          WebkitFontSmoothing: 'antialiased',
          textRendering: 'optimizeLegibility',
          WebkitBackfaceVisibility: 'hidden',
          backfaceVisibility: 'hidden',
        }}
      >
        {words.map((w, i) => {
          const p = interpolate(frame, [f0 + i * 3, f0 + i * 3 + 18], [0, 1], {
            extrapolateLeft: 'clamp',
            extrapolateRight: 'clamp',
            easing: easeOut,
          });
          const isDone = p >= 1;
          const ty = (1 - p) * 60;
          const sc = 0.94 + p * 0.06;
          const blurVal = (1 - p) * 12;

          return (
            <span
              key={i}
              style={{
                display: 'inline-block',
                opacity: p,
                transform: isDone
                  ? 'translate3d(0, 0, 0)'
                  : `translate3d(0, ${ty}px, 0) scale(${sc})`,
                filter: isDone || blurVal < 0.15 ? 'none' : `blur(${blurVal}px)`,
                color: w.accent ? accentColor : color,
                textShadow: w.accent
                  ? `0 0 45px ${accentColor}66, 0 3px 20px rgba(0,0,0,0.9)`
                  : '0 3px 20px rgba(0,0,0,0.9), 0 1px 3px rgba(0,0,0,0.95)',
                WebkitBackfaceVisibility: 'hidden',
                backfaceVisibility: 'hidden',
              }}
            >
              {w.t}
            </span>
          );
        })}
      </div>
    </div>
  );
};

type ToolCardVerticalProps = {
  name: string;
  desc: string;
  at: number;
  until: number;
  index: number;
  total: number;
};

export const ToolCardVerticalEN: React.FC<ToolCardVerticalProps> = ({name, desc, at, until, index, total}) => {
  const frame = useCurrentFrame();
  const f0 = at * FPS;
  const f1 = until * FPS;
  if (frame < f0 - 1 || frame > f1 + 16) return null;

  const enter = interpolate(frame, [f0, f0 + 22], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: easeOut,
  });
  const exit = interpolate(frame, [f1, f1 + 12], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: easeIn,
  });
  const descIn = interpolate(frame, [f0 + 10, f0 + 30], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: easeOut,
  });
  const underline = interpolate(frame, [f0 + 6, f0 + 28], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: easeOut,
  });

  const isEnterDone = enter >= 1;
  const isDescDone = descIn >= 1;

  return (
    <div
      style={{
        position: 'absolute',
        inset: 0,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '0 48px',
        opacity: (1 - exit) * enter,
        transform: isEnterDone && exit === 0
          ? 'translate3d(0, 0, 0)'
          : `translate3d(${(1 - enter) * -120 + exit * 90}px, 0, 0)`,
        willChange: isEnterDone && exit === 0 ? 'auto' : 'transform, opacity',
        WebkitBackfaceVisibility: 'hidden',
        backfaceVisibility: 'hidden',
      }}
    >
      <div
        style={{
          textAlign: 'center',
          fontFamily,
          maxWidth: '100%',
          WebkitFontSmoothing: 'antialiased',
          textRendering: 'optimizeLegibility',
          WebkitBackfaceVisibility: 'hidden',
          backfaceVisibility: 'hidden',
        }}
      >
        {/* Step Badge */}
        <div
          dir="ltr"
          style={{
            fontSize: 28,
            fontWeight: 700,
            letterSpacing: '0.3em',
            color: COLORS.blue,
            marginBottom: 20,
            textShadow: '0 2px 10px rgba(0,0,0,0.85)',
          }}
        >
          {String(index + 1).padStart(2, '0')} / {String(total).padStart(2, '0')}
        </div>

        {/* SVG Brand Mark */}
        <div
          style={{
            display: 'flex',
            justifyContent: 'center',
            marginBottom: 24,
            transform: isEnterDone ? 'scale(1)' : `scale(${0.8 + enter * 0.2})`,
            opacity: enter,
          }}
        >
          {renderToolLogo(name, 150)}
        </div>

        {/* Tool Name */}
        <div
          dir="ltr"
          style={{
            fontSize: 96,
            fontWeight: 900,
            lineHeight: 1.1,
            color: COLORS.yellow,
            textShadow: `0 0 50px ${COLORS.yellow}55, 0 3px 20px rgba(0,0,0,0.9)`,
            letterSpacing: '-0.02em',
          }}
        >
          {name}
        </div>

        {/* Neon Gradient Underline */}
        <div
          style={{
            height: 6,
            borderRadius: 3,
            margin: '20px auto 28px',
            width: 360 * underline,
            background: `linear-gradient(90deg, ${COLORS.blue}, ${COLORS.yellow})`,
            boxShadow: `0 0 16px ${COLORS.blue}88`,
          }}
        />

        {/* Description */}
        <div
          dir="ltr"
          style={{
            fontSize: 42,
            fontWeight: 700,
            lineHeight: 1.4,
            color: COLORS.white,
            marginTop: 240,
            opacity: descIn,
            transform: isDescDone
              ? 'translate3d(0, 0, 0)'
              : `translate3d(0, ${(1 - descIn) * 30}px, 0)`,
            willChange: isDescDone ? 'auto' : 'transform, opacity',
            textShadow: '0 3px 14px rgba(0,0,0,0.95), 0 1px 3px rgba(0,0,0,0.98)',
            padding: '0 24px',
          }}
        >
          {desc}
        </div>
      </div>
    </div>
  );
};

