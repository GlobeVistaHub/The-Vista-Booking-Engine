// ─────────────────────────────────────────────────────────────
//  HARFEN W LAKEN — ENGLISH 16:9 LANDSCAPE CONFIGURATION
//  Precision-calibrated to mariya_voiceover_en.wav (48kHz Master)
// ─────────────────────────────────────────────────────────────

export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;
export const DURATION_S = 55;
export const DURATION_FRAMES = FPS * DURATION_S;

export const VOICEOVER_FILE: string | null = 'mariya_voiceover_en.wav';

export const PRESENTER = 'Mariya';

export const CHANNEL = {
  ar: 'حرفين و لكن',
  en: 'HARFEN W LAKEN',
  tagline: 'Decoding the frontier of creative AI',
};

export const COLORS = {
  bg1: '#070B16', // deep charcoal-blue
  bg2: '#0E1A33',
  white: '#F5F7FF',
  blue: '#3D8BFF',
  yellow: '#FFD23F',
  dim: 'rgba(245,247,255,0.55)',
};

export const sec = (s: number) => Math.round(s * FPS);

export const T = {
  hook: [0, 6.4],
  tools: [6.4, 22.4],
  pivot: [22.3, 37.0],
  thesis: [37.0, 48.0],
  outro: [48.0, 55.0],
  silenceStart: 30.7,
  silenceEnd: 33.1,
  merge: 41.0,
} as const;

export type PhraseData = {
  at: number;
  until: number;
  text: string;
  y?: number;
  size?: number;
};

// 0–6.2s THE HOOK — Precision-calibrated to English VO (00:05.13 = Frame 163)
export const HOOK_EN: PhraseData[] = [
  {at: 0.20, until: 6.25, y: -180, size: 78, text: 'Headlines are screaming:'},
  {at: 2.20, until: 6.25, y: -60, size: 92, text: '*The Death of Video Editors!*'},
  {at: 3.88, until: 6.25, y: 60, size: 68, text: '*Is it real?*'},
  {at: 163 / 30, until: 6.25, y: 170, size: 82, text: '*Let\'s find out.*'},
];

// 6.67–22.4s THE TOOLS — Calibrated 1:1 to perceptual acoustic centers (Opus Clip @ 00:06.20 = Frame 200)
export const TOOLS_EN = [
  {name: 'Opus Clip', desc: 'Turns long-form footage into viral Shorts in seconds', at: 200 / 30, until: 10.45},
  {name: 'CapCut', desc: 'Auto-transcribes and subtitles every single spoken word', at: 10.80, until: 14.80},
  {name: 'Premiere Pro', desc: 'Expands entire frames with generative fill in one click', at: 15.25, until: 18.15},
  {name: 'Kling', desc: 'Creates full cinematic scenes straight from text prompts', at: 18.40, until: 22.20},
];

// 22.3–37.0s THE EMOTIONAL PIVOT (00:28.02 = Frame 842)
export const PIVOT_EN: PhraseData[] = [
  {at: 23.0, until: 26.8, y: -80, size: 84, text: 'Artificial intelligence *can cut a scene...*'},
  {at: 24.6, until: 26.8, y: 80, size: 92, text: 'but it will *never feel it.*'},
  {at: 842 / 30, until: 30.65, y: 0, size: 86, text: 'And it never knows when to let the *frame breathe.*'},
  // Holds through the silence, then lands right as vocal resumes at 33.15s
  {at: 33.15, until: 36.8, y: 0, size: 84, text: 'When *silence* is louder than the heaviest music.'},
];

// 37.0–48.0s THE MINDSET SHIFT
export const THESIS_EN: PhraseData[] = [
  {at: 37.2, until: 40.6, y: -80, size: 84, text: 'The editors who *will lose...*'},
  {at: 38.8, until: 40.6, y: 80, size: 84, text: 'won\'t lose to *artificial intelligence.*'},
  {at: 41.0, until: 43.6, y: 0, size: 96, text: '...they will lose to *editors who master it.*'},
  {at: 43.8, until: 47.8, y: -160, size: 106, text: 'Don\'t fight it.'},
  {at: 44.9, until: 47.8, y: 0, size: 110, text: '*Learn it.*'},
  {at: 46.0, until: 47.8, y: 160, size: 110, text: '*Use it.*'},
];

// 48.0–53.0s BRAND SIGN-OFF
export const SIGNOFF_AT = 48.3;
export const LOGO_AT = 49.5;
export const TAGLINE_AT = 50.4;
