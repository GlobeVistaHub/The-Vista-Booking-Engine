import React from 'react';
import {Easing, interpolate, useCurrentFrame} from 'remotion';
import {loadFont} from '@remotion/google-fonts/Cairo';
import {COLORS, FPS} from './config';

export const {fontFamily} = loadFont('normal', {
  weights: ['700', '900'],
  subsets: ['arabic', 'latin'],
});

// Smooth "expo-out" curve — fast start, long soft landing (no linear snaps).
const easeOut = Easing.bezier(0.16, 1, 0.3, 1);
const easeIn = Easing.bezier(0.5, 0, 0.9, 0.4);

type Word = {t: string; accent: boolean};

// "هل يستطيع *الذكاء الاصطناعي*" → words, highlighted ones flagged
const parse = (text: string): Word[] =>
  text
    .split('*')
    .flatMap((seg, i) =>
      seg
        .split(/\s+/)
        .filter(Boolean)
        .map((t) => ({t, accent: i % 2 === 1})),
    );

type PhraseProps = {
  at: number; // seconds: first word appears (match the narration beat)
  until: number; // seconds: phrase starts leaving (hold a beat after the voice)
  text: string;
  y?: number;
  size?: number;
  accentColor?: string;
  latin?: boolean; // for English text (letter-spaced, left-to-right)
  weight?: 700 | 900;
  color?: string;
};

export const Phrase: React.FC<PhraseProps> = ({
  at,
  until,
  text,
  y = 0,
  size = 104,
  accentColor = COLORS.yellow,
  latin = false,
  weight = 900,
  color = COLORS.white,
}) => {
  const frame = useCurrentFrame();
  const f0 = at * FPS;
  const f1 = until * FPS;
  if (frame < f0 - 1 || frame > f1 + 16) return null;

  const exit = interpolate(frame, [f1, f1 + 12], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: easeIn,
  });
  const words = parse(text);

  return (
    <div
      style={{
        position: 'absolute',
        inset: 0,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '0 160px',
        transform: `translate3d(0, ${y - exit * 36}px, 0)`,
        opacity: 1 - exit,
        willChange: 'transform, opacity',
        WebkitBackfaceVisibility: 'hidden',
        backfaceVisibility: 'hidden',
      }}
    >
      <div
        dir={latin ? 'ltr' : 'rtl'}
        style={{
          display: 'flex',
          flexWrap: 'wrap',
          justifyContent: 'center',
          gap: `0 ${size * 0.26}px`,
          fontFamily,
          fontWeight: weight,
          fontSize: size,
          lineHeight: 1.3,
          letterSpacing: latin ? '0.28em' : 0, // never letter-space Arabic: it breaks the joins
          textAlign: 'center',
          color,
          WebkitFontSmoothing: 'antialiased',
          textRendering: 'optimizeLegibility',
          WebkitBackfaceVisibility: 'hidden',
          backfaceVisibility: 'hidden',
        }}
      >
        {words.map((w, i) => {
          // each word arrives 3 frames after the previous one
          const p = interpolate(frame, [f0 + i * 3, f0 + i * 3 + 18], [0, 1], {
            extrapolateLeft: 'clamp',
            extrapolateRight: 'clamp',
            easing: easeOut,
          });
          const isDone = p >= 1;
          const ty = (1 - p) * 70;
          const sc = 0.92 + p * 0.08;
          const blurVal = (1 - p) * 14;

          return (
            <span
              key={i}
              style={{
                display: 'inline-block',
                opacity: p,
                transform: isDone
                  ? 'translate3d(0, 0, 0)'
                  : `translate3d(0, ${ty}px, 0) scale(${sc})`,
                filter: isDone || blurVal < 0.15 ? 'none' : `blur(${blurVal}px)`,
                willChange: isDone ? 'auto' : 'transform, opacity, filter',
                WebkitBackfaceVisibility: 'hidden',
                backfaceVisibility: 'hidden',
                transformOrigin: 'center center',
                color: w.accent ? accentColor : color,
                textShadow: w.accent
                  ? `0 0 38px ${accentColor}66, 0 3px 14px rgba(0,0,0,0.9)`
                  : '0 3px 14px rgba(0,0,0,0.9), 0 1px 3px rgba(0,0,0,0.95)',
              }}
            >
              {w.t}
            </span>
          );
        })}
      </div>
    </div>
  );
};

type ToolCardProps = {
  name: string;
  desc: string;
  at: number;
  until: number;
  index: number;
  total: number;
};

export const renderToolLogo = (name: string, size = 120) => {
  switch (name) {
    case 'Opus Clip':
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" fill="none">
          <defs>
            <linearGradient id="opusGrad" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
              <stop stopColor="#FFD23F" />
              <stop offset="0.5" stopColor="#FF7A00" />
              <stop offset="1" stopColor="#3D8BFF" />
            </linearGradient>
            <filter id="opusGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="4" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>
          <rect width="100" height="100" rx="26" fill="#0C1428" stroke="rgba(255,210,63,0.4)" strokeWidth="2.5" />
          <g filter="url(#opusGlow)">
            <path
              d="M32 30 C32 24, 46 22, 58 28 C70 34, 74 48, 68 60 C62 72, 48 78, 38 72 C28 66, 24 52, 30 40 C34 32, 44 30, 52 34 C60 38, 62 48, 58 54 C54 60, 46 62, 42 58"
              stroke="url(#opusGrad)"
              strokeWidth="9"
              strokeLinecap="round"
              fill="none"
            />
          </g>
        </svg>
      );
    case 'CapCut':
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" fill="none">
          <defs>
            <filter id="ccGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="4" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>
          <rect width="100" height="100" rx="26" fill="#070B16" stroke="rgba(61,139,255,0.45)" strokeWidth="2.5" />
          <g filter="url(#ccGlow)">
            <path d="M22 36 L48 24 L78 39 L52 51 Z" fill="#FFFFFF" />
            <path d="M22 64 L48 76 L78 61 L52 49 Z" fill="#3D8BFF" />
          </g>
        </svg>
      );
    case 'Premiere Pro':
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" fill="none">
          <defs>
            <linearGradient id="prGrad" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
              <stop stopColor="#1B0A33" />
              <stop offset="1" stopColor="#07031A" />
            </linearGradient>
            <filter id="prGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="4" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>
          <rect width="100" height="100" rx="24" fill="url(#prGrad)" stroke="#9999FF" strokeWidth="3" />
          <g filter="url(#prGlow)">
            <path d="M30 72 V28 H46 C54 28 60 33 60 41 C60 49 54 54 46 54 H38 V72 H30 Z M38 46 H45 C49 46 52 44 52 41 C52 38 49 36 45 36 H38 V46 Z" fill="#E685FF" />
            <path d="M64 72 V43 H71 V48 C73 44 77 42 81 42 V50 C76 50 72 53 72 58 V72 H64 Z" fill="#9999FF" />
          </g>
        </svg>
      );
    case 'Kling':
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" fill="none">
          <defs>
            <linearGradient id="klingGrad" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
              <stop stopColor="#FFD23F" />
              <stop offset="0.5" stopColor="#00F2FE" />
              <stop offset="1" stopColor="#3D8BFF" />
            </linearGradient>
            <filter id="klingGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="5" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>
          <rect width="100" height="100" rx="26" fill="#0A0F1E" stroke="rgba(255,210,63,0.4)" strokeWidth="2.5" />
          <g filter="url(#klingGlow)">
            <path d="M50 16 L56 42 L82 48 L56 54 L50 80 L44 54 L18 48 L44 42 Z" fill="url(#klingGrad)" />
            <circle cx="50" cy="48" r="5" fill="#FFFFFF" />
          </g>
        </svg>
      );
    default:
      return null;
  }
};

export const ToolCard: React.FC<ToolCardProps> = ({name, desc, at, until, index, total}) => {
  const frame = useCurrentFrame();
  const f0 = at * FPS;
  const f1 = until * FPS;
  if (frame < f0 - 1 || frame > f1 + 16) return null;

  const enter = interpolate(frame, [f0, f0 + 22], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: easeOut,
  });
  const exit = interpolate(frame, [f1, f1 + 12], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: easeIn,
  });
  const descIn = interpolate(frame, [f0 + 10, f0 + 30], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: easeOut,
  });
  const underline = interpolate(frame, [f0 + 6, f0 + 28], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: easeOut,
  });

  return (
    <div
      style={{
        position: 'absolute',
        inset: 0,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        opacity: (1 - exit) * enter,
        transform: `translate3d(${(1 - enter) * 160 - exit * 120}px, 0, 0)`,
        willChange: 'transform, opacity',
        WebkitBackfaceVisibility: 'hidden',
        backfaceVisibility: 'hidden',
      }}
    >
      <div
        style={{
          textAlign: 'center',
          fontFamily,
          WebkitFontSmoothing: 'antialiased',
          textRendering: 'optimizeLegibility',
          WebkitBackfaceVisibility: 'hidden',
          backfaceVisibility: 'hidden',
        }}
      >
        <div
          dir="ltr"
          style={{
            fontSize: 34,
            fontWeight: 700,
            letterSpacing: '0.3em',
            color: COLORS.blue,
            marginBottom: 16,
            textShadow: '0 2px 10px rgba(0,0,0,0.8)',
            WebkitBackfaceVisibility: 'hidden',
            backfaceVisibility: 'hidden',
          }}
        >
          {String(index + 1).padStart(2, '0')} / {String(total).padStart(2, '0')}
        </div>
        <div
          style={{
            display: 'flex',
            justifyContent: 'center',
            marginBottom: 20,
            transform: `scale(${0.75 + enter * 0.25})`,
            opacity: enter,
            WebkitBackfaceVisibility: 'hidden',
            backfaceVisibility: 'hidden',
          }}
        >
          {renderToolLogo(name, 130)}
        </div>
        <div
          dir="ltr"
          style={{
            fontSize: 160,
            fontWeight: 900,
            lineHeight: 1.05,
            color: COLORS.yellow,
            textShadow: `0 0 60px ${COLORS.yellow}55, 0 3px 20px rgba(0,0,0,0.9)`,
            WebkitBackfaceVisibility: 'hidden',
            backfaceVisibility: 'hidden',
          }}
        >
          {name}
        </div>
        <div
          style={{
            height: 8,
            borderRadius: 4,
            margin: '22px auto 34px',
            width: 520 * underline,
            background: `linear-gradient(90deg, ${COLORS.blue}, ${COLORS.yellow})`,
          }}
        />
        <div
          dir="rtl"
          style={{
            fontSize: 70,
            fontWeight: 700,
            color: COLORS.white,
            opacity: descIn,
            transform: `translate3d(0, ${(1 - descIn) * 40}px, 0)`,
            willChange: descIn >= 1 ? 'auto' : 'transform, opacity',
            WebkitBackfaceVisibility: 'hidden',
            backfaceVisibility: 'hidden',
            textShadow: '0 3px 14px rgba(0,0,0,0.9), 0 1px 3px rgba(0,0,0,0.95)',
          }}
        >
          {desc}
        </div>
      </div>
    </div>
  );
};
