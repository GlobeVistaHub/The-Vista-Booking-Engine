// ─────────────────────────────────────────────────────────────
//  HARFEN W LAKEN — VERTICAL 9:16 CONFIGURATION (1080 x 1920)
//  Calibrated for TikTok, Instagram Reels, and YouTube Shorts
//  Preserves strict mobile safe zones (Y: 280px to 1540px)
// ─────────────────────────────────────────────────────────────

import {
  FPS,
  DURATION_S,
  DURATION_FRAMES,
  VOICEOVER_FILE,
  PRESENTER,
  CHANNEL,
  COLORS,
  T,
  sec,
  TOOLS as TOOLS_ORIGINAL,
  PhraseData
} from './config';

export {
  FPS,
  DURATION_S,
  DURATION_FRAMES,
  VOICEOVER_FILE,
  PRESENTER,
  CHANNEL,
  COLORS,
  T,
  sec
};

export const WIDTH_V = 1080;
export const HEIGHT_V = 1920;

// 0–5.4s  THE HOOK — Calibrated for 9:16 mobile portrait
export const HOOK_V: PhraseData[] = [
  {at: 0.2, until: 5.2, y: -200, size: 76, text: 'المانشيتات بتقول:'},
  {at: 1.68, until: 5.2, y: 0, size: 84, text: '*نهاية عصر المونتيرين!*'},
  {at: 3.8, until: 5.2, y: 200, size: 68, text: '*هل ده بجد؟ تعالوا نشوف.*'},
];

// 5.2–22.4s  THE TOOLS — Reframed for vertical layout
export const TOOLS_V = TOOLS_ORIGINAL;

// 22.3–37.0s  THE EMOTIONAL PIVOT — Mobile scannable text
export const PIVOT_V: PhraseData[] = [
  {at: 22.6, until: 26.6, y: -120, size: 68, text: 'الذكاء الاصطناعي *يقدر يقطع مشهد*'},
  {at: 24.1, until: 26.6, y: 120, size: 76, text: 'بس *مستحيل يحسه*'},
  {at: 26.8, until: 30.5, y: 0, size: 72, text: 'وميعرفش امتى يسيب *الكادر يتنفس*'},
  // Holds through the silence on purpose
  {at: 34.0, until: 37.0, y: 0, size: 68, text: 'حين يكون *الصمت* أقوى من أعلى مزيكا'},
];

// 37.0–48.0s  THE MINDSET SHIFT — The thesis
export const THESIS_V: PhraseData[] = [
  {at: 37.3, until: 40.8, y: -100, size: 70, text: 'المحررين اللي *هيخسروا*'},
  {at: 39.0, until: 40.8, y: 100, size: 70, text: 'مش قدام *الذكاء الاصطناعي*'},
  {at: 41.0, until: 43.8, y: 0, size: 76, text: 'بل قدام *مونتيرين بيستخدموه*'},
  {at: 44.0, until: 47.8, y: -200, size: 88, text: 'لا تحاربه.'},
  {at: 45.0, until: 47.8, y: 0, size: 92, text: '*اتعلّمه.*'},
  {at: 46.0, until: 47.8, y: 200, size: 92, text: '*استخدمه.*'},
];

export const SIGNOFF_AT = 48.3;
export const LOGO_AT = 49.5;
export const TAGLINE_AT = 50.4;
