import React from 'react';
import {
  AbsoluteFill,
  Sequence,
  Video,
  Img,
  Audio,
  interpolate,
  spring,
  Easing,
  useCurrentFrame,
  useVideoConfig,
  staticFile
} from 'remotion';

// ─────────────────────────────────────────────────────────────
// DESIGN SYSTEM & MOBILE SAFE ZONES (9:16 Vertical 1080x1920)
// Safe Zone: Top >= 220px, Bottom >= 340px, Left/Right >= 80px
// ─────────────────────────────────────────────────────────────
const COLORS = {
  bgDark: '#020617',
  slateDark: '#0b1120',
  emerald: '#10b981',
  emeraldGlow: 'rgba(16, 185, 129, 0.65)',
  cyan: '#06b6d4',
  cyanGlow: 'rgba(6, 182, 212, 0.65)',
  rose: '#f43f5e',
  roseGlow: 'rgba(244, 63, 94, 0.6)',
  gold: '#fbbf24',
  textWhite: '#f8fafc',
  textMuted: '#94a3b8'
};

// Optical Flash Helper
const OpticalFlash: React.FC<{ frame: number; triggerFrame: number; duration?: number; color?: string }> = ({
  frame,
  triggerFrame,
  duration = 5,
  color = '#ffffff'
}) => {
  const diff = frame - triggerFrame;
  if (diff < 0 || diff > duration) return null;
  const opacity = interpolate(diff, [0, 1, duration], [0, 0.85, 0], { extrapolateRight: 'clamp' });
  return (
    <div
      style={{
        position: 'absolute',
        inset: 0,
        backgroundColor: color,
        opacity,
        pointerEvents: 'none',
        zIndex: 99
      }}
    />
  );
};

export const AkkariCommercialAd: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  return (
    <AbsoluteFill style={{ backgroundColor: COLORS.bgDark, fontFamily: 'system-ui, -apple-system, sans-serif', overflow: 'hidden' }}>

      {/* ──────────────────────────────────────────────────────────
          GLOBAL TRANSITION OPTICAL FLASHES & WIPES
      ─────────────────────────────────────────────────────────── */}
      {/* Wipe into Scene 2 (Site Manager) */}
      <OpticalFlash frame={frame} triggerFrame={126} duration={6} color="#06b6d4" />
      {/* Glitch flash into Craft */}
      <OpticalFlash frame={frame} triggerFrame={345} duration={6} color="#f43f5e" />
      {/* Laser wipe into Staccato */}
      <OpticalFlash frame={frame} triggerFrame={480} duration={8} color="#10b981" />
      {/* Staccato rapid-fire flashes */}
      <OpticalFlash frame={frame} triggerFrame={520} duration={4} color="#ffffff" />
      <OpticalFlash frame={frame} triggerFrame={560} duration={4} color="#ffffff" />
      <OpticalFlash frame={frame} triggerFrame={600} duration={4} color="#ffffff" />
      {/* Flash into CAD Intake & +240% */}
      <OpticalFlash frame={frame} triggerFrame={640} duration={8} color="#06b6d4" />
      {/* Flash into Commercial Pro */}
      <OpticalFlash frame={frame} triggerFrame={864} duration={6} color="#10b981" />
      {/* Flash into Close */}
      <OpticalFlash frame={frame} triggerFrame={1002} duration={8} color="#38bdf8" />
      {/* Flash into GoodBrains Outro at frame 1140 */}
      <OpticalFlash frame={frame} triggerFrame={1140} duration={10} color="#fbbf24" />

      {/* ──────────────────────────────────────────────────────────
          MASTER BROADCAST AUDIO TRACK (Music + Dynamic Ducking + VO + Footsteps)
          Mastered at 48kHz / 320kbps with true-peak limiter and dynamic ducking (Option B - Zero Delay Start at 00:00.05).
      ─────────────────────────────────────────────────────────── */}
      <Audio src={staticFile('tile-commercial/commercial_master_audio_v42.mp3')} volume={1.0} />

      {/* ──────────────────────────────────────────────────────────
          BEAT 1: THE HOOK (Frames 0 - 90 / 0s - 3.0s)
          Nero Marquina Black Marble Glide + High-Stakes Tender Leak Alert
      ─────────────────────────────────────────────────────────── */}
      <Sequence from={0} durationInFrames={126}>
        <AbsoluteFill>
          {/* Resonating 2.5D Parallax Drift - Keeps black marble floating through tail pause */}
          <Video
            src={staticFile('tile-commercial/shot1_macro_hook.mp4')}
            muted
            style={{
              width: '100%',
              height: '100%',
              objectFit: 'cover',
              transform: `translate3d(${interpolate(frame, [90, 126], [0, -10], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' })}px, ${interpolate(frame, [90, 126], [0, 8], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' })}px, 0) scale(${interpolate(frame, [0, 90, 126], [1.0, 1.06, 1.11], { extrapolateRight: 'clamp' })}) rotate(${interpolate(frame, [90, 126], [0, -0.3], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' })}deg)`,
              willChange: 'transform'
            }}
          />
          <div
            style={{
              position: 'absolute',
              inset: 0,
              background: 'linear-gradient(180deg, rgba(2,6,23,0.75) 0%, rgba(2,6,23,0.05) 35%, rgba(2,6,23,0.3) 65%, rgba(2,6,23,0.92) 100%)'
            }}
          />

          {/* Top Brand Pill (Safe Zone: top: 220px) */}
          <div
            style={{
              position: 'absolute',
              top: 220,
              left: 80,
              right: 80,
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              opacity: interpolate(frame, [0, 12], [0, 1])
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 18 }}>
              <div
                style={{
                  width: 58,
                  height: 58,
                  borderRadius: 16,
                  background: 'linear-gradient(135deg, #06b6d4, #10b981)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontWeight: 900,
                  fontSize: 28,
                  color: '#020617',
                  boxShadow: '0 0 25px rgba(16, 185, 129, 0.4)'
                }}
              >
                A
              </div>
              <div>
                <div style={{ color: '#ffffff', fontWeight: 900, fontSize: 30, letterSpacing: '0.04em', textShadow: '0 2px 12px rgba(0,0,0,0.95)' }}>
                  AKKARI TILING
                </div>
                <div style={{ color: '#38bdf8', fontSize: 18, fontWeight: 900, letterSpacing: '0.14em', textShadow: '0 2px 10px rgba(0,0,0,0.95)' }}>
                  MELBOURNE // COMMERCIAL
                </div>
              </div>
            </div>

            <div
              style={{
                background: 'rgba(15, 23, 42, 0.78)',
                backdropFilter: 'blur(16px)',
                border: '1.5px solid rgba(56, 189, 248, 0.5)',
                borderRadius: 999,
                padding: '12px 26px',
                color: '#38bdf8',
                fontSize: 18,
                fontWeight: 900,
                letterSpacing: '0.08em',
                boxShadow: '0 0 25px rgba(56, 189, 248, 0.25)',
                textShadow: '0 2px 10px rgba(0,0,0,0.95)'
              }}
            >
              ★ EXECUTIVE AUDIT
            </div>
          </div>

          {/* Kinetic Headline (Safe Zone: bottom: 360px) */}
          <div
            style={{
              position: 'absolute',
              bottom: 360,
              left: 80,
              right: 80,
              transform: frame < 15
                ? `translate3d(0, ${interpolate(frame, [0, 15], [35, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' })}px, 0)`
                : 'none',
              opacity: interpolate(frame, [0, 12], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' }),
              WebkitFontSmoothing: 'antialiased',
              textRendering: 'optimizeLegibility',
              backfaceVisibility: 'hidden',
              WebkitBackfaceVisibility: 'hidden'
            }}
          >
            <div
              style={{
                display: 'inline-block',
                background: 'rgba(244, 63, 94, 0.28)',
                border: '2px solid #f43f5e',
                color: '#fecdd3',
                fontSize: 22,
                fontWeight: 900,
                padding: '10px 26px',
                borderRadius: 14,
                marginBottom: 18,
                letterSpacing: '0.08em',
                boxShadow: '0 0 25px rgba(244, 63, 94, 0.4)',
                textShadow: '0 2px 10px rgba(0,0,0,0.95)'
              }}
            >
              ⚠️ TIER-1 LEAKAGE ALERT
            </div>

            <h1
              style={{
                fontSize: 66,
                fontWeight: 900,
                lineHeight: 1.15,
                color: '#ffffff',
                margin: 0,
                textShadow: '0 8px 32px rgba(0,0,0,0.9)'
              }}
            >
              YOUR WEBSITE IS LEAKING{' '}
              <span
                style={{
                  color: '#f43f5e',
                  textDecoration: 'underline',
                  textDecorationColor: '#f43f5e',
                  textUnderlineOffset: '10px'
                }}
              >
                $500K+
              </span>{' '}
              COMMERCIAL TENDERS
            </h1>

            <p style={{ color: '#e2e8f0', fontSize: 26, marginTop: 20, lineHeight: 1.35, fontWeight: 600 }}>
              Melbourne head contractors skip slow websites in under 4 seconds.
            </p>
          </div>
        </AbsoluteFill>
      </Sequence>

      {/* ──────────────────────────────────────────────────────────
          BEAT 2: THE AGITATION & GLITCH PUNCHLINE (Frames 90 - 180 / 3.0s - 6.0s)
          Builder on site with iPad + VIBRANT HIGH-ENERGY PUNCHLINE (NO DARK SHROUD!)
      ─────────────────────────────────────────────────────────── */}
      <Sequence from={126} durationInFrames={219}>
        <AbsoluteFill>
          {/* Resonating 2.5D Parallax Drift - Contractor keeps floating with dramatic glitch punchline */}
          <Video
            src={staticFile('tile-commercial/shot2_site_manager.mp4')}
            muted
            playbackRate={0.55}
            style={{
              width: '100%',
              height: '100%',
              objectFit: 'cover',
              transform: frame - 126 >= 110
                ? `translate3d(0, ${interpolate(frame - 236, [0, 109], [0, -12], { extrapolateRight: 'clamp' })}px, 0) scale(${interpolate(frame - 236, [0, 109], [1.14, 1.25])}) rotate(${interpolate(frame - 236, [0, 109], [0, 0.3], { extrapolateRight: 'clamp' })}deg)`
                : `scale(${interpolate(frame - 126, [0, 110], [1.02, 1.08])})`,
              willChange: 'transform'
            }}
          />

          {/* Clean Film Grade - Keeps contractor & Melbourne skyline 100% visible! */}
          <div
            style={{
              position: 'absolute',
              inset: 0,
              background:
                frame - 126 >= 110
                  ? 'radial-gradient(circle at 50% 45%, rgba(244,63,94,0.12) 0%, rgba(2,6,23,0.3) 55%, rgba(2,6,23,0.78) 100%)'
                  : 'linear-gradient(180deg, rgba(2,6,23,0.65) 0%, rgba(2,6,23,0.1) 35%, rgba(2,6,23,0.25) 65%, rgba(2,6,23,0.88) 100%)'
            }}
          />

          {/* Top HUD Lag Box (Frames 90 - 135) */}
          {frame - 126 < 110 && (
            <div
              style={{
                position: 'absolute',
                top: 230,
                left: 80,
                right: 80,
                background: 'rgba(15, 23, 42, 0.82)',
                backdropFilter: 'blur(24px) saturate(160%)',
                border: '2px solid rgba(244, 63, 94, 0.85)',
                borderRadius: 24,
                padding: '28px 36px',
                boxShadow: '0 25px 70px rgba(0,0,0,0.8), 0 0 45px rgba(244, 63, 94, 0.3)',
                transform: `scale(${spring({ frame: frame - 126, fps, config: { damping: 16 } })})`
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                  <span
                    style={{
                      width: 16,
                      height: 16,
                      borderRadius: 999,
                      backgroundColor: '#f43f5e',
                      display: 'inline-block',
                      boxShadow: '0 0 14px #f43f5e'
                    }}
                  />
                  <span
                    style={{
                      color: '#fca5a5',
                      fontWeight: 900,
                      fontSize: 24,
                      letterSpacing: '0.08em',
                      textShadow: '0 2px 12px rgba(0,0,0,0.95)'
                    }}
                  >
                    WORDPRESS / ELEMENTOR LAG
                  </span>
                </div>
                
                {/* Premium High-End Digital Monitor Tag for 4.8s */}
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 12,
                    background: 'rgba(244, 63, 94, 0.22)',
                    border: '2px solid rgba(244, 63, 94, 0.85)',
                    borderRadius: 16,
                    padding: '8px 22px',
                    boxShadow: '0 0 30px rgba(244, 63, 94, 0.5), inset 0 0 15px rgba(244, 63, 94, 0.25)'
                  }}
                >
                  <span
                    style={{
                      width: 12,
                      height: 12,
                      borderRadius: 999,
                      backgroundColor: '#f43f5e',
                      display: 'inline-block',
                      boxShadow: '0 0 16px #f43f5e',
                      opacity: interpolate((frame - 126) % 24, [0, 12, 24], [1, 0.35, 1])
                    }}
                  />
                  <span
                    style={{
                      color: '#ffffff',
                      fontWeight: 900,
                      fontSize: 42,
                      fontFamily: 'monospace',
                      textShadow: '0 0 20px rgba(244, 63, 94, 0.95), 0 0 40px rgba(244, 63, 94, 0.6)'
                    }}
                  >
                    4.8s
                  </span>
                  <span
                    style={{
                      color: '#fca5a5',
                      fontSize: 17,
                      fontWeight: 900,
                      letterSpacing: '0.1em',
                      textShadow: '0 2px 10px rgba(0,0,0,0.95)'
                    }}
                  >
                    SLOW
                  </span>
                </div>
              </div>

              <div style={{ height: 2, background: 'rgba(244, 63, 94, 0.35)', margin: '18px 0' }} />

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
                <div>
                  <div
                    style={{
                      color: '#e2e8f0',
                      fontSize: 20,
                      fontWeight: 800,
                      textShadow: '0 2px 10px rgba(0,0,0,0.95)'
                    }}
                  >
                    Architecture
                  </div>
                  <div
                    style={{
                      color: '#ffffff',
                      fontWeight: 900,
                      fontSize: 32,
                      marginTop: 6,
                      textShadow: '0 2px 16px rgba(0,0,0,0.95)'
                    }}
                  >
                    16 DOM Bloat Layers
                  </div>
                </div>
                <div>
                  <div
                    style={{
                      color: '#e2e8f0',
                      fontSize: 20,
                      fontWeight: 800,
                      textShadow: '0 2px 10px rgba(0,0,0,0.95)'
                    }}
                  >
                    Tender Inbound
                  </div>
                  <div
                    style={{
                      color: '#f87171',
                      fontWeight: 900,
                      fontSize: 32,
                      marginTop: 6,
                      textShadow: '0 0 20px rgba(244, 63, 94, 0.75), 0 2px 16px rgba(0,0,0,0.95)'
                    }}
                  >
                    -68% Mobile Abandon
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* PHASE A (Frames 90 - 135): "When a site manager waits 5 seconds..." */}
          {frame - 126 < 110 && (
            <div
              style={{
                position: 'absolute',
                bottom: 380,
                left: 80,
                right: 80,
                textAlign: 'center',
                transform: `scale(${spring({ frame: frame - 126, fps, config: { damping: 18, stiffness: 95 } })})`
              }}
            >
              <div
                style={{
                  fontSize: 58,
                  fontWeight: 900,
                  color: '#ffffff',
                  lineHeight: 1.25,
                  textShadow: '0 8px 35px rgba(0,0,0,0.95), 0 0 50px rgba(0,0,0,0.9)'
                }}
              >
                WHEN A SITE MANAGER{' '}
                <span style={{ color: '#f87171', textShadow: '0 0 25px rgba(244, 63, 94, 0.8)' }}>
                  WAITS 5 SECONDS...
                </span>
              </div>
            </div>
          )}

          {/* PHASE B (Frames 135 - 180): VIBRANT GLITCH PUNCHLINE (Contractor remains clearly visible!) */}
          {frame - 126 >= 110 && (
            <>
              {/* Floating Alert HUD at Top Safe Zone */}
              <div
                style={{
                  position: 'absolute',
                  top: 230,
                  left: 80,
                  right: 80,
                  display: 'flex',
                  justifyContent: 'center',
                  transform: `scale(${spring({ frame: frame - 236, fps, config: { damping: 18, stiffness: 95 } })})`
                }}
              >
                <div
                  style={{
                    background: 'rgba(244, 63, 94, 0.9)',
                    backdropFilter: 'blur(16px)',
                    color: '#ffffff',
                    fontSize: 20,
                    fontWeight: 900,
                    padding: '10px 28px',
                    borderRadius: 999,
                    letterSpacing: '0.12em',
                    boxShadow: '0 0 35px rgba(244, 63, 94, 0.65)'
                  }}
                >
                  ⚡ THE COMMERCIAL REALITY
                </div>
              </div>

              {/* Kinetic Typography Overlay (Safe Zone: bottom: 360px - Refined Anamorphic VFX!) */}
              <div
                style={{
                  position: 'absolute',
                  bottom: 360,
                  left: 60,
                  right: 60,
                  textAlign: 'center',
                  transform: `scale(${spring({ frame: frame - 236, fps, config: { damping: 18, stiffness: 95 } })})`
                }}
              >
                <div
                  style={{
                    position: 'relative',
                    overflow: 'hidden',
                    background: 'rgba(15, 23, 42, 0.76)',
                    backdropFilter: 'blur(24px) saturate(160%)',
                    border: '2px solid rgba(244, 63, 94, 0.75)',
                    borderRadius: 28,
                    padding: '34px 30px',
                    boxShadow: '0 25px 70px rgba(0,0,0,0.85), 0 0 45px rgba(244, 63, 94, 0.3)'
                  }}
                >
                  {/* Anamorphic Crimson Lens Flare Sweep across card on impact */}
                  {frame - 236 < 18 && (
                    <div
                      style={{
                        position: 'absolute',
                        top: 0,
                        bottom: 0,
                        left: 0,
                        width: '100%',
                        background: 'linear-gradient(90deg, transparent, rgba(244, 63, 94, 0.35), rgba(255, 255, 255, 0.6), rgba(244, 63, 94, 0.35), transparent)',
                        transform: `translateX(${interpolate(frame - 236, [0, 18], [-1000, 1000])}px)`,
                        pointerEvents: 'none'
                      }}
                    />
                  )}

                  <h1
                    style={{
                      fontSize: 64,
                      fontWeight: 900,
                      color: '#ffffff',
                      lineHeight: 1.15,
                      margin: 0,
                      textShadow: `
                        -1.5px 0 rgba(6, 182, 212, 0.8),
                        1.5px 0 rgba(244, 63, 94, 0.8),
                        0 0 35px rgba(244, 63, 94, 0.5),
                        0 8px 30px rgba(0,0,0,0.9)
                      `,
                      letterSpacing: '-0.02em'
                    }}
                  >
                    THEY AWARD THE CONTRACT{' '}
                    <span style={{ display: 'block', color: '#f43f5e', marginTop: 12, textShadow: '0 0 30px rgba(244, 63, 94, 0.9)' }}>
                      TO SOMEONE ELSE.
                    </span>
                  </h1>
                </div>
              </div>
            </>
          )}
        </AbsoluteFill>
      </Sequence>

      {/* ──────────────────────────────────────────────────────────
          BEAT 3: THE CRAFTSMANSHIP & ANIMATING LAYERED UIS (Frames 180 - 280 / 6.0s - 9.3s)
          Real Suction Lifters & Green Laser Line Precision + 4 Cascading Spring HUDs
      ─────────────────────────────────────────────────────────── */}
      <Sequence from={345} durationInFrames={135}>
        <AbsoluteFill>
          {/* Resonating 2.5D Parallax Drift - Laser alignment & hands glide in continuous 3D depth */}
          <Video
            src={staticFile('tile-commercial/shot3_laser_craft.mp4')}
            muted
            style={{
              width: '100%',
              height: '100%',
              objectFit: 'cover',
              transform: `translate3d(${interpolate(frame - 345, [90, 135], [0, 12], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' })}px, ${interpolate(frame - 345, [90, 135], [0, -8], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' })}px, 0) scale(${interpolate(frame - 345, [0, 90, 135], [1.0, 1.08, 1.15], { extrapolateRight: 'clamp' })}) rotate(${interpolate(frame - 345, [90, 135], [0, -0.3], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' })}deg)`,
              willChange: 'transform'
            }}
          />
          <div
            style={{
              position: 'absolute',
              inset: 0,
              background: 'linear-gradient(180deg, rgba(2,6,23,0.72) 0%, rgba(2,6,23,0.05) 30%, rgba(2,6,23,0.15) 55%, rgba(2,6,23,0.92) 100%)'
            }}
          />

          {/* Heading (Safe Zone: top: 220px) */}
          <div
            style={{
              position: 'absolute',
              top: 220,
              left: 80,
              right: 80,
              textAlign: 'center'
            }}
          >
            <div
              style={{
                display: 'inline-block',
                background: 'rgba(16, 185, 129, 0.28)',
                border: '2px solid #10b981',
                color: '#34d399',
                fontSize: 21,
                fontWeight: 900,
                padding: '10px 28px',
                borderRadius: 999,
                letterSpacing: '0.12em',
                marginBottom: 14,
                boxShadow: '0 0 25px rgba(16, 185, 129, 0.45)',
                textShadow: '0 2px 10px rgba(0,0,0,0.95)'
              }}
            >
              ★ SURGICAL PRECISION
            </div>
            <h2 style={{ fontSize: 58, fontWeight: 900, color: '#ffffff', margin: 0, lineHeight: 1.15 }}>
              One System. Every Surface.
            </h2>
          </div>

          {/* 4 Cascading Animated Glassmorphism Capability Slabs (Safe Zone: bottom: 340px) */}
          <div
            style={{
              position: 'absolute',
              bottom: 340,
              left: 70,
              right: 70,
              display: 'flex',
              flexDirection: 'column',
              gap: 12
            }}
          >
            {[
              {
                num: '01',
                title: 'Laser Alignment & 0mm Lippage',
                desc: 'Large-Format 1200x600mm+ Porcelain',
                tag: 'VBA Standards',
                color: '#10b981'
              },
              {
                num: '02',
                title: 'Sub-Second Clean Code Stack',
                desc: 'Google 98+ Score — Zero Bloat',
                tag: '0.7s Instant',
                color: '#06b6d4'
              },
              {
                num: '03',
                title: 'Victorian Compliance Trust Hub',
                desc: 'VBA Registered & $20M Public Liability',
                tag: '$20M Insurance',
                color: '#10b981'
              },
              {
                num: '04',
                title: 'Job-Site Rapid Tender Intake',
                desc: 'Commercial Estimators submit CAD in 3 taps',
                tag: 'Tender Ready',
                color: '#fbbf24'
              }
            ].map((mod, idx) => {
              const delay = idx * 7;
              const cardAge = frame - 345 - delay;
              const cardScale = interpolate(cardAge, [0, 12], [0.95, 1.0], {
                extrapolateLeft: 'clamp',
                extrapolateRight: 'clamp',
                easing: Easing.out(Easing.cubic)
              });
              const slideX = interpolate(cardAge, [0, 12], [36, 0], {
                extrapolateLeft: 'clamp',
                extrapolateRight: 'clamp',
                easing: Easing.out(Easing.cubic)
              });
              const opacity = interpolate(cardAge, [0, 8], [0, 1], {
                extrapolateLeft: 'clamp',
                extrapolateRight: 'clamp'
              });

              // Momentary Green Laser Beam Glow Sweep on Entrance
              const isEntering = cardAge >= 0 && cardAge <= 14;
              const laserGlow = isEntering
                ? interpolate(cardAge, [0, 4, 14], [0, 1, 0], { extrapolateRight: 'clamp' })
                : 0;

              return (
                <div
                  key={idx}
                  style={{
                    position: 'relative',
                    overflow: 'hidden',
                    transform: `translateX(${slideX}px) scale(${cardScale})`,
                    opacity,
                    background: 'rgba(15, 23, 42, 0.82)',
                    backdropFilter: 'blur(20px) saturate(160%)',
                    border: '1.5px solid rgba(255, 255, 255, 0.15)',
                    borderLeft: `${6 + laserGlow * 3}px solid ${laserGlow > 0.1 ? '#10b981' : mod.color}`,
                    borderRadius: 20,
                    padding: '16px 26px',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    boxShadow: `0 20px 50px rgba(0,0,0,0.75), 0 0 ${laserGlow * 35}px rgba(16, 185, 129, ${laserGlow * 0.75})`,
                    WebkitFontSmoothing: 'antialiased',
                    backfaceVisibility: 'hidden',
                    willChange: 'transform, opacity'
                  }}
                >
                  {/* Momentary Green Laser Beam Sweep Across Card */}
                  {isEntering && (
                    <div
                      style={{
                        position: 'absolute',
                        top: 0,
                        bottom: 0,
                        left: 0,
                        width: 140,
                        background: 'linear-gradient(90deg, transparent, rgba(16, 185, 129, 0.4), rgba(255, 255, 255, 0.75), rgba(16, 185, 129, 0.4), transparent)',
                        transform: `translateX(${interpolate(cardAge, [0, 14], [-140, 940])}px)`,
                        pointerEvents: 'none',
                        opacity: laserGlow
                      }}
                    />
                  )}

                  <div style={{ display: 'flex', alignItems: 'center', gap: 18 }}>
                    <span
                      style={{
                        color: laserGlow > 0.2 ? '#34d399' : mod.color,
                        fontWeight: 900,
                        fontSize: 28,
                        fontFamily: 'monospace',
                        textShadow: laserGlow > 0.1 ? '0 0 18px #10b981' : '0 2px 10px rgba(0,0,0,0.95)'
                      }}
                    >
                      {mod.num}
                    </span>
                    <div>
                      <div
                        style={{
                          color: '#ffffff',
                          fontWeight: 900,
                          fontSize: 26,
                          letterSpacing: '0.01em',
                          textShadow: laserGlow > 0.1 ? '0 0 20px #34d399, 0 0 35px #10b981, 0 2px 12px rgba(0,0,0,0.95)' : '0 2px 12px rgba(0,0,0,0.95)'
                        }}
                      >
                        {mod.title}
                      </div>
                      <div
                        style={{
                          color: '#e2e8f0',
                          fontSize: 18,
                          fontWeight: 600,
                          marginTop: 3,
                          textShadow: '0 2px 10px rgba(0,0,0,0.95)'
                        }}
                      >
                        {mod.desc}
                      </div>
                    </div>
                  </div>

                  {/* Equal Width Rectangles on Right (Clean Razor-Sharp Column!) */}
                  <div
                    style={{
                      width: 210,
                      minWidth: 210,
                      background: 'rgba(255, 255, 255, 0.08)',
                      border: `1.5px solid ${laserGlow > 0.2 ? '#10b981' : mod.color}`,
                      color: laserGlow > 0.2 ? '#34d399' : mod.color,
                      fontSize: 18,
                      fontWeight: 900,
                      padding: '11px 18px',
                      borderRadius: 12,
                      textAlign: 'center',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      letterSpacing: '0.04em',
                      boxShadow: laserGlow > 0.2 ? '0 0 25px rgba(16, 185, 129, 0.6)' : '0 4px 15px rgba(0,0,0,0.5)',
                      textShadow: '0 2px 8px rgba(0,0,0,0.95)',
                      flexShrink: 0
                    }}
                  >
                    {mod.tag}
                  </div>
                </div>
              );
            })}
          </div>
        </AbsoluteFill>
      </Sequence>

      {/* ──────────────────────────────────────────────────────────
          BEAT 4: THE STACCATO SECTORS (Frames 280 - 410 / 9.3s - 13.6s)
          IMMEDIATELY AFTER CRAFTSMAN: Hotels ➔ Malls ➔ Penthouses ➔ Offices
      ─────────────────────────────────────────────────────────── */}
      <Sequence from={480} durationInFrames={160}>
        <AbsoluteFill>
          {/* Sector 1: Luxury Hotel & Resort (Frames 280 - 312) */}
          <Sequence from={0} durationInFrames={40}>
            {(() => {
              const secAge = frame - 480;
              const badgeScale = interpolate(secAge, [0, 5, 12], [0.82, 1.06, 1.0], { easing: Easing.out(Easing.back(1.8)), extrapolateRight: 'clamp' });
              const shockwaveScale = interpolate(secAge, [0, 16], [0.92, 1.35], { easing: Easing.out(Easing.quad), extrapolateRight: 'clamp' });
              const shockwaveOpacity = interpolate(secAge, [0, 4, 16], [0, 0.85, 0], { extrapolateRight: 'clamp' });
              const glintX = interpolate(secAge, [2, 18], [-150, 150], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
              return (
                <AbsoluteFill style={{ overflow: 'hidden' }}>
                  <div style={{ width: '100%', height: '100%' }}>
                    {/* Background with Snap-Zoom & Directional Blur into Sector 2 */}
                    <Img
                      src={staticFile('tile-commercial/sector_hotel_resort.jpg')}
                      style={{
                        width: '100%',
                        height: '100%',
                        objectFit: 'cover',
                        transform: `scale(${interpolate(secAge, [0, 34, 40], [1.02, 1.08, 1.22], { extrapolateRight: 'clamp' })}) translate3d(${interpolate(secAge, [35, 40], [0, -35], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' })}px, 0, 0)`,
                        filter: secAge >= 35 ? `blur(${interpolate(secAge, [35, 40], [0, 6], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' })}px)` : 'none',
                        willChange: 'transform, filter'
                      }}
                    />
                    <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(2,6,23,0.7) 0%, rgba(2,6,23,0.1) 40%, rgba(2,6,23,0.88) 100%)' }} />

                    <div style={{ position: 'absolute', bottom: 380, left: 80, right: 80, textAlign: 'center' }}>
                      {/* Resonating Badge with Shockwave & Specular Glint */}
                      <div style={{ position: 'relative', display: 'inline-block' }}>
                        {/* Outward Resonating Shockwave Ring */}
                        <div
                          style={{
                            position: 'absolute',
                            inset: -4,
                            borderRadius: 999,
                            border: '2px solid #10b981',
                            boxShadow: '0 0 25px #10b981',
                            opacity: shockwaveOpacity,
                            transform: `scale(${shockwaveScale})`,
                            pointerEvents: 'none'
                          }}
                        />
                        {/* Main Pill Badge */}
                        <div
                          style={{
                            position: 'relative',
                            background: '#10b981',
                            color: '#020617',
                            padding: '10px 28px',
                            borderRadius: 999,
                            fontWeight: 900,
                            fontSize: 22,
                            boxShadow: '0 0 25px rgba(16,185,129,0.5)',
                            transform: `scale(${badgeScale})`,
                            overflow: 'hidden'
                          }}
                        >
                          HOTELS & RESORTS • فندق أو منتجع فاخر
                          {/* Specular Glint Light Sweep */}
                          <div
                            style={{
                              position: 'absolute',
                              inset: 0,
                              background: 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.7) 50%, transparent 100%)',
                              transform: `translateX(${glintX}%)`,
                              pointerEvents: 'none'
                            }}
                          />
                        </div>
                      </div>

                      <h1 style={{ color: '#ffffff', fontSize: 68, fontWeight: 900, margin: '16px 0 6px 0', textShadow: '0 8px 30px rgba(0,0,0,0.9)', transform: `scale(${interpolate(secAge, [0, 6], [0.94, 1.0], { easing: Easing.out(Easing.cubic), extrapolateRight: 'clamp' })})` }}>
                        15,000 m²
                      </h1>
                      <div style={{ color: '#38bdf8', fontSize: 28, fontWeight: 800, fontFamily: 'monospace', textShadow: '0 0 15px rgba(56,189,248,0.7)' }}>
                        $3,500,000 AUD TENDER VALUE
                      </div>
                    </div>
                  </div>
                </AbsoluteFill>
              );
            })()}
          </Sequence>

          {/* Sector 2: Flagship Shopping Mall (Frames 312 - 344) */}
          <Sequence from={40} durationInFrames={40}>
            {(() => {
              const secAge = frame - 520;
              const badgeScale = interpolate(secAge, [0, 5, 12], [0.82, 1.06, 1.0], { easing: Easing.out(Easing.back(1.8)), extrapolateRight: 'clamp' });
              const shockwaveScale = interpolate(secAge, [0, 16], [0.92, 1.35], { easing: Easing.out(Easing.quad), extrapolateRight: 'clamp' });
              const shockwaveOpacity = interpolate(secAge, [0, 4, 16], [0, 0.85, 0], { extrapolateRight: 'clamp' });
              const glintX = interpolate(secAge, [2, 18], [-150, 150], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
              return (
                <AbsoluteFill style={{ overflow: 'hidden' }}>
                  <div style={{ width: '100%', height: '100%' }}>
                    {/* Background with Snap-Zoom In & Directional Blur Out into Sector 3 */}
                    <Img
                      src={staticFile('tile-commercial/sector_mall_retail.jpg')}
                      style={{
                        width: '100%',
                        height: '100%',
                        objectFit: 'cover',
                        transform: `scale(${interpolate(secAge, [0, 5, 34, 40], [1.18, 1.02, 1.08, 1.22], { extrapolateRight: 'clamp' })}) translate3d(${
                          secAge <= 5
                            ? interpolate(secAge, [0, 5], [35, 0], { extrapolateRight: 'clamp' })
                            : interpolate(secAge, [35, 40], [0, -35], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' })
                        }px, 0, 0)`,
                        filter: secAge <= 4
                          ? `blur(${interpolate(secAge, [0, 4], [6, 0], { extrapolateRight: 'clamp' })}px)`
                          : secAge >= 35
                          ? `blur(${interpolate(secAge, [35, 40], [0, 6], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' })}px)`
                          : 'none',
                        willChange: 'transform, filter'
                      }}
                    />
                    <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(2,6,23,0.7) 0%, rgba(2,6,23,0.1) 40%, rgba(2,6,23,0.88) 100%)' }} />

                    <div style={{ position: 'absolute', bottom: 380, left: 80, right: 80, textAlign: 'center' }}>
                      {/* Resonating Badge with Shockwave & Specular Glint */}
                      <div style={{ position: 'relative', display: 'inline-block' }}>
                        {/* Outward Resonating Shockwave Ring */}
                        <div
                          style={{
                            position: 'absolute',
                            inset: -4,
                            borderRadius: 999,
                            border: '2px solid #06b6d4',
                            boxShadow: '0 0 25px #06b6d4',
                            opacity: shockwaveOpacity,
                            transform: `scale(${shockwaveScale})`,
                            pointerEvents: 'none'
                          }}
                        />
                        {/* Main Pill Badge */}
                        <div
                          style={{
                            position: 'relative',
                            background: '#06b6d4',
                            color: '#020617',
                            padding: '10px 28px',
                            borderRadius: 999,
                            fontWeight: 900,
                            fontSize: 22,
                            boxShadow: '0 0 25px rgba(6,182,212,0.5)',
                            transform: `scale(${badgeScale})`,
                            overflow: 'hidden'
                          }}
                        >
                          COMMERCIAL MALLS • مول أو مركز تجاري
                          {/* Specular Glint Light Sweep */}
                          <div
                            style={{
                              position: 'absolute',
                              inset: 0,
                              background: 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.7) 50%, transparent 100%)',
                              transform: `translateX(${glintX}%)`,
                              pointerEvents: 'none'
                            }}
                          />
                        </div>
                      </div>

                      <h1 style={{ color: '#ffffff', fontSize: 68, fontWeight: 900, margin: '16px 0 6px 0', textShadow: '0 8px 30px rgba(0,0,0,0.9)', transform: `scale(${interpolate(secAge, [0, 6], [0.94, 1.0], { easing: Easing.out(Easing.cubic), extrapolateRight: 'clamp' })})` }}>
                        8,500 m²
                      </h1>
                      <div style={{ color: '#38bdf8', fontSize: 28, fontWeight: 800, fontFamily: 'monospace', textShadow: '0 0 15px rgba(56,189,248,0.7)' }}>
                        $1,850,000 AUD TENDER VALUE
                      </div>
                    </div>
                  </div>
                </AbsoluteFill>
              );
            })()}
          </Sequence>

          {/* Sector 3: Luxury Residential Penthouse (Frames 344 - 376) */}
          <Sequence from={80} durationInFrames={40}>
            {(() => {
              const secAge = frame - 560;
              const badgeScale = interpolate(secAge, [0, 5, 12], [0.82, 1.06, 1.0], { easing: Easing.out(Easing.back(1.8)), extrapolateRight: 'clamp' });
              const shockwaveScale = interpolate(secAge, [0, 16], [0.92, 1.35], { easing: Easing.out(Easing.quad), extrapolateRight: 'clamp' });
              const shockwaveOpacity = interpolate(secAge, [0, 4, 16], [0, 0.85, 0], { extrapolateRight: 'clamp' });
              const glintX = interpolate(secAge, [2, 18], [-150, 150], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
              return (
                <AbsoluteFill style={{ overflow: 'hidden' }}>
                  <div style={{ width: '100%', height: '100%' }}>
                    {/* Background with Snap-Zoom In & Directional Blur Out into Sector 4 */}
                    <Img
                      src={staticFile('tile-commercial/sector_residential_tower.jpg')}
                      style={{
                        width: '100%',
                        height: '100%',
                        objectFit: 'cover',
                        transform: `scale(${interpolate(secAge, [0, 5, 34, 40], [1.18, 1.02, 1.08, 1.22], { extrapolateRight: 'clamp' })}) translate3d(${
                          secAge <= 5
                            ? interpolate(secAge, [0, 5], [35, 0], { extrapolateRight: 'clamp' })
                            : interpolate(secAge, [35, 40], [0, -35], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' })
                        }px, 0, 0)`,
                        filter: secAge <= 4
                          ? `blur(${interpolate(secAge, [0, 4], [6, 0], { extrapolateRight: 'clamp' })}px)`
                          : secAge >= 35
                          ? `blur(${interpolate(secAge, [35, 40], [0, 6], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' })}px)`
                          : 'none',
                        willChange: 'transform, filter'
                      }}
                    />
                    <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(2,6,23,0.7) 0%, rgba(2,6,23,0.1) 40%, rgba(2,6,23,0.88) 100%)' }} />

                    <div style={{ position: 'absolute', bottom: 380, left: 80, right: 80, textAlign: 'center' }}>
                      {/* Resonating Badge with Shockwave & Specular Glint */}
                      <div style={{ position: 'relative', display: 'inline-block' }}>
                        {/* Outward Resonating Shockwave Ring */}
                        <div
                          style={{
                            position: 'absolute',
                            inset: -4,
                            borderRadius: 999,
                            border: '2px solid #fbbf24',
                            boxShadow: '0 0 25px #fbbf24',
                            opacity: shockwaveOpacity,
                            transform: `scale(${shockwaveScale})`,
                            pointerEvents: 'none'
                          }}
                        />
                        {/* Main Pill Badge */}
                        <div
                          style={{
                            position: 'relative',
                            background: '#fbbf24',
                            color: '#020617',
                            padding: '10px 28px',
                            borderRadius: 999,
                            fontWeight: 900,
                            fontSize: 22,
                            boxShadow: '0 0 25px rgba(251,191,36,0.5)',
                            transform: `scale(${badgeScale})`,
                            overflow: 'hidden'
                          }}
                        >
                          RESIDENTIAL TOWERS • مجمع سكني راقٍ
                          {/* Specular Glint Light Sweep */}
                          <div
                            style={{
                              position: 'absolute',
                              inset: 0,
                              background: 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.7) 50%, transparent 100%)',
                              transform: `translateX(${glintX}%)`,
                              pointerEvents: 'none'
                            }}
                          />
                        </div>
                      </div>

                      <h1 style={{ color: '#ffffff', fontSize: 68, fontWeight: 900, margin: '16px 0 6px 0', textShadow: '0 8px 30px rgba(0,0,0,0.9)', transform: `scale(${interpolate(secAge, [0, 6], [0.94, 1.0], { easing: Easing.out(Easing.cubic), extrapolateRight: 'clamp' })})` }}>
                        5,000 m²
                      </h1>
                      <div style={{ color: '#38bdf8', fontSize: 28, fontWeight: 800, fontFamily: 'monospace', textShadow: '0 0 15px rgba(56,189,248,0.7)' }}>
                        $1,200,000 AUD TENDER VALUE
                      </div>
                    </div>
                  </div>
                </AbsoluteFill>
              );
            })()}
          </Sequence>

          {/* Sector 4: Corporate Office Tower (Frames 376 - 410) */}
          <Sequence from={120} durationInFrames={40}>
            {(() => {
              const secAge = frame - 600;
              const badgeScale = interpolate(secAge, [0, 5, 12], [0.82, 1.06, 1.0], { easing: Easing.out(Easing.back(1.8)), extrapolateRight: 'clamp' });
              const shockwaveScale = interpolate(secAge, [0, 16], [0.92, 1.35], { easing: Easing.out(Easing.quad), extrapolateRight: 'clamp' });
              const shockwaveOpacity = interpolate(secAge, [0, 4, 16], [0, 0.85, 0], { extrapolateRight: 'clamp' });
              const glintX = interpolate(secAge, [2, 18], [-150, 150], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
              return (
                <AbsoluteFill style={{ overflow: 'hidden' }}>
                  <div style={{ width: '100%', height: '100%' }}>
                    {/* Background with Snap-Zoom In from Sector 3 */}
                    <Img
                      src={staticFile('tile-commercial/sector_office_tower.jpg')}
                      style={{
                        width: '100%',
                        height: '100%',
                        objectFit: 'cover',
                        transform: `scale(${interpolate(secAge, [0, 5, 34], [1.18, 1.02, 1.08], { extrapolateRight: 'clamp' })}) translate3d(${
                          secAge <= 5
                            ? interpolate(secAge, [0, 5], [35, 0], { extrapolateRight: 'clamp' })
                            : 0
                        }px, 0, 0)`,
                        filter: secAge <= 4
                          ? `blur(${interpolate(secAge, [0, 4], [6, 0], { extrapolateRight: 'clamp' })}px)`
                          : 'none',
                        willChange: 'transform, filter'
                      }}
                    />
                    <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(2,6,23,0.7) 0%, rgba(2,6,23,0.1) 40%, rgba(2,6,23,0.88) 100%)' }} />

                    <div style={{ position: 'absolute', bottom: 380, left: 80, right: 80, textAlign: 'center' }}>
                      {/* Resonating Badge with Shockwave & Specular Glint */}
                      <div style={{ position: 'relative', display: 'inline-block' }}>
                        {/* Outward Resonating Shockwave Ring */}
                        <div
                          style={{
                            position: 'absolute',
                            inset: -4,
                            borderRadius: 999,
                            border: '2px solid #38bdf8',
                            boxShadow: '0 0 25px #38bdf8',
                            opacity: shockwaveOpacity,
                            transform: `scale(${shockwaveScale})`,
                            pointerEvents: 'none'
                          }}
                        />
                        {/* Main Pill Badge */}
                        <div
                          style={{
                            position: 'relative',
                            background: '#38bdf8',
                            color: '#020617',
                            padding: '10px 28px',
                            borderRadius: 999,
                            fontWeight: 900,
                            fontSize: 22,
                            boxShadow: '0 0 25px rgba(56,189,248,0.5)',
                            transform: `scale(${badgeScale})`,
                            overflow: 'hidden'
                          }}
                        >
                          OFFICE TOWERS & HQ • برج مكاتب ومقر إداري
                          {/* Specular Glint Light Sweep */}
                          <div
                            style={{
                              position: 'absolute',
                              inset: 0,
                              background: 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.7) 50%, transparent 100%)',
                              transform: `translateX(${glintX}%)`,
                              pointerEvents: 'none'
                            }}
                          />
                        </div>
                      </div>

                      <h1 style={{ color: '#ffffff', fontSize: 68, fontWeight: 900, margin: '16px 0 6px 0', textShadow: '0 8px 30px rgba(0,0,0,0.9)', transform: `scale(${interpolate(secAge, [0, 6], [0.94, 1.0], { easing: Easing.out(Easing.cubic), extrapolateRight: 'clamp' })})` }}>
                        12,000 m²
                      </h1>
                      <div style={{ color: '#38bdf8', fontSize: 28, fontWeight: 800, fontFamily: 'monospace', textShadow: '0 0 15px rgba(56,189,248,0.7)' }}>
                        $2,700,000 AUD TENDER VALUE
                      </div>
                    </div>
                  </div>
                </AbsoluteFill>
              );
            })()}
          </Sequence>

          {/* Top Escalation Header (Safe Zone: top: 220px) */}
          <div
            style={{
              position: 'absolute',
              top: 220,
              left: 80,
              right: 80,
              textAlign: 'center'
            }}
          >
            <div
              style={{
                display: 'inline-block',
                background: 'rgba(15, 23, 42, 0.85)',
                backdropFilter: 'blur(16px)',
                border: '1.5px solid rgba(255,255,255,0.3)',
                color: '#f8fafc',
                fontSize: 18,
                fontWeight: 900,
                padding: '10px 28px',
                borderRadius: 999,
                letterSpacing: '0.12em'
              }}
            >
              ★ WHERE THE REVENUE ENGINE DEPLOYS
            </div>
          </div>
        </AbsoluteFill>
      </Sequence>

      {/* ──────────────────────────────────────────────────────────
          BEAT 5: APPLE-STYLE 3D DEVICE + INTERLOCKING TILES BACKGROUND
          (Frames 410 - 580 / 13.6s - 19.3s)
          No more flat navy background! 3D Interlocking Stone Slabs Snapping in place!
      ─────────────────────────────────────────────────────────── */}
      <Sequence from={640} durationInFrames={224}>
        <AbsoluteFill style={{ backgroundColor: '#020617', perspective: '1400px', overflow: 'hidden' }}>

          {/* 3D INTERLOCKING ARCHITECTURAL TILES ASSEMBLED IN BACKGROUND */}
          <div
            style={{
              position: 'absolute',
              inset: -120,
              transform: `
                rotateX(16deg)
                rotateY(${interpolate(frame - 640, [0, 170], [-8, 6])}deg)
                scale(${interpolate(frame - 640, [0, 170], [1.02, 1.1])})
              `,
              transformStyle: 'preserve-3d',
              display: 'grid',
              gridTemplateColumns: 'repeat(3, 1fr)',
              gap: 24,
              opacity: 0.92,
              filter: 'brightness(0.95) contrast(1.15) saturate(1.1)'
            }}
          >
            {[
              { img: 'sector_hotel_resort.jpg', z: 20, border: 'rgba(251, 191, 36, 0.45)' },
              { img: 'sector_mall_retail.jpg', z: -10, border: 'rgba(6, 182, 212, 0.45)' },
              { img: 'sector_residential_tower.jpg', z: 30, border: 'rgba(16, 185, 129, 0.45)' },
              { img: 'sector_office_tower.jpg', z: -15, border: 'rgba(236, 72, 153, 0.45)' },
              { img: 'sector_hotel_resort.jpg', z: 25, border: 'rgba(251, 191, 36, 0.45)' },
              { img: 'sector_residential_tower.jpg', z: 0, border: 'rgba(6, 182, 212, 0.45)' }
            ].map((tile, idx) => (
              <div
                key={idx}
                style={{
                  height: 520,
                  borderRadius: 28,
                  overflow: 'hidden',
                  border: `2.5px solid ${tile.border}`,
                  boxShadow: '0 30px 70px rgba(0,0,0,0.85), inset 0 0 0 2px rgba(255,255,255,0.2)',
                  transform: `
                    translateZ(${interpolate(frame - 640, [0, 45], [-240, tile.z], { extrapolateRight: 'clamp' })}px)
                    rotateZ(${idx % 2 === 0 ? 1 : -1}deg)
                  `,
                  position: 'relative'
                }}
              >
                <Img src={staticFile(`tile-commercial/${tile.img}`)} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                {/* Tile Glaze & Chamfered Grout Reflection */}
                <div
                  style={{
                    position: 'absolute',
                    inset: 0,
                    background: 'linear-gradient(135deg, rgba(255,255,255,0.25) 0%, rgba(2,6,23,0.15) 50%, rgba(0,0,0,0.45) 100%)'
                  }}
                />
              </div>
            ))}
          </div>

          {/* Gentle Luxury Ambient Vignette (Keeps slabs vibrant & sharp!) */}
          <div
            style={{
              position: 'absolute',
              inset: 0,
              background: 'radial-gradient(circle at 50% 50%, rgba(2,6,23,0.3) 0%, rgba(2,6,23,0.75) 100%)',
              pointerEvents: 'none'
            }}
          />

          {/* Heading (Safe Zone: top: 220px) */}
          <div
            style={{
              position: 'absolute',
              top: 220,
              left: 80,
              right: 80,
              textAlign: 'center',
              zIndex: 30
            }}
          >
            <div
              style={{
                display: 'inline-block',
                background: 'rgba(6, 182, 212, 0.28)',
                border: '2px solid #06b6d4',
                color: '#38bdf8',
                fontSize: 22,
                fontWeight: 900,
                padding: '12px 30px',
                borderRadius: 999,
                letterSpacing: '0.12em',
                marginBottom: 16,
                boxShadow: '0 0 25px rgba(6, 182, 212, 0.45)',
                textShadow: '0 2px 10px rgba(0,0,0,0.95)'
              }}
            >
              ★ THE DIGITAL TRANSFORMATION
            </div>
            <h2 style={{ fontSize: 62, fontWeight: 900, color: '#ffffff', margin: 0, lineHeight: 1.15, textShadow: '0 4px 20px rgba(0,0,0,0.95)' }}>
              The Akkari Revenue Engine
            </h2>
          </div>

          {/* 3D TILTED APPLE IPHONE CHASSIS (Centered in Safe Zone) */}
          <div
            style={{
              position: 'absolute',
              top: 380,
              left: '50%',
              marginLeft: -260,
              width: 520,
              height: 1040,
              transform: `
                rotateX(${interpolate(frame - 640, [0, 40], [22, 12], { extrapolateRight: 'clamp' })}deg)
                rotateY(${interpolate(frame - 640, [0, 40], [-24, -8], { extrapolateRight: 'clamp' })}deg)
                rotateZ(${interpolate(frame - 640, [0, 40], [5, 1], { extrapolateRight: 'clamp' })}deg)
                scale(${spring({ frame: frame - 640, fps, config: { damping: 18, stiffness: 90 } })})
              `,
              transformStyle: 'preserve-3d',
              borderRadius: 56,
              background: 'linear-gradient(145deg, #1e293b, #0f172a)',
              padding: 14,
              boxShadow: `
                0 40px 100px rgba(0,0,0,0.95),
                0 0 70px rgba(6, 182, 212, 0.35),
                inset 0 0 2px 2px rgba(255,255,255,0.3)
              `,
              border: '2.5px solid rgba(255,255,255,0.2)',
              zIndex: 10
            }}
          >
            {/* Dynamic Island / Speaker Notch */}
            <div
              style={{
                position: 'absolute',
                top: 24,
                left: '50%',
                marginLeft: -65,
                width: 130,
                height: 28,
                borderRadius: 20,
                backgroundColor: '#000000',
                zIndex: 20
              }}
            />

            {/* Inner Phone Screen with DYNAMIC SCROLLING */}
            <div
              style={{
                width: '100%',
                height: '100%',
                borderRadius: 44,
                overflow: 'hidden',
                backgroundColor: '#020617',
                position: 'relative'
              }}
            >
              <div
                style={{
                  width: '100%',
                  transform: `translateY(-${interpolate(frame - 640, [30, 150], [0, 440], {
                    extrapolateLeft: 'clamp',
                    extrapolateRight: 'clamp'
                  })}px)`
                }}
              >
                <Img
                  src={staticFile('tile-commercial/ui_portal_mobile_hero.png')}
                  style={{ width: '100%', display: 'block' }}
                />
                <Img
                  src={staticFile('tile-commercial/ui_portal_mobile_packages.png')}
                  style={{ width: '100%', display: 'block' }}
                />
              </div>
            </div>
          </div>

          {/* Floating Parallax HUD Cards (Positioned safely: NEVER touching title!) */}
          {/* Card 1: Dynamic Countdown from 4.8s Lag down to 0.7s Instant! */}
          {(() => {
            const b5Age = frame - 640;
            const speedNumber = interpolate(b5Age, [8, 44], [4.8, 0.7], {
              extrapolateLeft: 'clamp',
              extrapolateRight: 'clamp'
            });
            const isSpeedFast = b5Age >= 40;
            const speedColor = isSpeedFast ? '#10b981' : (b5Age < 20 ? '#f43f5e' : '#fbbf24');
            const speedGlow = isSpeedFast ? 'rgba(16, 185, 129, 0.5)' : (b5Age < 20 ? 'rgba(244, 63, 94, 0.5)' : 'rgba(251, 191, 36, 0.5)');

            return (
              <div
                style={{
                  position: 'absolute',
                  top: 610,
                  right: 50,
                  zIndex: 25,
                  background: 'rgba(15, 23, 42, 0.92)',
                  backdropFilter: 'blur(20px)',
                  border: `2px solid ${speedColor}`,
                  borderRadius: 24,
                  padding: '24px 34px',
                  boxShadow: `0 20px 50px rgba(0,0,0,0.85), 0 0 40px ${speedGlow}`,
                  transform: `
                    translateY(${interpolate(b5Age, [0, 35], [50, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' })}px)
                    scale(${spring({ frame: b5Age, fps, config: { damping: 18, stiffness: 90 } })})
                  `
                }}
              >
                <div style={{ color: speedColor, fontSize: 18, fontWeight: 900, letterSpacing: '0.08em', textShadow: '0 2px 8px rgba(0,0,0,0.95)' }}>
                  {isSpeedFast ? '★ LOAD SPEED' : '⚠️ PREVIOUS LAG'}
                </div>
                <div
                  style={{
                    color: '#ffffff',
                    fontSize: 54,
                    fontWeight: 900,
                    fontFamily: 'monospace',
                    marginTop: 4,
                    textShadow: `0 0 30px ${speedGlow}, 0 2px 14px rgba(0,0,0,0.95)`
                  }}
                >
                  {speedNumber.toFixed(1)}s
                </div>
                <div style={{ color: isSpeedFast ? '#6ee7b7' : '#fca5a5', fontSize: 20, fontWeight: 900, marginTop: 6, textShadow: '0 2px 10px rgba(0,0,0,0.95)' }}>
                  {isSpeedFast ? 'Google Score 98+' : 'Elementor Bloat'}
                </div>
              </div>
            );
          })()}

          {/* Card 2: Tender Conversion Dynamic Count-up to +240% */}
          {(() => {
            const b5Age = frame - 640;
            const convNumber = Math.round(
              interpolate(b5Age, [18, 54], [0, 240], {
                extrapolateLeft: 'clamp',
                extrapolateRight: 'clamp'
              })
            );

            return (
              <div
                style={{
                  position: 'absolute',
                  bottom: 400,
                  left: 50,
                  zIndex: 25,
                  background: 'rgba(15, 23, 42, 0.92)',
                  backdropFilter: 'blur(20px)',
                  border: '2px solid #06b6d4',
                  borderRadius: 24,
                  padding: '24px 34px',
                  boxShadow: '0 20px 50px rgba(0,0,0,0.85), 0 0 40px rgba(6, 182, 212, 0.5)',
                  transform: `
                    translateY(${interpolate(b5Age, [15, 50], [50, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' })}px)
                    scale(${spring({ frame: b5Age - 15, fps, config: { damping: 18, stiffness: 90 } })})
                  `
                }}
              >
                <div style={{ color: '#38bdf8', fontSize: 18, fontWeight: 900, letterSpacing: '0.08em', textShadow: '0 2px 8px rgba(0,0,0,0.95)' }}>
                  ★ TENDER CONVERSION
                </div>
                <div
                  style={{
                    color: '#ffffff',
                    fontSize: 54,
                    fontWeight: 900,
                    fontFamily: 'monospace',
                    marginTop: 4,
                    textShadow: '0 0 30px rgba(6, 182, 212, 0.8), 0 2px 14px rgba(0,0,0,0.95)'
                  }}
                >
                  +{convNumber}%
                </div>
                <div style={{ color: '#7dd3fc', fontSize: 20, fontWeight: 900, marginTop: 6, textShadow: '0 2px 10px rgba(0,0,0,0.95)' }}>
                  Interactive CAD Intake
                </div>
              </div>
            );
          })()}
        </AbsoluteFill>
      </Sequence>

      {/* ──────────────────────────────────────────────────────────
          BEAT 6: THE COMMERCIAL PRO REVEAL (Frames 580 - 720 / 19.3s - 24.0s)
          Luxury Charcoal Atrium + True Translucent Glassmorphism Card
      ─────────────────────────────────────────────────────────── */}
      <Sequence from={864} durationInFrames={138}>
        <AbsoluteFill>
          {/* Resonating 2.5D Parallax Drift - Polished marble atrium glides seamlessly behind cards */}
          <Video
            src={staticFile('tile-commercial/shot4_luxury_lobby.mp4')}
            muted
            style={{
              width: '100%',
              height: '100%',
              objectFit: 'cover',
              transform: `translate3d(${interpolate(frame - 864, [90, 138], [0, -10], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' })}px, ${interpolate(frame - 864, [90, 138], [0, 10], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' })}px, 0) scale(${interpolate(frame - 864, [0, 90, 138], [1.02, 1.08, 1.14], { extrapolateRight: 'clamp' })}) rotate(${interpolate(frame - 864, [90, 138], [0, 0.25], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' })}deg)`,
              willChange: 'transform'
            }}
          />
          {/* Translucent overlay that lets floor shine completely! */}
          <div
            style={{
              position: 'absolute',
              inset: 0,
              background: 'linear-gradient(180deg, rgba(2,6,23,0.88) 0%, rgba(2,6,23,0.65) 28%, rgba(2,6,23,0.18) 46%, rgba(2,6,23,0.12) 70%, rgba(2,6,23,0.85) 100%)'
            }}
          />

          {/* Heading (Safe Zone: top: 280px) */}
          <div
            style={{
              position: 'absolute',
              top: 280,
              left: 70,
              right: 70,
              textAlign: 'center',
              transform: `scale(${spring({ frame: frame - 864, fps, config: { damping: 14 } })})`
            }}
          >
            <div
              style={{
                display: 'inline-block',
                background: 'rgba(251, 191, 36, 0.25)',
                border: '1.5px solid #fbbf24',
                color: '#fef08a',
                fontSize: 16,
                fontWeight: 900,
                padding: '8px 26px',
                borderRadius: 999,
                letterSpacing: '0.12em',
                marginBottom: 14
              }}
            >
              ★ RECOMMENDED STARTING TIER
            </div>
            <h2
              style={{
                fontSize: 68,
                fontWeight: 900,
                color: '#ffffff',
                margin: 0,
                lineHeight: 1.1,
                letterSpacing: '-0.02em',
                textShadow: '0 6px 30px rgba(0,0,0,0.95), 0 2px 8px rgba(0,0,0,0.9)'
              }}
            >
              Commercial Pro
            </h2>
            <div
              style={{
                display: 'inline-flex',
                alignItems: 'baseline',
                justifyContent: 'center',
                gap: 12,
                marginTop: 12,
                background: 'rgba(2, 6, 23, 0.75)',
                backdropFilter: 'blur(16px)',
                border: '1.5px solid rgba(16, 185, 129, 0.5)',
                borderRadius: 999,
                padding: '8px 28px',
                boxShadow: '0 10px 30px rgba(0,0,0,0.8), 0 0 25px rgba(16, 185, 129, 0.25)'
              }}
            >
              <span
                style={{
                  color: '#34d399',
                  fontSize: 36,
                  fontWeight: 900,
                  textShadow: '0 2px 10px rgba(0,0,0,0.95), 0 0 16px rgba(52,211,153,0.6)'
                }}
              >
                $5,200 AUD
              </span>
              <span
                style={{
                  color: '#f8fafc',
                  fontSize: 24,
                  fontWeight: 800,
                  textShadow: '0 2px 10px rgba(0,0,0,0.95)'
                }}
              >
                (~ $3,500 USD)
              </span>
            </div>
          </div>

          {/* PERFECTLY CENTERED FLOATING GLASSMORPHISM CARD (Ultra-Refined See-Through Glass) */}
          <div
            style={{
              position: 'absolute',
              top: 610,
              left: 70,
              right: 70,
              background: 'linear-gradient(145deg, rgba(255, 255, 255, 0.14) 0%, rgba(15, 23, 42, 0.32) 35%, rgba(15, 23, 42, 0.44) 100%)',
              backdropFilter: 'blur(22px) saturate(210%) brightness(1.04)',
              border: '2px solid rgba(16, 185, 129, 0.6)',
              borderRadius: 36,
              padding: '42px 40px',
              boxShadow: '0 30px 80px rgba(0,0,0,0.55), 0 0 45px rgba(16, 185, 129, 0.25), inset 0 1.5px 1px rgba(255,255,255,0.45), inset 0 -1px 1px rgba(255,255,255,0.1)',
              transform: `scale(${spring({ frame: frame - 864, fps, config: { damping: 18, stiffness: 90 } })})`
            }}
          >
            <div style={{ display: 'flex', flexDirection: 'column', gap: 26 }}>
              {[
                {
                  title: 'Sub-Second Clean Code Stack',
                  desc: 'Google 98+ Score — Zero Elementor Bloat',
                  tag: 'Score 98+'
                },
                {
                  title: 'Victorian Compliance Trust Hub',
                  desc: 'VBA Registered & $20M Public Liability Insurance',
                  tag: 'VBA + $20M'
                },
                {
                  title: 'Interactive Project Case Studies',
                  desc: 'Prestige Proof: Marriott, Gucci & Seafarers',
                  tag: 'Tender Proof'
                },
                {
                  title: 'Modular Scalable Architecture',
                  desc: 'Direct upgrade to Enterprise CAD portal anytime',
                  tag: 'Scale Guaranteed'
                }
              ].map((feat, idx) => {
                const itemStart = 20 + idx * 16; // Sequential reveal starting at frame 20
                const itemProgress = frame - 864 - itemStart;
                const isRevealed = itemProgress >= 0;
                const isTicked = itemProgress >= 8; // Tick pops 8 frames after item appears!

                const itemSlideX = isRevealed
                  ? interpolate(itemProgress, [0, 10], [45, 0], { extrapolateRight: 'clamp' })
                  : 45;
                const itemOpacity = isRevealed
                  ? interpolate(itemProgress, [0, 8], [0, 1], { extrapolateRight: 'clamp' })
                  : 0;

                const tickSpringVal = isTicked
                  ? spring({
                      frame: itemProgress - 8,
                      fps,
                      config: { damping: 14, mass: 0.5, stiffness: 120 }
                    })
                  : 0;

                return (
                  <div
                    key={idx}
                    style={{
                      transform: `translateX(${itemSlideX}px)`,
                      opacity: itemOpacity,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      gap: 20
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
                      {/* ANIMATED TICKING CHECKBOX CONTAINER */}
                      <div
                        style={{
                          position: 'relative',
                          width: 48,
                          height: 48,
                          borderRadius: 15,
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flexShrink: 0,
                          background: isTicked
                            ? 'linear-gradient(135deg, #10b981, #059669)'
                            : 'rgba(15, 23, 42, 0.65)',
                          border: isTicked
                            ? '2px solid #34d399'
                            : '2px solid rgba(148, 163, 184, 0.35)',
                          boxShadow: isTicked
                            ? '0 0 30px rgba(16, 185, 129, 0.85), inset 0 1px 1px rgba(255,255,255,0.4)'
                            : 'none',
                          transform: isTicked ? `scale(${tickSpringVal})` : 'scale(1)'
                        }}
                      >
                        {/* Green radar expanding ripple on tick */}
                        {isTicked && itemProgress - 8 < 14 && (
                          <div
                            style={{
                              position: 'absolute',
                              inset: -8,
                              borderRadius: 20,
                              border: '2px solid #10b981',
                              opacity: interpolate(itemProgress - 8, [0, 14], [0.85, 0]),
                              transform: `scale(${interpolate(itemProgress - 8, [0, 14], [1, 1.55])})`,
                              pointerEvents: 'none'
                            }}
                          />
                        )}

                        {/* Animated Checkmark Pop */}
                        <span
                          style={{
                            color: '#ffffff',
                            fontWeight: 900,
                            fontSize: 26,
                            transform: `scale(${tickSpringVal})`,
                            display: isTicked ? 'inline-block' : 'none',
                            textShadow: '0 2px 8px rgba(0,0,0,0.4)'
                          }}
                        >
                          ✓
                        </span>
                      </div>

                      {/* Text content with green glow flash on tick */}
                      <div>
                        <div
                          style={{
                            color: '#ffffff',
                            fontWeight: 900,
                            fontSize: 28,
                            letterSpacing: '0.01em',
                            textShadow: isTicked
                              ? '0 0 20px rgba(52, 211, 153, 0.45), 0 2px 14px rgba(0,0,0,0.95)'
                              : '0 2px 14px rgba(0,0,0,0.95)'
                          }}
                        >
                          {feat.title}
                        </div>
                        <div
                          style={{
                            color: '#e2e8f0',
                            fontSize: 18,
                            marginTop: 4,
                            fontWeight: 600,
                            textShadow: '0 2px 10px rgba(0,0,0,0.95)'
                          }}
                        >
                          {feat.desc}
                        </div>
                      </div>
                    </div>

                    {/* Equal Width Rectangles on Right (Clean Razor-Sharp Column!) */}
                    <div
                      style={{
                        width: 210,
                        minWidth: 210,
                        textAlign: 'center',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        background: isTicked ? 'rgba(16, 185, 129, 0.22)' : 'rgba(255, 255, 255, 0.08)',
                        border: isTicked ? '1.5px solid #10b981' : '1px solid rgba(255, 255, 255, 0.16)',
                        color: isTicked ? '#34d399' : '#94a3b8',
                        fontSize: 17,
                        fontWeight: 900,
                        padding: '11px 16px',
                        borderRadius: 12,
                        letterSpacing: '0.04em',
                        boxShadow: isTicked ? '0 0 25px rgba(16, 185, 129, 0.45)' : 'none',
                        textShadow: '0 2px 8px rgba(0,0,0,0.95)',
                        flexShrink: 0
                      }}
                    >
                      {feat.tag}
                    </div>
                  </div>
                );
              })}
            </div>

            <div style={{ height: 1.5, background: 'rgba(255, 255, 255, 0.15)', margin: '30px 0 22px 0' }} />

            {/* Bottom Scale-Up Guarantee (Slides in smoothly) */}
            <div
              style={{
                textAlign: 'center',
                color: '#6ee7b7',
                fontSize: 19,
                fontWeight: 800,
                textShadow: '0 2px 10px rgba(0,0,0,0.95)',
                opacity: interpolate(frame - 864, [80, 95], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' }),
                transform: `translateY(${interpolate(frame - 864, [80, 95], [15, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' })}px)`
              }}
            >
              ⚡ Modular Foundation: Designed to scale without rewriting code.
            </div>
          </div>

          {/* FLOATING TRUST ASSURANCE PILL (Safe Zone: bottom: 390px) */}
          <div
            style={{
              position: 'absolute',
              bottom: 390,
              left: 70,
              right: 70,
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              opacity: interpolate(frame - 864, [90, 110], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' }),
              transform: `translateY(${interpolate(frame - 864, [90, 110], [20, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' })}px)`
            }}
          >
            <div
              style={{
                background: 'rgba(15, 23, 42, 0.78)',
                backdropFilter: 'blur(20px)',
                border: '1.5px solid rgba(56, 189, 248, 0.4)',
                borderRadius: 999,
                padding: '14px 32px',
                color: '#38bdf8',
                fontSize: 16,
                fontWeight: 900,
                letterSpacing: '0.06em',
                boxShadow: '0 10px 30px rgba(0,0,0,0.6), 0 0 25px rgba(56, 189, 248, 0.2)'
              }}
            >
              🔒 AUDITED ARCHITECTURAL FOUNDATION // ZERO TECH DEBT
            </div>
          </div>
        </AbsoluteFill>
      </Sequence>

      {/* ──────────────────────────────────────────────────────────
          BEAT 7 & 8: BOARDROOM DEAL CLOSE & CONTINUOUS GOODBRAINS OUTRO
          (Frames 720 - 900 / 24.0s - 30.0s)
          shot5_boardroom_close.mp4 RUNS CONTINUOUSLY TO 30.0s!
          Akkari elements gracefully dissolve at frame 804-816
          At frame 819 (00:27.09): GoodBrains.Pro reveals directly ON the footage!
      ─────────────────────────────────────────────────────────── */}
      <Sequence from={1002} durationInFrames={246}>
        <AbsoluteFill>
          {/* Continuous Melbourne Boardroom Footage (Zero dark cut!) */}
          <Video
            src={staticFile('tile-commercial/shot5_boardroom_close.mp4')}
            muted
            style={{
              width: '100%',
              height: '100%',
              objectFit: 'cover',
              transform: `scale(${interpolate(frame - 1002, [0, 180], [1.0, 1.07], { extrapolateRight: 'clamp' })})`
            }}
          />

          {/* Deep Cinematic Film Grade */}
          <div
            style={{
              position: 'absolute',
              inset: 0,
              background: 'linear-gradient(180deg, rgba(2,6,23,0.72) 0%, rgba(2,6,23,0.25) 35%, rgba(2,6,23,0.92) 80%)'
            }}
          />

          {/* Akkari Elements (Dissolve away smoothly between 818 and 829 before 00:27.20) */}
          {(() => {
            const akkariExitOpacity = interpolate(frame, [1128, 1139], [1, 0], {
              extrapolateLeft: 'clamp',
              extrapolateRight: 'clamp'
            });

            if (frame >= 1140) return null;

            return (
              <>
                {/* Center Brand Emblem (Safe Zone: top: 220px) - Jitter-Free Clamped Deceleration! */}
                <div
                  style={{
                    position: 'absolute',
                    top: 220,
                    left: 80,
                    right: 80,
                    textAlign: 'center',
                    opacity: akkariExitOpacity,
                    transform: `translateY(${interpolate(frame - 1002, [0, 14], [25, 0], {
                      extrapolateLeft: 'clamp',
                      extrapolateRight: 'clamp',
                      easing: Easing.out(Easing.cubic)
                    })}px)`,
                    willChange: 'transform, opacity',
                    WebkitFontSmoothing: 'antialiased',
                    backfaceVisibility: 'hidden'
                  }}
                >
                  <div
                    style={{
                      width: 96,
                      height: 96,
                      borderRadius: 28,
                      background: 'linear-gradient(135deg, #06b6d4, #10b981)',
                      display: 'inline-flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontWeight: 900,
                      fontSize: 52,
                      color: '#020617',
                      boxShadow: '0 0 50px rgba(16, 185, 129, 0.55)'
                    }}
                  >
                    A
                  </div>
                  <h1
                    style={{
                      fontSize: 58,
                      fontWeight: 900,
                      color: '#ffffff',
                      letterSpacing: '0.04em',
                      margin: '18px 0 6px 0',
                      textShadow: '0 8px 30px rgba(0,0,0,0.95)'
                    }}
                  >
                    AKKARI TILING
                  </h1>
                  <div style={{ color: '#38bdf8', fontSize: 20, fontWeight: 900, letterSpacing: '0.15em', textShadow: '0 2px 10px rgba(0,0,0,0.95)' }}>
                    MELBOURNE // COMMERCIAL
                  </div>
                </div>

                {/* High-Converting Australian Tender CTA Box (Safe Zone: bottom: 360px) */}
                <div
                  style={{
                    position: 'absolute',
                    bottom: 360,
                    left: 70,
                    right: 70,
                    opacity: akkariExitOpacity,
                    background: 'rgba(15, 23, 42, 0.82)',
                    backdropFilter: 'blur(28px) saturate(170%)',
                    border: '2px solid #10b981',
                    borderRadius: 32,
                    padding: '36px 36px',
                    textAlign: 'center',
                    boxShadow: '0 20px 60px rgba(0,0,0,0.85), 0 0 45px rgba(16, 185, 129, 0.4)',
                    willChange: 'opacity',
                    WebkitFontSmoothing: 'antialiased'
                  }}
                >
                  {/* Australian Tender Line Button with Light Sheen - ZERO PULSE JITTER */}
                  <div
                    style={{
                      position: 'relative',
                      overflow: 'hidden',
                      background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
                      color: '#020617',
                      fontSize: 27,
                      fontWeight: 900,
                      padding: '22px 28px',
                      borderRadius: 22,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: 14,
                      boxShadow: '0 12px 35px rgba(16, 185, 129, 0.5), 0 0 35px rgba(16, 185, 129, 0.4)'
                    }}
                  >
                    {/* Metallic Light Sheen Sweep */}
                    <div
                      style={{
                        position: 'absolute',
                        top: 0,
                        bottom: 0,
                        left: 0,
                        width: '100%',
                        background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.45), transparent)',
                        transform: `translateX(${interpolate((frame - 1002) % 50, [0, 25], [-400, 600], { extrapolateRight: 'clamp' })}px)`,
                        pointerEvents: 'none'
                      }}
                    />
                    <span style={{ fontSize: 32 }}>📞</span>
                    <span>DIRECT TENDER LINE:</span>
                    <span style={{ fontFamily: 'monospace', fontSize: 31, fontWeight: 900, letterSpacing: '0.04em' }}>+61 400 764 508</span>
                  </div>

                  <div style={{ color: '#ffffff', fontSize: 24, fontWeight: 900, marginTop: 20, textShadow: '0 2px 10px rgba(0,0,0,0.95)' }}>
                    Commercial Pro Package • $5,200 AUD
                  </div>

                  {/* Prominent Illuminated Proposal URL Glass Pill */}
                  <div
                    style={{
                      marginTop: 14,
                      background: 'rgba(6, 182, 212, 0.22)',
                      border: '2px solid #06b6d4',
                      borderRadius: 18,
                      padding: '12px 26px',
                      display: 'inline-block',
                      boxShadow: '0 0 30px rgba(6, 182, 212, 0.4), inset 0 0 15px rgba(6, 182, 212, 0.15)'
                    }}
                  >
                    <div
                      style={{
                        color: '#38bdf8',
                        fontSize: 25,
                        fontFamily: 'monospace',
                        fontWeight: 900,
                        letterSpacing: '0.04em',
                        textShadow: '0 0 20px rgba(56, 189, 248, 0.8), 0 2px 10px rgba(0,0,0,0.95)'
                      }}
                    >
                      🔗 akkari-tiling-proposal.vercel.app
                    </div>
                  </div>
                </div>
              </>
            );
          })()}

          {/* AT FRAME 830 (00:27.20): 3D HONED STONE SLABS STACKING & CARVED GOODBRAINS REVEAL */}
          {frame >= 1140 && (
            <div
              style={{
                position: 'absolute',
                inset: 0,
                background: 'radial-gradient(circle at 50% 50%, rgba(2, 6, 23, 0.5) 0%, rgba(2, 6, 23, 0.88) 60%, rgba(2, 6, 23, 0.98) 100%)',
                backdropFilter: 'blur(16px)',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                opacity: interpolate(frame, [1140, 1148], [0, 1], {
                  extrapolateLeft: 'clamp',
                  extrapolateRight: 'clamp'
                })
              }}
            >
              {/* Main GoodBrains.Pro Studio Signature Container */}
              <div
                style={{
                  position: 'relative',
                  zIndex: 10,
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  textAlign: 'center',
                  width: '100%',
                  padding: '0 80px'
                }}
              >
                {/* PRESTIGE GOODBRAINS.PRO MEDALLION REVEAL */}
                <div
                  style={{
                    position: 'relative',
                    width: 260,
                    height: 260,
                    marginBottom: 34,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}
                >
                  {/* Clean 3D Golden Medallion GoodBrains Emblem */}
                  <div
                    style={{
                      position: 'relative',
                      zIndex: 20,
                      width: 250,
                      height: 250,
                      borderRadius: '50%',
                      boxShadow: '0 0 60px rgba(245, 158, 11, 0.45), 0 0 120px rgba(245, 158, 11, 0.2), inset 0 3px 8px rgba(0,0,0,0.9)',
                      border: '2px solid rgba(251, 191, 36, 0.4)',
                      transform: `scale(${interpolate(frame - 1140, [0, 16], [0.88, 1.0], { easing: Easing.out(Easing.cubic), extrapolateRight: 'clamp' })})`,
                      overflow: 'hidden'
                    }}
                  >
                    <Img
                      src={staticFile('tile-commercial/goodbrains_logo.png')}
                      style={{
                        width: '100%',
                        height: '100%',
                        objectFit: 'contain',
                        borderRadius: '50%',
                        display: 'block',
                        filter: 'drop-shadow(0 15px 35px rgba(0,0,0,0.95))'
                      }}
                    />

                    {/* Specular Gold Metallic Light Sheen Sweep Across the Emblem */}
                    <div
                      style={{
                        position: 'absolute',
                        inset: 0,
                        background: 'linear-gradient(115deg, transparent 25%, rgba(251, 191, 36, 0.45) 50%, transparent 75%)',
                        transform: `translateX(${interpolate(frame - 1154, [0, 24], [-300, 300], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' })}px)`,
                        pointerEvents: 'none'
                      }}
                    />
                  </div>
                </div>

                {/* Tracking "PRODUCED BY" */}
                <div
                  style={{
                    color: '#fbbf24',
                    fontSize: 18,
                    fontWeight: 900,
                    letterSpacing: '0.35em',
                    textTransform: 'uppercase',
                    textShadow: '0 0 20px rgba(251, 191, 36, 0.7)',
                    opacity: interpolate(frame - 1140, [10, 20], [0, 1], { extrapolateRight: 'clamp' }),
                    marginBottom: 12
                  }}
                >
                  PRODUCED BY
                </div>

                {/* Brand Title: GoodBrains.Pro */}
                <h1
                  style={{
                    color: '#ffffff',
                    fontSize: 56,
                    fontWeight: 900,
                    letterSpacing: '0.04em',
                    margin: 0,
                    textShadow: '0 4px 30px rgba(0,0,0,0.95)',
                    opacity: interpolate(frame - 1140, [14, 26], [0, 1], { extrapolateRight: 'clamp' })
                  }}
                >
                  GoodBrains<span style={{ color: '#fbbf24' }}>.Pro</span>
                </h1>

                {/* Tagline */}
                <div
                  style={{
                    color: '#94a3b8',
                    fontSize: 18,
                    fontWeight: 700,
                    letterSpacing: '0.22em',
                    textTransform: 'uppercase',
                    marginTop: 16,
                    textShadow: '0 2px 10px rgba(0,0,0,0.9)',
                    opacity: interpolate(frame - 1140, [18, 30], [0, 1], { extrapolateRight: 'clamp' })
                  }}
                >
                  Executive Digital Production
                </div>
              </div>
            </div>
          )}
        </AbsoluteFill>
      </Sequence>

      {/* ──────────────────────────────────────────────────────────
          MASTER ANAMORPHIC CINEMA COLOR GRADE OVERLAY
          Obsidian-slate contrast curve, golden specular preservation,
          and subtle anamorphic edge vignette across all 5 scenes.
      ─────────────────────────────────────────────────────────── */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          background: 'radial-gradient(ellipse at 50% 50%, transparent 60%, rgba(2, 6, 23, 0.4) 100%)',
          boxShadow: 'inset 0 0 120px rgba(2, 6, 23, 0.45)',
          pointerEvents: 'none',
          zIndex: 80
        }}
      />

    </AbsoluteFill>
  );
};
